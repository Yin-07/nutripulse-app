import { translations } from '../translations';

export const useTranslation = (language) => {
  return language === 'ar' ? translations.ar : translations.en;
};

