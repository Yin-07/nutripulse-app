import { useState, useEffect } from 'react';

export const useSettings = (language) => {
  // استرجاع الإعدادات من التخزين المحلي أو استخدام القيم الافتراضية
  const [settings, setSettings] = useState(() => {
    const savedSettings = localStorage.getItem('settings');
    return savedSettings ? JSON.parse(savedSettings) : {
      weightUnit: 'kg',
      heightUnit: 'cm',
      distanceUnit: 'km',
      volumeUnit: 'ml',
      temperatureUnit: 'celsius',
      theme: 'light',
      fontSize: 'medium',
      notifications: true,
      autoSave: true,
      language: language || 'ar'
    };
  });

  // حفظ الإعدادات في التخزين المحلي عند تغييرها
  useEffect(() => {
    localStorage.setItem('settings', JSON.stringify(settings));
  }, [settings]);

  // تحديث الإعدادات
  const updateSettings = (newSettings) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  // تحديث إعداد واحد
  const updateSetting = (key, value) => {
    setSettings(prev => ({ ...prev, [key]: value }));
  };

  // إعادة تعيين الإعدادات إلى القيم الافتراضية
  const resetSettings = () => {
    const defaultSettings = {
      weightUnit: 'kg',
      heightUnit: 'cm',
      distanceUnit: 'km',
      volumeUnit: 'ml',
      temperatureUnit: 'celsius',
      theme: 'light',
      fontSize: 'medium',
      notifications: true,
      autoSave: true,
      language: language || 'ar'
    };
    setSettings(defaultSettings);
  };

  // تحويل القيم بين وحدات القياس المختلفة
  const convertValue = (value, fromUnit, toUnit) => {
    if (fromUnit === toUnit) return value;

    // تحويل الوزن
    if ((fromUnit === 'kg' && toUnit === 'lb') || (fromUnit === 'lb' && toUnit === 'kg')) {
      return fromUnit === 'kg' ? value * 2.20462 : value / 2.20462;
    }

    // تحويل الطول
    if (fromUnit === 'cm' && toUnit === 'm') return value / 100;
    if (fromUnit === 'm' && toUnit === 'cm') return value * 100;
    if (fromUnit === 'cm' && toUnit === 'ft') return value * 0.0328084;
    if (fromUnit === 'ft' && toUnit === 'cm') return value / 0.0328084;
    if (fromUnit === 'm' && toUnit === 'ft') return value * 3.28084;
    if (fromUnit === 'ft' && toUnit === 'm') return value / 3.28084;
    if (fromUnit === 'ft' && toUnit === 'in') return value * 12;
    if (fromUnit === 'in' && toUnit === 'ft') return value / 12;
    if (fromUnit === 'cm' && toUnit === 'in') return value * 0.393701;
    if (fromUnit === 'in' && toUnit === 'cm') return value / 0.393701;

    // تحويل المسافة
    if ((fromUnit === 'km' && toUnit === 'mi') || (fromUnit === 'mi' && toUnit === 'km')) {
      return fromUnit === 'km' ? value * 0.621371 : value / 0.621371;
    }

    // تحويل الحجم
    if (fromUnit === 'ml' && toUnit === 'l') return value / 1000;
    if (fromUnit === 'l' && toUnit === 'ml') return value * 1000;
    if (fromUnit === 'ml' && toUnit === 'oz') return value * 0.033814;
    if (fromUnit === 'oz' && toUnit === 'ml') return value / 0.033814;
    if (fromUnit === 'l' && toUnit === 'oz') return value * 33.814;
    if (fromUnit === 'oz' && toUnit === 'l') return value / 33.814;
    if (fromUnit === 'ml' && toUnit === 'cup') return value * 0.00422675;
    if (fromUnit === 'cup' && toUnit === 'ml') return value / 0.00422675;
    if (fromUnit === 'l' && toUnit === 'cup') return value * 4.22675;
    if (fromUnit === 'cup' && toUnit === 'l') return value / 4.22675;

    // تحويل درجة الحرارة
    if (fromUnit === 'celsius' && toUnit === 'fahrenheit') return (value * 9/5) + 32;
    if (fromUnit === 'fahrenheit' && toUnit === 'celsius') return (value - 32) * 5/9;

    return value;
  };

  // الحصول على وحدة القياس المناسبة
  const getUnitLabel = (type, t) => {
    if (!t) return '';
    
    switch (type) {
      case 'weight':
        return settings.weightUnit === 'kg' ? t.settings.kg : t.settings.lb;
      case 'height':
        switch (settings.heightUnit) {
          case 'cm': return t.settings.cm;
          case 'm': return t.settings.m;
          case 'ft': return t.settings.ft;
          case 'in': return t.settings.in;
          default: return '';
        }
      case 'distance':
        return settings.distanceUnit === 'km' ? t.settings.km : t.settings.mi;
      case 'volume':
        switch (settings.volumeUnit) {
          case 'ml': return t.settings.ml;
          case 'l': return t.settings.l;
          case 'oz': return t.settings.oz;
          case 'cup': return t.settings.cup;
          default: return '';
        }
      case 'temperature':
        return settings.temperatureUnit === 'celsius' ? t.settings.celsius : t.settings.fahrenheit;
      default:
        return '';
    }
  };

  return {
    settings,
    updateSettings,
    updateSetting,
    resetSettings,
    convertValue,
    getUnitLabel
  };
};

