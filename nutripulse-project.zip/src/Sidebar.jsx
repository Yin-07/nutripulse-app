import React from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { 
  X, 
  Calculator, 
  Utensils, 
  Scale, 
  Activity, 
  Droplets,
  Percent,
  Zap,
  TrendingUp,
  Apple,
  ClipboardList,
  BarChart3,
  BookOpen,
  ChefHat,
  Calendar,
  Filter,
  FileText,
  Lightbulb,
  HelpCircle,
  User,
  Settings,
  Bell,
  Home,
  Scan,
  Ruler
} from 'lucide-react'
import { Button } from '@/components/ui/button.jsx'
import { getTranslation } from './translations'

const Sidebar = ({ isOpen, onClose, activeSection, onSectionChange, language }) => {
  const t = (key) => getTranslation(key, language)

  const sections = [
    {
      category: 'navigation',
      items: [
        { id: 'home', icon: Home, color: 'text-gray-600' }
      ]
    },
    {
      category: 'basic_calculators',
      items: [
        { id: 'daily-needs', icon: Calculator, color: 'text-blue-600' },
        { id: 'food-calories', icon: Utensils, color: 'text-purple-600' },
        { id: 'ideal-weight', icon: Scale, color: 'text-green-600' },
        { id: 'bmi', icon: Activity, color: 'text-orange-600' },
        { id: 'water-needs', icon: Droplets, color: 'text-cyan-600' }
      ]
    },
    {
      category: 'advanced_calculators',
      items: [
        { id: 'body-fat', icon: Percent, color: 'text-red-600' },
        { id: 'metabolic-rate', icon: Zap, color: 'text-yellow-600' },
        { id: 'barcode-scanner', icon: Scan, color: 'text-teal-600' }
      ]
    },
    {
      category: 'tracking_monitoring',
      items: [
        { id: 'weight-log', icon: TrendingUp, color: 'text-indigo-600' },
        { id: 'nutrition-tracking', icon: Apple, color: 'text-pink-600' },
        { id: 'activity-log', icon: ClipboardList, color: 'text-teal-600' },
        { id: 'progress-charts', icon: BarChart3, color: 'text-violet-600' }
      ]
    },
    {
      category: 'recipes_meals',
      items: [
        { id: 'healthy-recipes', icon: BookOpen, color: 'text-emerald-600' },
        { id: 'recipe-calculator', icon: ChefHat, color: 'text-amber-600' },
        { id: 'meal-planner', icon: Calendar, color: 'text-rose-600' },
        { id: 'recipe-filter', icon: Filter, color: 'text-sky-600' }
      ]
    },
    {
      category: 'information_support',
      items: [
        { id: 'articles', icon: FileText, color: 'text-slate-600' },
        { id: 'tips', icon: Lightbulb, color: 'text-lime-600' },
        { id: 'faq', icon: HelpCircle, color: 'text-fuchsia-600' }
      ]
    },
    {
      category: 'account_settings',
      items: [
        { id: 'user-profile', icon: User, color: 'text-gray-600' },
        { id: 'preferences', icon: Settings, color: 'text-stone-600' },
        { id: 'notifications', icon: Bell, color: 'text-zinc-600' },
        { id: 'unit-converter', icon: Ruler, color: 'text-blue-600' }
      ]
    }
  ]

  const sidebarVariants = {
    open: {
      x: 0,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 30
      }
    },
    closed: {
      x: language === 'ar' ? '100%' : '-100%',
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 30
      }
    }
  }

  const overlayVariants = {
    open: { opacity: 1 },
    closed: { opacity: 0 }
  }

  const itemVariants = {
    open: {
      opacity: 1,
      x: 0,
      transition: {
        type: "spring",
        stiffness: 300,
        damping: 30
      }
    },
    closed: {
      opacity: 0,
      x: language === 'ar' ? 20 : -20
    }
  }

  const containerVariants = {
    open: {
      transition: {
        staggerChildren: 0.05,
        delayChildren: 0.1
      }
    },
    closed: {
      transition: {
        staggerChildren: 0.02,
        staggerDirection: -1
      }
    }
  }

  const handleSectionClick = (sectionId) => {
    onSectionChange(sectionId)
    onClose()
  }

  return (
    <AnimatePresence>
      {isOpen && (
        <>
          {/* Overlay */}
          <motion.div
            initial="closed"
            animate="open"
            exit="closed"
            variants={overlayVariants}
            className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40"
            onClick={onClose}
          />

          {/* Sidebar */}
          <motion.div
            initial="closed"
            animate="open"
            exit="closed"
            variants={sidebarVariants}
            className={`fixed top-0 ${language === 'ar' ? 'right-0' : 'left-0'} h-full w-80 bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl border-${language === 'ar' ? 'l' : 'r'} border-gray-200 dark:border-gray-700 shadow-2xl z-50 overflow-y-auto`}
          >
            <div className="p-6">
              {/* Header */}
              <div className="flex items-center justify-between mb-8">
                <motion.h2 
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="text-xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent"
                >
                  {t('sections')}
                </motion.h2>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={onClose}
                  className="enhanced-button-ghost"
                >
                  <X className="h-5 w-5" />
                </Button>
              </div>

              {/* Navigation Sections */}
              <motion.div
                variants={containerVariants}
                initial="closed"
                animate="open"
                className="space-y-8"
              >
                {sections.map((section) => (
                  <motion.div key={section.category} variants={itemVariants}>
                    {section.category !== 'navigation' && (
                      <h3 className="text-sm font-semibold text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-3">
                        {t(section.category) || section.category.replace('_', ' ')}
                      </h3>
                    )}
                    <div className="space-y-1">
                      {section.items.map((item) => {
                        const IconComponent = item.icon
                        const isActive = activeSection === item.id
                        
                        return (
                          <motion.button
                            key={item.id}
                            onClick={() => handleSectionClick(item.id)}
                            className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-${language === 'ar' ? 'right' : 'left'} transition-all duration-200 ${
                              isActive
                                ? 'bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/30 dark:to-purple-900/30 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-700'
                                : 'hover:bg-gray-50 dark:hover:bg-gray-800/50 text-gray-700 dark:text-gray-300'
                            }`}
                            whileHover={{ scale: 1.02, x: language === 'ar' ? -2 : 2 }}
                            whileTap={{ scale: 0.98 }}
                          >
                            <IconComponent className={`h-5 w-5 ${isActive ? 'text-blue-600 dark:text-blue-400' : item.color}`} />
                            <span className="font-medium">
                              {t(item.id.replace('-', '_'))}
                            </span>
                            {isActive && (
                              <motion.div
                                layoutId="activeIndicator"
                                className={`ml-auto w-2 h-2 bg-blue-600 dark:bg-blue-400 rounded-full ${language === 'ar' ? 'mr-auto ml-0' : ''}`}
                                initial={false}
                                transition={{ type: "spring", stiffness: 300, damping: 30 }}
                              />
                            )}
                          </motion.button>
                        )
                      })}
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  )
}

export default Sidebar

