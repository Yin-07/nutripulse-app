export const translations = {
  en: {
    // Header
    title: "Calorie Calculator",
    subtitle: "Calculate calories in your food and your daily needs",
    
    // Navigation
    home: "Home",
    sections: "Sections",
    
    // Main sections
    sections_title: "Health & Nutrition Tools",
    sections_subtitle: "Choose the tool that suits your health goals",
    
    // Basic calculators
    daily_needs: "Daily Calorie Needs",
    daily_needs_desc: "Calculate your daily calorie requirements based on your personal data",
    food_calories: "Food Calorie Calculator",
    food_calories_desc: "Calculate calories in your food using macronutrients",
    ideal_weight: "Ideal Weight Calculator",
    ideal_weight_desc: "Find your ideal weight using scientific formulas",
    bmi: "BMI Calculator",
    bmi_desc: "Calculate your Body Mass Index and health status",
    water_needs: "Daily Water Needs",
    water_needs_desc: "Calculate your daily water requirements",
    
    // Advanced calculators
    body_fat: "Body Fat Percentage",
    body_fat_desc: "Calculate your body fat percentage using accurate methods",
    metabolic_rate: "Basal Metabolic Rate",
    metabolic_rate_desc: "Calculate your basal metabolic rate and calories burned at rest",
    barcode_scanner: "Barcode Scanner",
    barcode_scanner_desc: "Scan food barcodes to get nutritional information",
    
    // Tracking sections
    weight_log: "Weight & Measurements Log",
    weight_log_desc: "Track your weight and body measurements over time",
    nutrition_tracking: "Nutrition Tracking",
    nutrition_tracking_desc: "Monitor your daily intake of vitamins, minerals, and nutrients",
    activity_log: "Physical Activity Log",
    activity_log_desc: "Record your physical activities and calories burned",
    progress_charts: "Progress Charts",
    progress_charts_desc: "Visualize your health and fitness progress",
    
    // Recipe sections
    healthy_recipes: "Healthy Recipe Library",
    healthy_recipes_desc: "Discover healthy and delicious recipes with detailed nutritional information",
    recipe_calculator: "Recipe Calculator",
    recipe_calculator_desc: "Calculate nutritional values for your favorite recipes",
    meal_planner: "Meal Planner",
    meal_planner_desc: "Plan your weekly meals based on your nutritional goals",
    recipe_filter: "Recipe Filter",
    recipe_filter_desc: "Search for recipes by ingredients and dietary restrictions",
    
    // Information sections
    articles: "Nutrition Articles",
    articles_desc: "Read the latest articles and research in nutrition and health",
    tips: "Health Tips",
    tips_desc: "Get daily tips for a healthier lifestyle",
    faq: "Frequently Asked Questions",
    faq_desc: "Answers to the most common questions about nutrition and health",
    
    // Account sections
    user_profile: "User Profile",
    user_profile_desc: "Manage your personal data and preferences",
    preferences: "Settings & Preferences",
    preferences_desc: "Customize your experience according to your personal needs",
    notifications: "Notification Settings",
    notifications_desc: "Control health notifications and reminders",
    unit_converter: "Unit Converter",
    unit_converter_desc: "Convert between different units of measurement",
    
    // Form labels
    age: "Age (years)",
    gender: "Gender",
    weight: "Weight (kg)",
    height: "Height (cm)",
    activity_level: "Physical Activity Level",
    protein: "Protein (grams)",
    carbs: "Carbohydrates (grams)",
    fat: "Fat (grams)",
    
    // Buttons
    calculate: "Calculate",
    calculate_daily_needs: "Calculate Daily Needs",
    calculate_food_calories: "Calculate Food Calories",
    back_to_home: "Back to Home",
    
    // Gender options
    male: "Male",
    female: "Female",
    
    // Activity levels
    sedentary: "Sedentary (little or no exercise)",
    light: "Light activity (light exercise 1-3 days/week)",
    moderate: "Moderate activity (moderate exercise 3-5 days/week)",
    active: "Active (hard exercise 6-7 days/week)",
    very_active: "Very active (very hard exercise, physical job)",
    
    // Results
    your_daily_needs: "Your Daily Calorie Needs",
    for_weight_loss: "For Weight Loss",
    to_maintain_weight: "To Maintain Weight",
    for_weight_gain: "For Weight Gain",
    total_calories: "Total Calories",
    calories_per_gram: "calories/gram",
    
    // Coming soon
    coming_soon: "Coming Soon",
    coming_soon_desc: "This section is under development and will be available soon",
    
    // Categories
    basic_calculators: "Basic Calculators",
    advanced_calculators: "Advanced Calculators", 
    tracking_monitoring: "Tracking & Monitoring",
    recipes_meals: "Recipes & Meals",
    information_support: "Information & Support",
    account_settings: "Account & Settings",
    
    // Settings
    settings: {
      title: "Settings",
      description: "Customize your experience and preferences",
      units: "Measurement Units",
      weightUnit: "Weight Unit",
      heightUnit: "Height Unit",
      distanceUnit: "Distance Unit",
      volumeUnit: "Volume Unit",
      temperatureUnit: "Temperature Unit",
      appearance: "Appearance",
      theme: "Theme",
      fontSize: "Font Size",
      preferences: "Preferences",
      notifications: "Enable Notifications",
      autoSave: "Auto Save Data",
      reset: "Reset to Default",
      save: "Save Settings",
      savedMessage: "Settings saved successfully!",
      
      // Units
      kg: "Kilograms (kg)",
      lb: "Pounds (lb)",
      cm: "Centimeters (cm)",
      m: "Meters (m)",
      ft: "Feet (ft)",
      in: "Inches (in)",
      km: "Kilometers (km)",
      mi: "Miles (mi)",
      ml: "Milliliters (ml)",
      l: "Liters (l)",
      oz: "Fluid Ounces (oz)",
      cup: "Cups",
      celsius: "Celsius (°C)",
      fahrenheit: "Fahrenheit (°F)",
      
      // Theme options
      light: "Light",
      dark: "Dark",
      auto: "Auto (System)",
      
      // Font size options
      small: "Small",
      medium: "Medium",
      large: "Large"
    },
    
    // Unit Converter
    converter: {
      title: "Unit Converter",
      description: "Convert between different units of measurement",
      type: "Conversion Type",
      select_type: "Select conversion type",
      weight: "Weight",
      height: "Height",
      distance: "Distance",
      volume: "Volume",
      temperature: "Temperature",
      from: "From",
      to: "To",
      convert: "Convert",
      result: "Result"
    },
    
    // Footer
    disclaimer: "⚠️ Disclaimer:",
    disclaimer_text: "This calculator provides approximate estimates for educational purposes only. Consult a qualified nutritionist for a personalized diet plan and accurate medical advice.",
    
    // Errors
    please_fill_all_fields: "Please fill in all fields",
    invalid_age: "Please enter a valid age",
    invalid_weight: "Please enter a valid weight",
    invalid_height: "Please enter a valid height",
    select_gender: "Please select gender",
    select_activity: "Please select activity level",
    invalid_protein: "Please enter a valid protein amount",
    invalid_carbs: "Please enter a valid carbohydrate amount",
    invalid_fat: "Please enter a valid fat amount"
  },
  
  ar: {
    // Header
    title: "حاسبة السعرات الحرارية",
    subtitle: "احسب السعرات الحرارية في طعامك واحتياجاتك اليومية",
    
    // Navigation
    home: "الرئيسية",
    sections: "الأقسام",
    
    // Main sections
    sections_title: "أدوات الصحة والتغذية",
    sections_subtitle: "اختر الأداة التي تناسب أهدافك الصحية",
    
    // Basic calculators
    daily_needs: "الاحتياجات اليومية",
    daily_needs_desc: "احسب احتياجاتك اليومية من السعرات الحرارية بناءً على بياناتك الشخصية",
    food_calories: "حساب سعرات الطعام",
    food_calories_desc: "احسب السعرات الحرارية في طعامك باستخدام المغذيات الكبرى",
    ideal_weight: "الوزن المثالي",
    ideal_weight_desc: "اكتشف وزنك المثالي باستخدام الصيغ العلمية",
    bmi: "مؤشر كتلة الجسم",
    bmi_desc: "احسب مؤشر كتلة الجسم وحالتك الصحية",
    water_needs: "احتياجات الماء اليومية",
    water_needs_desc: "احسب احتياجاتك اليومية من الماء",
    
    // Advanced calculators
    body_fat: "نسبة الدهون في الجسم",
    body_fat_desc: "احسب نسبة الدهون في جسمك باستخدام طرق دقيقة",
    metabolic_rate: "معدل الأيض الأساسي",
    metabolic_rate_desc: "احسب معدل الأيض الأساسي والسعرات المحروقة في الراحة",
    barcode_scanner: "ماسح الباركود",
    barcode_scanner_desc: "امسح الباركود للمنتجات الغذائية للحصول على المعلومات الغذائية",
    
    // Tracking sections
    weight_log: "سجل الوزن والقياسات",
    weight_log_desc: "تتبع وزنك وقياسات جسمك عبر الزمن",
    nutrition_tracking: "تتبع المغذيات",
    nutrition_tracking_desc: "راقب استهلاكك اليومي من الفيتامينات والمعادن والمغذيات",
    activity_log: "سجل النشاط البدني",
    activity_log_desc: "سجل أنشطتك البدنية والسعرات المحروقة",
    progress_charts: "مخططات التقدم",
    progress_charts_desc: "تصور تقدمك الصحي واللياقي",
    
    // Recipe sections
    healthy_recipes: "مكتبة الوصفات الصحية",
    healthy_recipes_desc: "اكتشف وصفات صحية ولذيذة مع معلومات غذائية مفصلة",
    recipe_calculator: "حاسبة الوصفات",
    recipe_calculator_desc: "احسب القيم الغذائية لوصفاتك المفضلة",
    meal_planner: "مخطط الوجبات",
    meal_planner_desc: "خطط وجباتك الأسبوعية بناءً على أهدافك الغذائية",
    recipe_filter: "تصفية الوصفات",
    recipe_filter_desc: "ابحث عن الوصفات حسب المكونات والقيود الغذائية",
    
    // Information sections
    articles: "مقالات التغذية",
    articles_desc: "اقرأ أحدث المقالات والأبحاث في مجال التغذية والصحة",
    tips: "نصائح صحية",
    tips_desc: "احصل على نصائح يومية لحياة صحية أفضل",
    faq: "الأسئلة الشائعة",
    faq_desc: "إجابات على أكثر الأسئلة شيوعاً حول التغذية والصحة",
    
    // Account sections
    user_profile: "الملف الشخصي",
    user_profile_desc: "إدارة بياناتك الشخصية وتفضيلاتك",
    preferences: "الإعدادات والتفضيلات",
    preferences_desc: "خصص تجربتك وفقاً لاحتياجاتك الشخصية",
    notifications: "إعدادات الإشعارات",
    notifications_desc: "تحكم في الإشعارات والتذكيرات الصحية",
    unit_converter: "محول وحدات القياس",
    unit_converter_desc: "تحويل بين وحدات القياس المختلفة",
    
    // Form labels
    age: "العمر (سنة)",
    gender: "الجنس",
    weight: "الوزن (كيلوجرام)",
    height: "الطول (سنتيمتر)",
    activity_level: "مستوى النشاط البدني",
    protein: "البروتين (جرام)",
    carbs: "الكربوهيدرات (جرام)",
    fat: "الدهون (جرام)",
    
    // Buttons
    calculate: "احسب",
    calculate_daily_needs: "احسب الاحتياجات اليومية",
    calculate_food_calories: "احسب سعرات الطعام",
    back_to_home: "العودة للرئيسية",
    
    // Gender options
    male: "ذكر",
    female: "أنثى",
    
    // Activity levels
    sedentary: "خامل (قليل أو لا يوجد تمرين)",
    light: "نشاط خفيف (تمرين خفيف 1-3 أيام/أسبوع)",
    moderate: "نشاط متوسط (تمرين متوسط 3-5 أيام/أسبوع)",
    active: "نشط (تمرين شاق 6-7 أيام/أسبوع)",
    very_active: "نشط جداً (تمرين شاق جداً، عمل بدني)",
    
    // Results
    your_daily_needs: "احتياجاتك اليومية من السعرات الحرارية",
    for_weight_loss: "لإنقاص الوزن",
    to_maintain_weight: "للحفاظ على الوزن",
    for_weight_gain: "لزيادة الوزن",
    total_calories: "إجمالي السعرات",
    calories_per_gram: "سعرة/جرام",
    
    // Coming soon
    coming_soon: "قريباً",
    coming_soon_desc: "هذا القسم قيد التطوير وسيكون متاحاً قريباً",
    
    // Categories
    basic_calculators: "الحاسبات الأساسية",
    advanced_calculators: "الحاسبات المتقدمة", 
    tracking_monitoring: "التتبع والمراقبة",
    recipes_meals: "الوصفات والوجبات",
    information_support: "المعلومات والدعم",
    account_settings: "الحساب والإعدادات",
    
    // Settings
    settings: {
      title: "الإعدادات",
      description: "تخصيص تجربتك وتفضيلاتك",
      units: "وحدات القياس",
      weightUnit: "وحدة الوزن",
      heightUnit: "وحدة الطول",
      distanceUnit: "وحدة المسافة",
      volumeUnit: "وحدة الحجم",
      temperatureUnit: "وحدة درجة الحرارة",
      appearance: "المظهر",
      theme: "السمة",
      fontSize: "حجم الخط",
      preferences: "التفضيلات",
      notifications: "تفعيل الإشعارات",
      autoSave: "حفظ البيانات تلقائياً",
      reset: "إعادة تعيين للافتراضي",
      save: "حفظ الإعدادات",
      savedMessage: "تم حفظ الإعدادات بنجاح!",
      
      // Units
      kg: "كيلوجرام (كجم)",
      lb: "رطل (باوند)",
      cm: "سنتيمتر (سم)",
      m: "متر (م)",
      ft: "قدم (قدم)",
      in: "بوصة (إنش)",
      km: "كيلومتر (كم)",
      mi: "ميل (ميل)",
      ml: "ملليلتر (مل)",
      l: "لتر (ل)",
      oz: "أونصة سائلة (أوز)",
      cup: "كوب",
      celsius: "سيلسيوس (°م)",
      fahrenheit: "فهرنهايت (°ف)",
      
      // Theme options
      light: "فاتح",
      dark: "داكن",
      auto: "تلقائي (حسب النظام)",
      
      // Font size options
      small: "صغير",
      medium: "متوسط",
      large: "كبير"
    },
    
    // Unit Converter
    converter: {
      title: "محول وحدات القياس",
      description: "تحويل بين وحدات القياس المختلفة",
      type: "نوع التحويل",
      select_type: "اختر نوع التحويل",
      weight: "الوزن",
      height: "الطول",
      distance: "المسافة",
      volume: "الحجم",
      temperature: "درجة الحرارة",
      from: "من",
      to: "إلى",
      convert: "تحويل",
      result: "النتيجة"
    },
    
    // Footer
    disclaimer: "⚠️ إخلاء مسؤولية:",
    disclaimer_text: "هذه الحاسبة تقدم تقديرات تقريبية للأغراض التعليمية فقط. استشر أخصائي تغذية مؤهل للحصول على خطة غذائية مخصصة ونصائح طبية دقيقة.",
    
    // Errors
    please_fill_all_fields: "يرجى ملء جميع الحقول",
    invalid_age: "يرجى إدخال عمر صحيح",
    invalid_weight: "يرجى إدخال وزن صحيح",
    invalid_height: "يرجى إدخال طول صحيح",
    select_gender: "يرجى اختيار الجنس",
    select_activity: "يرجى اختيار مستوى النشاط",
    invalid_protein: "يرجى إدخال كمية بروتين صحيحة",
    invalid_carbs: "يرجى إدخال كمية كربوهيدرات صحيحة",
    invalid_fat: "يرجى إدخال كمية دهون صحيحة"
  }
}

// Function to get browser language
export const getBrowserLanguage = () => {
  const browserLang = navigator.language || navigator.userLanguage
  if (browserLang.startsWith('ar')) {
    return 'ar'
  }
  return 'en' // Default to English
}

// Function to get translation
export const getTranslation = (key, language) => {
  return translations[language]?.[key] || translations.en[key] || key
}

