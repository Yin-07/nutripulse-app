import React from 'react'
import { motion } from 'framer-motion'
import { 
  Calculator, 
  Utensils, 
  Scale, 
  Activity, 
  Droplets,
  Percent,
  Zap,
  TrendingUp,
  Apple,
  ClipboardList,
  BarChart3,
  BookOpen,
  ChefHat,
  Calendar,
  Filter,
  FileText,
  Lightbulb,
  HelpCircle,
  User,
  Settings,
  Bell
} from 'lucide-react'
import { Card, CardContent } from '@/components/ui/card.jsx'
import { getTranslation } from '../translations'

const HomePage = ({ language, onSectionChange }) => {
  const t = (key) => getTranslation(key, language)

  const sections = [
    // Basic Calculators
    {
      id: 'daily-needs',
      icon: Calculator,
      color: 'from-blue-500 to-blue-600',
      bgColor: 'bg-blue-50 dark:bg-blue-900/20',
      category: 'basic'
    },
    {
      id: 'food-calories',
      icon: Utensils,
      color: 'from-purple-500 to-purple-600',
      bgColor: 'bg-purple-50 dark:bg-purple-900/20',
      category: 'basic'
    },
    {
      id: 'ideal-weight',
      icon: Scale,
      color: 'from-green-500 to-green-600',
      bgColor: 'bg-green-50 dark:bg-green-900/20',
      category: 'basic'
    },
    {
      id: 'bmi',
      icon: Activity,
      color: 'from-orange-500 to-orange-600',
      bgColor: 'bg-orange-50 dark:bg-orange-900/20',
      category: 'basic'
    },
    {
      id: 'water-needs',
      icon: Droplets,
      color: 'from-cyan-500 to-cyan-600',
      bgColor: 'bg-cyan-50 dark:bg-cyan-900/20',
      category: 'basic'
    },
    
    // Advanced Calculators
    {
      id: 'body-fat',
      icon: Percent,
      color: 'from-red-500 to-red-600',
      bgColor: 'bg-red-50 dark:bg-red-900/20',
      category: 'advanced'
    },
    {
      id: 'metabolic-rate',
      icon: Zap,
      color: 'from-yellow-500 to-yellow-600',
      bgColor: 'bg-yellow-50 dark:bg-yellow-900/20',
      category: 'advanced'
    },
    
    // Tracking Sections
    {
      id: 'weight-log',
      icon: TrendingUp,
      color: 'from-indigo-500 to-indigo-600',
      bgColor: 'bg-indigo-50 dark:bg-indigo-900/20',
      category: 'tracking'
    },
    {
      id: 'nutrition-tracking',
      icon: Apple,
      color: 'from-pink-500 to-pink-600',
      bgColor: 'bg-pink-50 dark:bg-pink-900/20',
      category: 'tracking'
    },
    {
      id: 'activity-log',
      icon: ClipboardList,
      color: 'from-teal-500 to-teal-600',
      bgColor: 'bg-teal-50 dark:bg-teal-900/20',
      category: 'tracking'
    },
    {
      id: 'progress-charts',
      icon: BarChart3,
      color: 'from-violet-500 to-violet-600',
      bgColor: 'bg-violet-50 dark:bg-violet-900/20',
      category: 'tracking'
    },
    
    // Recipe Sections
    {
      id: 'healthy-recipes',
      icon: BookOpen,
      color: 'from-emerald-500 to-emerald-600',
      bgColor: 'bg-emerald-50 dark:bg-emerald-900/20',
      category: 'recipes'
    },
    {
      id: 'recipe-calculator',
      icon: ChefHat,
      color: 'from-amber-500 to-amber-600',
      bgColor: 'bg-amber-50 dark:bg-amber-900/20',
      category: 'recipes'
    },
    {
      id: 'meal-planner',
      icon: Calendar,
      color: 'from-rose-500 to-rose-600',
      bgColor: 'bg-rose-50 dark:bg-rose-900/20',
      category: 'recipes'
    },
    {
      id: 'recipe-filter',
      icon: Filter,
      color: 'from-sky-500 to-sky-600',
      bgColor: 'bg-sky-50 dark:bg-sky-900/20',
      category: 'recipes'
    },
    
    // Information Sections
    {
      id: 'articles',
      icon: FileText,
      color: 'from-slate-500 to-slate-600',
      bgColor: 'bg-slate-50 dark:bg-slate-900/20',
      category: 'info'
    },
    {
      id: 'tips',
      icon: Lightbulb,
      color: 'from-lime-500 to-lime-600',
      bgColor: 'bg-lime-50 dark:bg-lime-900/20',
      category: 'info'
    },
    {
      id: 'faq',
      icon: HelpCircle,
      color: 'from-fuchsia-500 to-fuchsia-600',
      bgColor: 'bg-fuchsia-50 dark:bg-fuchsia-900/20',
      category: 'info'
    },
    
    // Account Sections
    {
      id: 'user-profile',
      icon: User,
      color: 'from-gray-500 to-gray-600',
      bgColor: 'bg-gray-50 dark:bg-gray-900/20',
      category: 'account'
    },
    {
      id: 'preferences',
      icon: Settings,
      color: 'from-stone-500 to-stone-600',
      bgColor: 'bg-stone-50 dark:bg-stone-900/20',
      category: 'account'
    },
    {
      id: 'notifications',
      icon: Bell,
      color: 'from-zinc-500 to-zinc-600',
      bgColor: 'bg-zinc-50 dark:bg-zinc-900/20',
      category: 'account'
    }
  ]

  const categories = {
    basic: t('basic_calculators') || 'Basic Calculators',
    advanced: t('advanced_calculators') || 'Advanced Calculators',
    tracking: t('tracking_monitoring') || 'Tracking & Monitoring',
    recipes: t('recipes_meals') || 'Recipes & Meals',
    info: t('information_support') || 'Information & Support',
    account: t('account_settings') || 'Account & Settings'
  }

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.5
      }
    }
  }

  const groupedSections = sections.reduce((acc, section) => {
    if (!acc[section.category]) {
      acc[section.category] = []
    }
    acc[section.category].push(section)
    return acc
  }, {})

  return (
    <div className="space-y-12">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="text-center space-y-4"
      >
        <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
          {t('sections_title')}
        </h1>
        <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
          {t('sections_subtitle')}
        </p>
      </motion.div>

      {/* Sections Grid with Category Headers */}
      <motion.div
        initial="hidden"
        animate="visible"
        variants={containerVariants}
        className="space-y-10"
      >
        {Object.entries(groupedSections).map(([category, categorySections]) => (
          <motion.div
            key={category}
            variants={containerVariants}
            className="space-y-6"
          >
            {/* Category Header */}
            <motion.div
              variants={itemVariants}
              className="flex items-center gap-4"
            >
              <h2 className="text-xl md:text-2xl font-bold text-gray-800 dark:text-gray-200">
                {categories[category]}
              </h2>
              <div className="flex-1 h-0.5 bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500 opacity-30"></div>
            </motion.div>
            
            {/* Category Sections */}
            <motion.div
              variants={containerVariants}
              className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4 md:gap-6"
            >
              {categorySections.map((section) => {
                const IconComponent = section.icon
                return (
                  <motion.div
                    key={section.id}
                    variants={itemVariants}
                    whileHover={{ scale: 1.05, y: -5 }}
                    whileTap={{ scale: 0.95 }}
                    className="cursor-pointer"
                    onClick={() => onSectionChange(section.id)}
                  >
                    <Card className={`h-full enhanced-card hover:shadow-2xl transition-all duration-300 ${section.bgColor} border-0 aspect-square`}>
                      <CardContent className="p-4 md:p-6 text-center space-y-3 flex flex-col justify-center h-full">
                        <div className={`w-12 h-12 md:w-16 md:h-16 mx-auto rounded-2xl bg-gradient-to-br ${section.color} flex items-center justify-center shadow-lg`}>
                          <IconComponent className="h-6 w-6 md:h-8 md:w-8 text-white" />
                        </div>
                        
                        <div className="space-y-1">
                          <h3 className="font-bold text-sm md:text-base text-gray-800 dark:text-gray-200 leading-tight">
                            {t(section.id.replace('-', '_'))}
                          </h3>
                          <p className="text-xs text-gray-600 dark:text-gray-400 leading-relaxed line-clamp-2">
                            {t(section.id.replace('-', '_') + '_desc')}
                          </p>
                        </div>
                        
                        <div className={`w-full h-1 bg-gradient-to-r ${section.color} rounded-full opacity-60`}></div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </motion.div>
          </motion.div>
        ))}
      </motion.div>
    </div>
  )
}

export default HomePage

