import React, { useState, useEffect } from 'react';
import { useTranslation } from '../hooks/use-translation';
import { useSettings } from '../hooks/use-settings';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx';
import { Input } from '@/components/ui/input.jsx';
import { Label } from '@/components/ui/label.jsx';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx';
import { Button } from '@/components/ui/button.jsx';
import { ArrowRight, ArrowLeft, RefreshCw } from 'lucide-react';

const UnitConverter = ({ language }) => {
  const t = useTranslation(language);
  const { convertValue } = useSettings(language);
  
  const [conversionType, setConversionType] = useState('weight');
  const [fromUnit, setFromUnit] = useState('kg');
  const [toUnit, setToUnit] = useState('lb');
  const [fromValue, setFromValue] = useState('');
  const [toValue, setToValue] = useState('');
  const [direction, setDirection] = useState('forward'); // 'forward' or 'backward'

  // تحديث وحدات القياس عند تغيير نوع التحويل
  useEffect(() => {
    switch (conversionType) {
      case 'weight':
        setFromUnit('kg');
        setToUnit('lb');
        break;
      case 'height':
        setFromUnit('cm');
        setToUnit('ft');
        break;
      case 'distance':
        setFromUnit('km');
        setToUnit('mi');
        break;
      case 'volume':
        setFromUnit('ml');
        setToUnit('oz');
        break;
      case 'temperature':
        setFromUnit('celsius');
        setToUnit('fahrenheit');
        break;
      default:
        break;
    }
    setFromValue('');
    setToValue('');
  }, [conversionType]);

  // تحويل القيمة
  const convert = () => {
    if (!fromValue || isNaN(fromValue)) return;
    
    const value = parseFloat(fromValue);
    const result = direction === 'forward' 
      ? convertValue(value, fromUnit, toUnit)
      : convertValue(value, toUnit, fromUnit);
    
    if (direction === 'forward') {
      setToValue(result.toFixed(2));
    } else {
      setFromValue(result.toFixed(2));
    }
  };

  // تبديل اتجاه التحويل
  const swapDirection = () => {
    setDirection(prev => prev === 'forward' ? 'backward' : 'forward');
    setFromValue('');
    setToValue('');
  };

  // الحصول على وحدات القياس المتاحة لنوع التحويل المحدد
  const getUnitOptions = () => {
    switch (conversionType) {
      case 'weight':
        return [
          { value: 'kg', label: t.settings.kg },
          { value: 'lb', label: t.settings.lb }
        ];
      case 'height':
        return [
          { value: 'cm', label: t.settings.cm },
          { value: 'm', label: t.settings.m },
          { value: 'ft', label: t.settings.ft },
          { value: 'in', label: t.settings.in }
        ];
      case 'distance':
        return [
          { value: 'km', label: t.settings.km },
          { value: 'mi', label: t.settings.mi }
        ];
      case 'volume':
        return [
          { value: 'ml', label: t.settings.ml },
          { value: 'l', label: t.settings.l },
          { value: 'oz', label: t.settings.oz },
          { value: 'cup', label: t.settings.cup }
        ];
      case 'temperature':
        return [
          { value: 'celsius', label: t.settings.celsius },
          { value: 'fahrenheit', label: t.settings.fahrenheit }
        ];
      default:
        return [];
    }
  };

  const unitOptions = getUnitOptions();

  return (
    <Card className="enhanced-card">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold text-gray-800 dark:text-gray-200">
          {t.converter ? t.converter.title : 'Unit Converter'}
        </CardTitle>
        <CardDescription className="text-gray-600 dark:text-gray-400">
          {t.converter ? t.converter.description : 'Convert between different units of measurement'}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="space-y-3">
          <Label htmlFor="conversionType" className="text-gray-700 dark:text-gray-200 font-semibold">
            {t.converter ? t.converter.type : 'Conversion Type'}
          </Label>
          <Select value={conversionType} onValueChange={setConversionType}>
            <SelectTrigger className="enhanced-input text-lg py-4">
              <SelectValue placeholder={t.converter ? t.converter.select_type : 'Select conversion type'} />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="weight">{t.converter ? t.converter.weight : 'Weight'}</SelectItem>
              <SelectItem value="height">{t.converter ? t.converter.height : 'Height'}</SelectItem>
              <SelectItem value="distance">{t.converter ? t.converter.distance : 'Distance'}</SelectItem>
              <SelectItem value="volume">{t.converter ? t.converter.volume : 'Volume'}</SelectItem>
              <SelectItem value="temperature">{t.converter ? t.converter.temperature : 'Temperature'}</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-7 gap-4 items-center">
          <div className="md:col-span-3 space-y-3">
            <Label htmlFor="fromUnit" className="text-gray-700 dark:text-gray-200 font-semibold">
              {direction === 'forward' 
                ? (t.converter ? t.converter.from : 'From') 
                : (t.converter ? t.converter.to : 'To')}
            </Label>
            <Select value={fromUnit} onValueChange={setFromUnit}>
              <SelectTrigger className="enhanced-input text-lg py-4">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {unitOptions.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input
              type="number"
              value={fromValue}
              onChange={(e) => {
                setFromValue(e.target.value);
                if (direction === 'backward' && e.target.value) {
                  const value = parseFloat(e.target.value);
                  const result = convertValue(value, toUnit, fromUnit);
                  setToValue(result.toFixed(2));
                }
              }}
              placeholder="0"
              className="enhanced-input text-lg py-4 text-center"
            />
          </div>

          <div className="md:col-span-1 flex justify-center">
            <Button
              variant="ghost"
              size="icon"
              onClick={swapDirection}
              className="enhanced-button-ghost p-3 rounded-full"
            >
              {language === 'ar' ? <ArrowLeft className="h-6 w-6" /> : <ArrowRight className="h-6 w-6" />}
            </Button>
          </div>

          <div className="md:col-span-3 space-y-3">
            <Label htmlFor="toUnit" className="text-gray-700 dark:text-gray-200 font-semibold">
              {direction === 'forward' 
                ? (t.converter ? t.converter.to : 'To') 
                : (t.converter ? t.converter.from : 'From')}
            </Label>
            <Select value={toUnit} onValueChange={setToUnit}>
              <SelectTrigger className="enhanced-input text-lg py-4">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {unitOptions.map(option => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Input
              type="number"
              value={toValue}
              onChange={(e) => {
                setToValue(e.target.value);
                if (direction === 'forward' && e.target.value) {
                  const value = parseFloat(e.target.value);
                  const result = convertValue(value, toUnit, fromUnit);
                  setFromValue(result.toFixed(2));
                }
              }}
              placeholder="0"
              className="enhanced-input text-lg py-4 text-center"
            />
          </div>
        </div>

        <Button 
          onClick={convert}
          className="w-full enhanced-button text-lg py-6 font-semibold"
        >
          <RefreshCw className="mr-2 h-5 w-5" />
          {t.converter ? t.converter.convert : 'Convert'}
        </Button>
      </CardContent>
    </Card>
  );
};

export default UnitConverter;

