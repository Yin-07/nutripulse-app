import React, { useState, useEffect } from 'react';
import { useTranslation } from '../hooks/use-translation';

const Settings = ({ language }) => {
  const t = useTranslation(language);
  
  // استرجاع الإعدادات من التخزين المحلي أو استخدام القيم الافتراضية
  const [settings, setSettings] = useState(() => {
    const savedSettings = localStorage.getItem('settings');
    return savedSettings ? JSON.parse(savedSettings) : {
      weightUnit: 'kg',
      heightUnit: 'cm',
      distanceUnit: 'km',
      volumeUnit: 'ml',
      temperatureUnit: 'celsius',
      theme: 'light',
      fontSize: 'medium',
      notifications: true,
      autoSave: true,
      language: language || 'ar'
    };
  });

  // حفظ الإعدادات في التخزين المحلي عند تغييرها
  useEffect(() => {
    localStorage.setItem('settings', JSON.stringify(settings));
  }, [settings]);

  // تحديث الإعدادات
  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;
    setSettings({
      ...settings,
      [name]: type === 'checkbox' ? checked : value
    });
  };

  // تطبيق السمة (الوضع الداكن/الفاتح)
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', settings.theme);
  }, [settings.theme]);

  // تطبيق حجم الخط
  useEffect(() => {
    document.documentElement.style.fontSize = 
      settings.fontSize === 'small' ? '14px' : 
      settings.fontSize === 'medium' ? '16px' : '18px';
  }, [settings.fontSize]);

  // إعادة تعيين الإعدادات إلى القيم الافتراضية
  const resetSettings = () => {
    const defaultSettings = {
      weightUnit: 'kg',
      heightUnit: 'cm',
      distanceUnit: 'km',
      volumeUnit: 'ml',
      temperatureUnit: 'celsius',
      theme: 'light',
      fontSize: 'medium',
      notifications: true,
      autoSave: true,
      language: language || 'ar'
    };
    setSettings(defaultSettings);
  };

  return (
    <div className="settings-container">
      <h2 className="settings-title">{t.settings.title}</h2>
      <p className="settings-description">{t.settings.description}</p>

      <div className="settings-section">
        <h3>{t.settings.units}</h3>
        
        <div className="setting-item">
          <label htmlFor="weightUnit">{t.settings.weightUnit}</label>
          <select 
            id="weightUnit" 
            name="weightUnit" 
            value={settings.weightUnit} 
            onChange={handleChange}
          >
            <option value="kg">{t.settings.kg}</option>
            <option value="lb">{t.settings.lb}</option>
          </select>
        </div>

        <div className="setting-item">
          <label htmlFor="heightUnit">{t.settings.heightUnit}</label>
          <select 
            id="heightUnit" 
            name="heightUnit" 
            value={settings.heightUnit} 
            onChange={handleChange}
          >
            <option value="cm">{t.settings.cm}</option>
            <option value="m">{t.settings.m}</option>
            <option value="ft">{t.settings.ft}</option>
            <option value="in">{t.settings.in}</option>
          </select>
        </div>

        <div className="setting-item">
          <label htmlFor="distanceUnit">{t.settings.distanceUnit}</label>
          <select 
            id="distanceUnit" 
            name="distanceUnit" 
            value={settings.distanceUnit} 
            onChange={handleChange}
          >
            <option value="km">{t.settings.km}</option>
            <option value="mi">{t.settings.mi}</option>
          </select>
        </div>

        <div className="setting-item">
          <label htmlFor="volumeUnit">{t.settings.volumeUnit}</label>
          <select 
            id="volumeUnit" 
            name="volumeUnit" 
            value={settings.volumeUnit} 
            onChange={handleChange}
          >
            <option value="ml">{t.settings.ml}</option>
            <option value="l">{t.settings.l}</option>
            <option value="oz">{t.settings.oz}</option>
            <option value="cup">{t.settings.cup}</option>
          </select>
        </div>

        <div className="setting-item">
          <label htmlFor="temperatureUnit">{t.settings.temperatureUnit}</label>
          <select 
            id="temperatureUnit" 
            name="temperatureUnit" 
            value={settings.temperatureUnit} 
            onChange={handleChange}
          >
            <option value="celsius">{t.settings.celsius}</option>
            <option value="fahrenheit">{t.settings.fahrenheit}</option>
          </select>
        </div>
      </div>

      <div className="settings-section">
        <h3>{t.settings.appearance}</h3>
        
        <div className="setting-item">
          <label htmlFor="theme">{t.settings.theme}</label>
          <select 
            id="theme" 
            name="theme" 
            value={settings.theme} 
            onChange={handleChange}
          >
            <option value="light">{t.settings.light}</option>
            <option value="dark">{t.settings.dark}</option>
            <option value="auto">{t.settings.auto}</option>
          </select>
        </div>

        <div className="setting-item">
          <label htmlFor="fontSize">{t.settings.fontSize}</label>
          <select 
            id="fontSize" 
            name="fontSize" 
            value={settings.fontSize} 
            onChange={handleChange}
          >
            <option value="small">{t.settings.small}</option>
            <option value="medium">{t.settings.medium}</option>
            <option value="large">{t.settings.large}</option>
          </select>
        </div>
      </div>

      <div className="settings-section">
        <h3>{t.settings.preferences}</h3>
        
        <div className="setting-item checkbox">
          <input 
            type="checkbox" 
            id="notifications" 
            name="notifications" 
            checked={settings.notifications} 
            onChange={handleChange}
          />
          <label htmlFor="notifications">{t.settings.notifications}</label>
        </div>

        <div className="setting-item checkbox">
          <input 
            type="checkbox" 
            id="autoSave" 
            name="autoSave" 
            checked={settings.autoSave} 
            onChange={handleChange}
          />
          <label htmlFor="autoSave">{t.settings.autoSave}</label>
        </div>
      </div>

      <div className="settings-actions">
        <button 
          className="reset-button" 
          onClick={resetSettings}
        >
          {t.settings.reset}
        </button>
        <button 
          className="save-button"
          onClick={() => alert(t.settings.savedMessage)}
        >
          {t.settings.save}
        </button>
      </div>
    </div>
  );
};

export default Settings;

