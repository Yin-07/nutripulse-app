import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Zap, Calculator, User, Scale, Ruler, Activity } from 'lucide-react';

const MetabolicRate = () => {
  const [formData, setFormData] = useState({
    age: '',
    gender: '',
    weight: '',
    height: '',
    activityLevel: '',
    bodyFat: ''
  });

  const [result, setResult] = useState(null);
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.age || formData.age < 1 || formData.age > 120) {
      newErrors.age = 'يرجى إدخال عمر صحيح بين 1-120 سنة';
    }
    
    if (!formData.gender) {
      newErrors.gender = 'يرجى اختيار الجنس';
    }
    
    if (!formData.weight || formData.weight < 5 || formData.weight > 300) {
      newErrors.weight = 'يرجى إدخال وزن صحيح بين 5-300 كجم';
    }
    
    if (!formData.height || formData.height < 50 || formData.height > 250) {
      newErrors.height = 'يرجى إدخال طول صحيح بين 50-250 سم';
    }
    
    if (!formData.activityLevel) {
      newErrors.activityLevel = 'يرجى اختيار مستوى النشاط';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const calculateMetabolicRate = () => {
    if (!validateForm()) return;

    const { age, gender, weight, height, activityLevel, bodyFat } = formData;
    const ageNum = parseFloat(age);
    const weightNum = parseFloat(weight);
    const heightNum = parseFloat(height);
    const bodyFatNum = bodyFat ? parseFloat(bodyFat) : null;

    let bmr;

    // حساب BMR باستخدام عدة معادلات
    
    // 1. معادلة Mifflin-St Jeor (الأكثر دقة للبالغين)
    let mifflinBMR;
    if (ageNum >= 18) {
      if (gender === 'male') {
        mifflinBMR = 10 * weightNum + 6.25 * heightNum - 5 * ageNum + 5;
      } else {
        mifflinBMR = 10 * weightNum + 6.25 * heightNum - 5 * ageNum - 161;
      }
    } else {
      // معادلات خاصة للأطفال والمراهقين
      if (gender === 'male') {
        if (ageNum >= 10 && ageNum <= 17) {
          mifflinBMR = 17.5 * weightNum + 651;
        } else if (ageNum >= 3 && ageNum <= 9) {
          mifflinBMR = 22.7 * weightNum + 495;
        } else {
          mifflinBMR = 60.9 * weightNum - 54;
        }
      } else {
        if (ageNum >= 10 && ageNum <= 17) {
          mifflinBMR = 12.2 * weightNum + 746;
        } else if (ageNum >= 3 && ageNum <= 9) {
          mifflinBMR = 22.5 * weightNum + 499;
        } else {
          mifflinBMR = 61.0 * weightNum - 51;
        }
      }
    }

    // 2. معادلة Harris-Benedict المحدثة
    let harrisBMR;
    if (gender === 'male') {
      harrisBMR = 88.362 + (13.397 * weightNum) + (4.799 * heightNum) - (5.677 * ageNum);
    } else {
      harrisBMR = 447.593 + (9.247 * weightNum) + (3.098 * heightNum) - (4.330 * ageNum);
    }

    // 3. معادلة Katch-McArdle (إذا كانت نسبة الدهون متوفرة)
    let katchBMR = null;
    if (bodyFatNum && bodyFatNum > 0 && bodyFatNum < 50) {
      const leanBodyMass = weightNum * (1 - bodyFatNum / 100);
      katchBMR = 370 + (21.6 * leanBodyMass);
    }

    // استخدام متوسط المعادلات أو الأكثر دقة
    if (katchBMR) {
      bmr = katchBMR; // الأكثر دقة إذا كانت نسبة الدهون متوفرة
    } else {
      bmr = mifflinBMR; // الأكثر دقة للاستخدام العام
    }

    // معاملات النشاط
    const activityFactors = {
      sedentary: { factor: 1.2, name: 'قليل الحركة (عمل مكتبي)' },
      light: { factor: 1.375, name: 'نشاط خفيف (تمارين 1-3 أيام/أسبوع)' },
      moderate: { factor: 1.55, name: 'نشاط متوسط (تمارين 3-5 أيام/أسبوع)' },
      active: { factor: 1.725, name: 'نشاط عالي (تمارين 6-7 أيام/أسبوع)' },
      very_active: { factor: 1.9, name: 'نشاط عالي جداً (تمارين مكثفة يومياً)' }
    };

    const activityFactor = activityFactors[activityLevel];
    const tdee = bmr * activityFactor.factor;

    // حساب احتياجات المغذيات الكبرى
    const proteinCalories = weightNum * 2.2 * 4; // 2.2 جرام بروتين لكل كيلو × 4 سعرات لكل جرام
    const fatCalories = tdee * 0.25; // 25% من إجمالي السعرات
    const carbCalories = tdee - proteinCalories - fatCalories;

    const macros = {
      protein: Math.round(proteinCalories / 4),
      fat: Math.round(fatCalories / 9),
      carbs: Math.round(carbCalories / 4)
    };

    // أهداف مختلفة للوزن
    const weightGoals = {
      maintain: Math.round(tdee),
      lose: Math.round(tdee - 500), // نقص 500 سعرة = فقدان 0.5 كجم/أسبوع
      gain: Math.round(tdee + 500)  // زيادة 500 سعرة = زيادة 0.5 كجم/أسبوع
    };

    setResult({
      bmr: Math.round(bmr),
      tdee: Math.round(tdee),
      activityFactor,
      macros,
      weightGoals,
      mifflinBMR: Math.round(mifflinBMR),
      harrisBMR: Math.round(harrisBMR),
      katchBMR: katchBMR ? Math.round(katchBMR) : null
    });
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-8"
    >
      {/* العنوان */}
      <div className="text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-yellow-500 to-orange-500 rounded-full mb-4"
        >
          <Zap className="h-8 w-8 text-white" />
        </motion.div>
        <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-100 mb-2">
          حاسبة معدل الأيض الأساسي
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          احسب معدل الأيض الأساسي والسعرات المطلوبة يومياً
        </p>
      </div>

      {/* النموذج */}
      <div className="enhanced-card rounded-2xl p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* العمر */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <User className="h-4 w-4" />
              العمر (سنة)
            </label>
            <input
              type="number"
              value={formData.age}
              onChange={(e) => handleInputChange('age', e.target.value)}
              placeholder="مثال: 30"
              className="enhanced-input"
            />
            {errors.age && <p className="text-red-500 text-sm">{errors.age}</p>}
          </div>

          {/* الجنس */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <User className="h-4 w-4" />
              الجنس
            </label>
            <select
              value={formData.gender}
              onChange={(e) => handleInputChange('gender', e.target.value)}
              className="enhanced-input"
            >
              <option value="">اختر الجنس</option>
              <option value="male">ذكر</option>
              <option value="female">أنثى</option>
            </select>
            {errors.gender && <p className="text-red-500 text-sm">{errors.gender}</p>}
          </div>

          {/* الوزن */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <Scale className="h-4 w-4" />
              الوزن (كجم)
            </label>
            <input
              type="number"
              value={formData.weight}
              onChange={(e) => handleInputChange('weight', e.target.value)}
              placeholder="مثال: 70"
              className="enhanced-input"
            />
            {errors.weight && <p className="text-red-500 text-sm">{errors.weight}</p>}
          </div>

          {/* الطول */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <Ruler className="h-4 w-4" />
              الطول (سم)
            </label>
            <input
              type="number"
              value={formData.height}
              onChange={(e) => handleInputChange('height', e.target.value)}
              placeholder="مثال: 175"
              className="enhanced-input"
            />
            {errors.height && <p className="text-red-500 text-sm">{errors.height}</p>}
          </div>

          {/* مستوى النشاط */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <Activity className="h-4 w-4" />
              مستوى النشاط البدني
            </label>
            <select
              value={formData.activityLevel}
              onChange={(e) => handleInputChange('activityLevel', e.target.value)}
              className="enhanced-input"
            >
              <option value="">اختر مستوى النشاط</option>
              <option value="sedentary">قليل الحركة (عمل مكتبي)</option>
              <option value="light">نشاط خفيف (1-3 أيام/أسبوع)</option>
              <option value="moderate">نشاط متوسط (3-5 أيام/أسبوع)</option>
              <option value="active">نشاط عالي (6-7 أيام/أسبوع)</option>
              <option value="very_active">نشاط عالي جداً (يومياً)</option>
            </select>
            {errors.activityLevel && <p className="text-red-500 text-sm">{errors.activityLevel}</p>}
          </div>

          {/* نسبة الدهون (اختيارية) */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <Zap className="h-4 w-4" />
              نسبة الدهون % (اختيارية)
            </label>
            <input
              type="number"
              value={formData.bodyFat}
              onChange={(e) => handleInputChange('bodyFat', e.target.value)}
              placeholder="مثال: 15"
              className="enhanced-input"
            />
            <p className="text-xs text-gray-500 dark:text-gray-400">
              لحساب أكثر دقة (يمكن تركها فارغة)
            </p>
          </div>
        </div>

        {/* زر الحساب */}
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={calculateMetabolicRate}
          className="w-full enhanced-button bg-gradient-to-r from-yellow-500 to-orange-500 hover:from-yellow-600 hover:to-orange-600 text-white py-4 rounded-xl font-semibold text-lg flex items-center justify-center gap-2"
        >
          <Calculator className="h-5 w-5" />
          احسب معدل الأيض
        </motion.button>
      </div>

      {/* النتائج */}
      {result && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="space-y-6"
        >
          {/* النتائج الأساسية */}
          <div className="enhanced-card rounded-2xl p-8">
            <h3 className="text-2xl font-bold text-center text-gray-800 dark:text-gray-100 mb-6">
              نتائج معدل الأيض
            </h3>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {/* BMR */}
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-6 text-center">
                <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
                  {result.bmr}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  معدل الأيض الأساسي (BMR)
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                  السعرات المطلوبة للوظائف الحيوية
                </div>
              </div>

              {/* TDEE */}
              <div className="bg-green-50 dark:bg-green-900/20 rounded-xl p-6 text-center">
                <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">
                  {result.tdee}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  إجمالي السعرات اليومية (TDEE)
                </div>
                <div className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                  مع النشاط البدني: {result.activityFactor.name}
                </div>
              </div>
            </div>
          </div>

          {/* أهداف الوزن */}
          <div className="enhanced-card rounded-2xl p-8">
            <h4 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4">
              السعرات حسب الهدف
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-red-50 dark:bg-red-900/20 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-red-600 dark:text-red-400">
                  {result.weightGoals.lose}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">فقدان الوزن</div>
                <div className="text-xs text-gray-500 dark:text-gray-500">-0.5 كجم/أسبوع</div>
              </div>
              <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                  {result.weightGoals.maintain}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">الحفاظ على الوزن</div>
                <div className="text-xs text-gray-500 dark:text-gray-500">وزن ثابت</div>
              </div>
              <div className="bg-green-50 dark:bg-green-900/20 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {result.weightGoals.gain}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">زيادة الوزن</div>
                <div className="text-xs text-gray-500 dark:text-gray-500">+0.5 كجم/أسبوع</div>
              </div>
            </div>
          </div>

          {/* المغذيات الكبرى */}
          <div className="enhanced-card rounded-2xl p-8">
            <h4 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4">
              توزيع المغذيات الكبرى (للحفاظ على الوزن)
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-purple-50 dark:bg-purple-900/20 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-purple-600 dark:text-purple-400">
                  {result.macros.protein}g
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">البروتين</div>
                <div className="text-xs text-gray-500 dark:text-gray-500">
                  {Math.round((result.macros.protein * 4 / result.tdee) * 100)}% من السعرات
                </div>
              </div>
              <div className="bg-yellow-50 dark:bg-yellow-900/20 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-yellow-600 dark:text-yellow-400">
                  {result.macros.fat}g
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">الدهون</div>
                <div className="text-xs text-gray-500 dark:text-gray-500">
                  {Math.round((result.macros.fat * 9 / result.tdee) * 100)}% من السعرات
                </div>
              </div>
              <div className="bg-orange-50 dark:bg-orange-900/20 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold text-orange-600 dark:text-orange-400">
                  {result.macros.carbs}g
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">الكربوهيدرات</div>
                <div className="text-xs text-gray-500 dark:text-gray-500">
                  {Math.round((result.macros.carbs * 4 / result.tdee) * 100)}% من السعرات
                </div>
              </div>
            </div>
          </div>

          {/* مقارنة المعادلات */}
          <div className="enhanced-card rounded-2xl p-8">
            <h4 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-4">
              مقارنة معادلات BMR
            </h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 text-center">
                <div className="text-xl font-bold text-gray-700 dark:text-gray-300">
                  {result.mifflinBMR}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Mifflin-St Jeor</div>
                <div className="text-xs text-gray-500 dark:text-gray-500">الأكثر دقة</div>
              </div>
              <div className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 text-center">
                <div className="text-xl font-bold text-gray-700 dark:text-gray-300">
                  {result.harrisBMR}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Harris-Benedict</div>
                <div className="text-xs text-gray-500 dark:text-gray-500">معادلة كلاسيكية</div>
              </div>
              {result.katchBMR && (
                <div className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 text-center">
                  <div className="text-xl font-bold text-gray-700 dark:text-gray-300">
                    {result.katchBMR}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">Katch-McArdle</div>
                  <div className="text-xs text-gray-500 dark:text-gray-500">بناءً على نسبة الدهون</div>
                </div>
              )}
            </div>
          </div>

          {/* نصائح */}
          <div className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-6">
            <h4 className="font-semibold text-gray-800 dark:text-gray-100 mb-3">نصائح مهمة:</h4>
            <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
              <li>• هذه النتائج تقديرية وقد تختلف حسب عوامل فردية</li>
              <li>• راقب وزنك وطاقتك لتعديل السعرات حسب الحاجة</li>
              <li>• شرب الماء الكافي يساعد في تحسين الأيض</li>
              <li>• النوم الجيد (7-9 ساعات) مهم لصحة الأيض</li>
              <li>• التمارين الرياضية تزيد من معدل الأيض</li>
            </ul>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default MetabolicRate;

