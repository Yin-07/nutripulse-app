import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Activity, User, Ruler, Scale } from 'lucide-react';

const BMICalculator = () => {
  const [formData, setFormData] = useState({
    height: '',
    weight: '',
    age: '',
    gender: ''
  });
  const [results, setResults] = useState(null);
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.height || formData.height < 100 || formData.height > 250) {
      newErrors.height = 'يرجى إدخال طول صحيح بين 100-250 سم';
    }
    
    if (!formData.weight || formData.weight < 5 || formData.weight > 300) {
      newErrors.weight = 'يرجى إدخال وزن صحيح بين 5-300 كجم';
    }
    
    if (!formData.age || formData.age < 1 || formData.age > 120) {
      newErrors.age = 'يرجى إدخال عمر صحيح بين 1-120 سنة';
    }
    
    if (!formData.gender) {
      newErrors.gender = 'يرجى اختيار الجنس';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const getBMICategory = (bmi) => {
    if (bmi < 18.5) {
      return {
        category: 'نقص في الوزن',
        color: 'text-blue-600 dark:text-blue-400',
        bgColor: 'bg-blue-50 dark:bg-blue-900/20',
        advice: 'قد تحتاج إلى زيادة الوزن. استشر طبيبك أو أخصائي التغذية.'
      };
    } else if (bmi < 25) {
      return {
        category: 'وزن طبيعي',
        color: 'text-green-600 dark:text-green-400',
        bgColor: 'bg-green-50 dark:bg-green-900/20',
        advice: 'وزنك في النطاق الصحي. حافظ على نمط حياة صحي.'
      };
    } else if (bmi < 30) {
      return {
        category: 'زيادة في الوزن',
        color: 'text-yellow-600 dark:text-yellow-400',
        bgColor: 'bg-yellow-50 dark:bg-yellow-900/20',
        advice: 'قد تحتاج إلى فقدان بعض الوزن. اتبع نظاماً غذائياً متوازناً ومارس الرياضة.'
      };
    } else if (bmi < 35) {
      return {
        category: 'سمنة درجة أولى',
        color: 'text-orange-600 dark:text-orange-400',
        bgColor: 'bg-orange-50 dark:bg-orange-900/20',
        advice: 'يُنصح بفقدان الوزن. استشر طبيبك لوضع خطة مناسبة.'
      };
    } else if (bmi < 40) {
      return {
        category: 'سمنة درجة ثانية',
        color: 'text-red-600 dark:text-red-400',
        bgColor: 'bg-red-50 dark:bg-red-900/20',
        advice: 'سمنة متوسطة. من المهم استشارة طبيب مختص لوضع خطة علاجية.'
      };
    } else {
      return {
        category: 'سمنة مفرطة',
        color: 'text-red-800 dark:text-red-300',
        bgColor: 'bg-red-100 dark:bg-red-900/30',
        advice: 'سمنة مفرطة. يجب استشارة طبيب مختص فوراً لوضع خطة علاجية شاملة.'
      };
    }
  };

  const calculateBMI = () => {
    if (!validateForm()) return;

    const height = parseFloat(formData.height) / 100; // تحويل إلى متر
    const weight = parseFloat(formData.weight);
    const age = parseInt(formData.age);

    const bmi = weight / (height * height);
    const category = getBMICategory(bmi);

    // حساب الوزن المثالي للحصول على BMI صحي (22.5)
    const idealWeight = 22.5 * (height * height);
    const weightDifference = weight - idealWeight;

    setResults({
      bmi: Math.round(bmi * 10) / 10,
      category,
      idealWeight: Math.round(idealWeight * 10) / 10,
      weightDifference: Math.round(weightDifference * 10) / 10,
      height: formData.height,
      weight: formData.weight,
      age,
      gender: formData.gender
    });
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8"
      >
        <div className="flex items-center gap-3 mb-6">
          <Activity className="w-8 h-8 text-green-600" />
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">حاسبة مؤشر كتلة الجسم (BMI)</h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* نموذج الإدخال */}
          <div className="space-y-6">
            {/* الطول */}
            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <Ruler className="w-4 h-4" />
                الطول (سم)
              </label>
              <input
                type="number"
                value={formData.height}
                onChange={(e) => handleInputChange('height', e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                placeholder="مثال: 170"
              />
              {errors.height && (
                <p className="text-red-500 text-sm mt-1">{errors.height}</p>
              )}
            </div>

            {/* الوزن */}
            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <Scale className="w-4 h-4" />
                الوزن (كجم)
              </label>
              <input
                type="number"
                value={formData.weight}
                onChange={(e) => handleInputChange('weight', e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                placeholder="مثال: 70"
              />
              {errors.weight && (
                <p className="text-red-500 text-sm mt-1">{errors.weight}</p>
              )}
            </div>

            {/* العمر */}
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                العمر (سنة)
              </label>
              <input
                type="number"
                value={formData.age}
                onChange={(e) => handleInputChange('age', e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                placeholder="مثال: 30"
              />
              {errors.age && (
                <p className="text-red-500 text-sm mt-1">{errors.age}</p>
              )}
            </div>

            {/* الجنس */}
            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <User className="w-4 h-4" />
                الجنس
              </label>
              <select
                value={formData.gender}
                onChange={(e) => handleInputChange('gender', e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
              >
                <option value="">اختر الجنس</option>
                <option value="male">ذكر</option>
                <option value="female">أنثى</option>
              </select>
              {errors.gender && (
                <p className="text-red-500 text-sm mt-1">{errors.gender}</p>
              )}
            </div>

            <motion.button
              onClick={calculateBMI}
              className="w-full bg-gradient-to-r from-green-600 to-blue-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-green-700 hover:to-blue-700 transition-all duration-300 shadow-lg"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              احسب مؤشر كتلة الجسم
            </motion.button>
          </div>

          {/* النتائج */}
          {results && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-4">النتائج</h3>
              
              <div className="bg-gradient-to-r from-green-50 to-blue-50 dark:from-green-900/20 dark:to-blue-900/20 p-4 rounded-lg">
                <h4 className="font-semibold text-gray-800 dark:text-white mb-2">مؤشر كتلة الجسم</h4>
                <p className="text-3xl font-bold text-green-600 dark:text-green-400">{results.bmi}</p>
              </div>

              <div className={`${results.category.bgColor} p-4 rounded-lg`}>
                <h4 className="font-semibold text-gray-800 dark:text-white mb-2">التصنيف</h4>
                <p className={`text-xl font-bold ${results.category.color} mb-2`}>
                  {results.category.category}
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  {results.category.advice}
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                <h4 className="font-semibold text-gray-800 dark:text-white mb-2">الوزن المثالي</h4>
                <p className="text-lg text-gray-600 dark:text-gray-300 mb-1">
                  {results.idealWeight} كجم
                </p>
                <p className="text-sm text-gray-500 dark:text-gray-400">
                  {results.weightDifference > 0 
                    ? `تحتاج إلى فقدان ${Math.abs(results.weightDifference)} كجم`
                    : results.weightDifference < 0
                    ? `تحتاج إلى زيادة ${Math.abs(results.weightDifference)} كجم`
                    : 'وزنك مثالي!'
                  }
                </p>
              </div>

              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                <h4 className="font-semibold text-gray-800 dark:text-white mb-2">معلومات إضافية</h4>
                <div className="space-y-1 text-sm text-gray-600 dark:text-gray-300">
                  <p>• النطاق الصحي: 18.5 - 24.9</p>
                  <p>• مؤشر كتلة الجسم هو مقياس تقريبي</p>
                  <p>• لا يأخذ في الاعتبار كتلة العضلات</p>
                  <p>• استشر طبيبك للحصول على تقييم شامل</p>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default BMICalculator;

