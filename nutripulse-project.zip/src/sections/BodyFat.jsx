import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Percent, Calculator, User, Ruler, Scale } from 'lucide-react';

const BodyFat = () => {
  const [formData, setFormData] = useState({
    age: '',
    gender: '',
    weight: '',
    height: '',
    neck: '',
    waist: '',
    hip: ''
  });

  const [result, setResult] = useState(null);
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.age || formData.age < 1 || formData.age > 120) {
      newErrors.age = 'يرجى إدخال عمر صحيح بين 1-120 سنة';
    }
    
    if (!formData.gender) {
      newErrors.gender = 'يرجى اختيار الجنس';
    }
    
    if (!formData.weight || formData.weight < 5 || formData.weight > 300) {
      newErrors.weight = 'يرجى إدخال وزن صحيح بين 5-300 كجم';
    }
    
    if (!formData.height || formData.height < 50 || formData.height > 250) {
      newErrors.height = 'يرجى إدخال طول صحيح بين 50-250 سم';
    }
    
    if (!formData.neck || formData.neck < 20 || formData.neck > 60) {
      newErrors.neck = 'يرجى إدخال محيط الرقبة بين 20-60 سم';
    }
    
    if (!formData.waist || formData.waist < 50 || formData.waist > 200) {
      newErrors.waist = 'يرجى إدخال محيط الخصر بين 50-200 سم';
    }
    
    if (formData.gender === 'female' && (!formData.hip || formData.hip < 60 || formData.hip > 200)) {
      newErrors.hip = 'يرجى إدخال محيط الورك بين 60-200 سم';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const calculateBodyFat = () => {
    if (!validateForm()) return;

    const { age, gender, weight, height, neck, waist, hip } = formData;
    const ageNum = parseFloat(age);
    const weightNum = parseFloat(weight);
    const heightNum = parseFloat(height);
    const neckNum = parseFloat(neck);
    const waistNum = parseFloat(waist);
    const hipNum = parseFloat(hip);

    let bodyFatPercentage;

    // استخدام معادلة US Navy لحساب نسبة الدهون
    if (gender === 'male') {
      // للرجال: 495 / (1.0324 - 0.19077 * log10(waist - neck) + 0.15456 * log10(height)) - 450
      const logValue = Math.log10(waistNum - neckNum);
      const heightLog = Math.log10(heightNum);
      bodyFatPercentage = 495 / (1.0324 - 0.19077 * logValue + 0.15456 * heightLog) - 450;
    } else {
      // للنساء: 495 / (1.29579 - 0.35004 * log10(waist + hip - neck) + 0.22100 * log10(height)) - 450
      const logValue = Math.log10(waistNum + hipNum - neckNum);
      const heightLog = Math.log10(heightNum);
      bodyFatPercentage = 495 / (1.29579 - 0.35004 * logValue + 0.22100 * heightLog) - 450;
    }

    // تحديد التصنيف
    const getBodyFatCategory = (percentage, gender, age) => {
      let categories;
      
      if (gender === 'male') {
        if (age < 30) {
          categories = [
            { min: 0, max: 8, category: 'منخفض جداً', color: 'text-blue-600', bgColor: 'bg-blue-50' },
            { min: 8, max: 19, category: 'صحي', color: 'text-green-600', bgColor: 'bg-green-50' },
            { min: 19, max: 25, category: 'مقبول', color: 'text-yellow-600', bgColor: 'bg-yellow-50' },
            { min: 25, max: 100, category: 'مرتفع', color: 'text-red-600', bgColor: 'bg-red-50' }
          ];
        } else {
          categories = [
            { min: 0, max: 11, category: 'منخفض جداً', color: 'text-blue-600', bgColor: 'bg-blue-50' },
            { min: 11, max: 22, category: 'صحي', color: 'text-green-600', bgColor: 'bg-green-50' },
            { min: 22, max: 27, category: 'مقبول', color: 'text-yellow-600', bgColor: 'bg-yellow-50' },
            { min: 27, max: 100, category: 'مرتفع', color: 'text-red-600', bgColor: 'bg-red-50' }
          ];
        }
      } else {
        if (age < 30) {
          categories = [
            { min: 0, max: 14, category: 'منخفض جداً', color: 'text-blue-600', bgColor: 'bg-blue-50' },
            { min: 14, max: 21, category: 'صحي', color: 'text-green-600', bgColor: 'bg-green-50' },
            { min: 21, max: 33, category: 'مقبول', color: 'text-yellow-600', bgColor: 'bg-yellow-50' },
            { min: 33, max: 100, category: 'مرتفع', color: 'text-red-600', bgColor: 'bg-red-50' }
          ];
        } else {
          categories = [
            { min: 0, max: 16, category: 'منخفض جداً', color: 'text-blue-600', bgColor: 'bg-blue-50' },
            { min: 16, max: 25, category: 'صحي', color: 'text-green-600', bgColor: 'bg-green-50' },
            { min: 25, max: 35, category: 'مقبول', color: 'text-yellow-600', bgColor: 'bg-yellow-50' },
            { min: 35, max: 100, category: 'مرتفع', color: 'text-red-600', bgColor: 'bg-red-50' }
          ];
        }
      }

      return categories.find(cat => percentage >= cat.min && percentage < cat.max) || categories[categories.length - 1];
    };

    const category = getBodyFatCategory(bodyFatPercentage, gender, ageNum);
    
    // حساب كتلة الدهون وكتلة العضلات
    const fatMass = (bodyFatPercentage / 100) * weightNum;
    const leanMass = weightNum - fatMass;

    setResult({
      bodyFatPercentage: Math.round(bodyFatPercentage * 10) / 10,
      category,
      fatMass: Math.round(fatMass * 10) / 10,
      leanMass: Math.round(leanMass * 10) / 10
    });
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-8"
    >
      {/* العنوان */}
      <div className="text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-red-500 to-pink-500 rounded-full mb-4"
        >
          <Percent className="h-8 w-8 text-white" />
        </motion.div>
        <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-100 mb-2">
          حاسبة نسبة الدهون في الجسم
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          احسب نسبة الدهون في جسمك باستخدام قياسات الجسم
        </p>
      </div>

      {/* النموذج */}
      <div className="enhanced-card rounded-2xl p-8 space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* العمر */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <User className="h-4 w-4" />
              العمر (سنة)
            </label>
            <input
              type="number"
              value={formData.age}
              onChange={(e) => handleInputChange('age', e.target.value)}
              placeholder="مثال: 30"
              className="enhanced-input"
            />
            {errors.age && <p className="text-red-500 text-sm">{errors.age}</p>}
          </div>

          {/* الجنس */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <User className="h-4 w-4" />
              الجنس
            </label>
            <select
              value={formData.gender}
              onChange={(e) => handleInputChange('gender', e.target.value)}
              className="enhanced-input"
            >
              <option value="">اختر الجنس</option>
              <option value="male">ذكر</option>
              <option value="female">أنثى</option>
            </select>
            {errors.gender && <p className="text-red-500 text-sm">{errors.gender}</p>}
          </div>

          {/* الوزن */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <Scale className="h-4 w-4" />
              الوزن (كجم)
            </label>
            <input
              type="number"
              value={formData.weight}
              onChange={(e) => handleInputChange('weight', e.target.value)}
              placeholder="مثال: 70"
              className="enhanced-input"
            />
            {errors.weight && <p className="text-red-500 text-sm">{errors.weight}</p>}
          </div>

          {/* الطول */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <Ruler className="h-4 w-4" />
              الطول (سم)
            </label>
            <input
              type="number"
              value={formData.height}
              onChange={(e) => handleInputChange('height', e.target.value)}
              placeholder="مثال: 175"
              className="enhanced-input"
            />
            {errors.height && <p className="text-red-500 text-sm">{errors.height}</p>}
          </div>

          {/* محيط الرقبة */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <Ruler className="h-4 w-4" />
              محيط الرقبة (سم)
            </label>
            <input
              type="number"
              value={formData.neck}
              onChange={(e) => handleInputChange('neck', e.target.value)}
              placeholder="مثال: 38"
              className="enhanced-input"
            />
            {errors.neck && <p className="text-red-500 text-sm">{errors.neck}</p>}
          </div>

          {/* محيط الخصر */}
          <div className="space-y-2">
            <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
              <Ruler className="h-4 w-4" />
              محيط الخصر (سم)
            </label>
            <input
              type="number"
              value={formData.waist}
              onChange={(e) => handleInputChange('waist', e.target.value)}
              placeholder="مثال: 85"
              className="enhanced-input"
            />
            {errors.waist && <p className="text-red-500 text-sm">{errors.waist}</p>}
          </div>

          {/* محيط الورك (للنساء فقط) */}
          {formData.gender === 'female' && (
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                <Ruler className="h-4 w-4" />
                محيط الورك (سم)
              </label>
              <input
                type="number"
                value={formData.hip}
                onChange={(e) => handleInputChange('hip', e.target.value)}
                placeholder="مثال: 95"
                className="enhanced-input"
              />
              {errors.hip && <p className="text-red-500 text-sm">{errors.hip}</p>}
            </div>
          )}
        </div>

        {/* زر الحساب */}
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          onClick={calculateBodyFat}
          className="w-full enhanced-button bg-gradient-to-r from-red-500 to-pink-500 hover:from-red-600 hover:to-pink-600 text-white py-4 rounded-xl font-semibold text-lg flex items-center justify-center gap-2"
        >
          <Calculator className="h-5 w-5" />
          احسب نسبة الدهون
        </motion.button>
      </div>

      {/* النتائج */}
      {result && (
        <motion.div
          initial={{ opacity: 0, scale: 0.9 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.5 }}
          className="enhanced-card rounded-2xl p-8 space-y-6"
        >
          <h3 className="text-2xl font-bold text-center text-gray-800 dark:text-gray-100 mb-6">
            نتائج حساب نسبة الدهون
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* نسبة الدهون */}
            <div className={`${result.category.bgColor} dark:bg-opacity-20 rounded-xl p-6 text-center`}>
              <div className={`text-3xl font-bold ${result.category.color} mb-2`}>
                {result.bodyFatPercentage}%
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">نسبة الدهون</div>
              <div className={`text-sm font-medium ${result.category.color} mt-2`}>
                {result.category.category}
              </div>
            </div>

            {/* كتلة الدهون */}
            <div className="bg-orange-50 dark:bg-orange-900/20 rounded-xl p-6 text-center">
              <div className="text-3xl font-bold text-orange-600 dark:text-orange-400 mb-2">
                {result.fatMass}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">كتلة الدهون (كجم)</div>
            </div>

            {/* الكتلة الخالية من الدهون */}
            <div className="bg-blue-50 dark:bg-blue-900/20 rounded-xl p-6 text-center">
              <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
                {result.leanMass}
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">كتلة العضلات (كجم)</div>
            </div>

            {/* النسبة المئوية للعضلات */}
            <div className="bg-green-50 dark:bg-green-900/20 rounded-xl p-6 text-center">
              <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">
                {Math.round((100 - result.bodyFatPercentage) * 10) / 10}%
              </div>
              <div className="text-sm text-gray-600 dark:text-gray-400">نسبة العضلات</div>
            </div>
          </div>

          {/* نصائح */}
          <div className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-6">
            <h4 className="font-semibold text-gray-800 dark:text-gray-100 mb-3">نصائح مهمة:</h4>
            <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
              <li>• هذه النتائج تقديرية وقد تختلف حسب طريقة القياس</li>
              <li>• للحصول على قياسات دقيقة، استخدم شريط قياس مرن</li>
              <li>• قس محيط الخصر في أضيق نقطة</li>
              <li>• قس محيط الرقبة تحت تفاحة آدم مباشرة</li>
              <li>• للنساء: قسي محيط الورك في أوسع نقطة</li>
            </ul>
          </div>
        </motion.div>
      )}
    </motion.div>
  );
};

export default BodyFat;

