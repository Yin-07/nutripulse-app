import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Scan, Camera, X, Plus, Search, AlertCircle, Check, Loader2 } from 'lucide-react';
import Quagga from 'quagga';

const BarcodeScanner = () => {
  const [scanning, setScanning] = useState(false);
  const [scannedCode, setScannedCode] = useState(null);
  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [manualCode, setManualCode] = useState('');
  const [recentScans, setRecentScans] = useState(() => {
    const saved = localStorage.getItem('recentBarcodeScans');
    return saved ? JSON.parse(saved) : [];
  });
  const [addedToTracking, setAddedToTracking] = useState(false);
  
  const scannerRef = useRef(null);

  // حفظ عمليات المسح الأخيرة في localStorage
  useEffect(() => {
    localStorage.setItem('recentBarcodeScans', JSON.stringify(recentScans));
  }, [recentScans]);

  // تهيئة ماسح الباركود
  const initScanner = () => {
    if (scannerRef.current) {
      Quagga.init({
        inputStream: {
          name: "Live",
          type: "LiveStream",
          target: scannerRef.current,
          constraints: {
            width: 480,
            height: 320,
            facingMode: "environment"
          },
        },
        locator: {
          patchSize: "medium",
          halfSample: true
        },
        numOfWorkers: 2,
        decoder: {
          readers: ["ean_reader", "ean_8_reader", "upc_reader", "upc_e_reader"]
        },
        locate: true
      }, function(err) {
        if (err) {
          console.error(err);
          setError("لم نتمكن من الوصول إلى الكاميرا. يرجى التأكد من منح الإذن للكاميرا.");
          setScanning(false);
          return;
        }
        Quagga.start();
      });

      Quagga.onDetected((result) => {
        if (result.codeResult.code) {
          const code = result.codeResult.code;
          setScannedCode(code);
          stopScanner();
          fetchProductInfo(code);
        }
      });
    }
  };

  // إيقاف الماسح
  const stopScanner = () => {
    Quagga.stop();
    setScanning(false);
  };

  // البحث عن معلومات المنتج باستخدام الباركود
  const fetchProductInfo = async (code) => {
    setLoading(true);
    setError(null);
    
    try {
      // محاكاة لطلب API - في التطبيق الحقيقي، استبدل هذا بطلب API فعلي
      // مثال: const response = await fetch(`https://world.openfoodfacts.org/api/v0/product/${code}.json`);
      
      // للتجربة، سنستخدم بيانات وهمية
      await new Promise(resolve => setTimeout(resolve, 1500)); // تأخير لمحاكاة طلب الشبكة
      
      // تحقق من وجود المنتج في قاعدة البيانات المحلية
      const mockProducts = {
        '8410500001927': {
          name: 'كوكا كولا زيرو',
          brand: 'كوكا كولا',
          image: 'https://images.openfoodfacts.org/images/products/841/050/000/1927/front_en.3.400.jpg',
          nutritionFacts: {
            calories: 0,
            protein: 0,
            carbs: 0,
            fat: 0,
            sugar: 0,
            sodium: 0.04,
            servingSize: '330ml'
          }
        },
        '5449000000996': {
          name: 'كوكا كولا كلاسيك',
          brand: 'كوكا كولا',
          image: 'https://images.openfoodfacts.org/images/products/544/900/000/0996/front_en.429.400.jpg',
          nutritionFacts: {
            calories: 139,
            protein: 0,
            carbs: 35,
            fat: 0,
            sugar: 35,
            sodium: 0,
            servingSize: '330ml'
          }
        },
        '8410076481495': {
          name: 'لبن كامل الدسم',
          brand: 'المراعي',
          image: 'https://cdn.salla.sa/Aedxd/CDxAuFIeBnZJDxxDsLd7MdBJlnlLJwgGAEQGxBOB.png',
          nutritionFacts: {
            calories: 63,
            protein: 3.3,
            carbs: 4.8,
            fat: 3.6,
            sugar: 4.8,
            sodium: 0.05,
            servingSize: '100ml'
          }
        },
        '6281006429130': {
          name: 'زبادي طبيعي',
          brand: 'المراعي',
          image: 'https://cdnprod.mafretailproxy.com/sys-master-root/h42/h8f/9844124917790/480Wx480H_17358_main.jpg',
          nutritionFacts: {
            calories: 74,
            protein: 4.2,
            carbs: 5.6,
            fat: 3.8,
            sugar: 5.6,
            sodium: 0.06,
            servingSize: '100g'
          }
        }
      };
      
      if (mockProducts[code]) {
        setProduct(mockProducts[code]);
        
        // إضافة إلى عمليات المسح الأخيرة
        const newScan = {
          code,
          product: mockProducts[code],
          timestamp: new Date().toISOString()
        };
        
        setRecentScans(prev => {
          // تحقق من عدم وجود تكرار
          const exists = prev.some(scan => scan.code === code);
          if (exists) {
            return [newScan, ...prev.filter(scan => scan.code !== code)];
          } else {
            return [newScan, ...prev].slice(0, 10); // الاحتفاظ بآخر 10 عمليات مسح
          }
        });
      } else {
        setError("لم نتمكن من العثور على معلومات لهذا المنتج. يرجى التحقق من الرمز أو إدخال المعلومات يدوياً.");
      }
    } catch (err) {
      console.error(err);
      setError("حدث خطأ أثناء البحث عن معلومات المنتج. يرجى المحاولة مرة أخرى.");
    } finally {
      setLoading(false);
    }
  };

  // بدء المسح
  const startScanning = () => {
    setScanning(true);
    setScannedCode(null);
    setProduct(null);
    setError(null);
    setAddedToTracking(false);
    
    setTimeout(() => {
      initScanner();
    }, 100);
  };

  // البحث اليدوي عن الباركود
  const handleManualSearch = () => {
    if (manualCode.trim().length > 0) {
      setScannedCode(manualCode);
      fetchProductInfo(manualCode);
    }
  };

  // إضافة المنتج إلى تتبع التغذية
  const addToNutritionTracking = () => {
    if (!product) return;
    
    try {
      // الحصول على بيانات التتبع الحالية
      const savedData = localStorage.getItem('nutritionTracking');
      const allData = savedData ? JSON.parse(savedData) : {};
      
      // التاريخ الحالي
      const today = new Date().toISOString().split('T')[0];
      
      // إنشاء إدخال جديد
      const newEntry = {
        id: Date.now(),
        name: `${product.brand} ${product.name}`,
        quantity: 100, // الكمية الافتراضية
        calories: product.nutritionFacts.calories,
        protein: product.nutritionFacts.protein,
        carbs: product.nutritionFacts.carbs,
        fat: product.nutritionFacts.fat,
        time: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })
      };
      
      // إضافة الإدخال إلى اليوم الحالي
      const todayEntries = allData[today] || [];
      allData[today] = [...todayEntries, newEntry];
      
      // حفظ البيانات
      localStorage.setItem('nutritionTracking', JSON.stringify(allData));
      
      // تحديث حالة الإضافة
      setAddedToTracking(true);
      
      // إظهار رسالة نجاح
      setTimeout(() => {
        setAddedToTracking(false);
      }, 3000);
    } catch (err) {
      console.error(err);
      setError("حدث خطأ أثناء إضافة المنتج إلى التتبع. يرجى المحاولة مرة أخرى.");
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-8"
    >
      {/* العنوان */}
      <div className="text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-teal-500 to-emerald-500 rounded-full mb-4"
        >
          <Scan className="h-8 w-8 text-white" />
        </motion.div>
        <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-100 mb-2">
          ماسح الباركود للمنتجات الغذائية
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          امسح الباركود للحصول على معلومات التغذية للمنتجات
        </p>
      </div>

      {/* قسم المسح */}
      <div className="enhanced-card rounded-2xl p-8">
        {!scanning && !scannedCode && (
          <div className="text-center space-y-6">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={startScanning}
              className="enhanced-button bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-white px-8 py-4 rounded-xl font-semibold text-lg flex items-center gap-2 mx-auto"
            >
              <Camera className="h-5 w-5" />
              بدء مسح الباركود
            </motion.button>
            
            <div className="relative max-w-md mx-auto">
              <div className="flex">
                <input
                  type="text"
                  value={manualCode}
                  onChange={(e) => setManualCode(e.target.value)}
                  placeholder="أدخل رمز الباركود يدوياً..."
                  className="enhanced-input flex-1 pl-10"
                />
                <motion.button
                  whileHover={{ scale: 1.05 }}
                  whileTap={{ scale: 0.95 }}
                  onClick={handleManualSearch}
                  disabled={!manualCode.trim()}
                  className="enhanced-button bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg font-semibold mr-2 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Search className="h-5 w-5" />
                </motion.button>
              </div>
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
            </div>
          </div>
        )}

        {scanning && (
          <div className="space-y-4">
            <div className="relative">
              <div 
                ref={scannerRef} 
                className="w-full max-w-md mx-auto h-64 bg-black rounded-lg overflow-hidden"
              ></div>
              
              {/* إطار المسح المتحرك */}
              <motion.div
                className="absolute top-0 left-0 right-0 bottom-0 border-2 border-teal-500 rounded-lg pointer-events-none"
                animate={{
                  boxShadow: ['0 0 0 0 rgba(20, 184, 166, 0)', '0 0 0 10px rgba(20, 184, 166, 0.3)'],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  repeatType: "reverse"
                }}
              />
              
              {/* خط المسح المتحرك */}
              <motion.div
                className="absolute left-0 right-0 h-0.5 bg-teal-500 pointer-events-none"
                animate={{
                  top: ['10%', '90%'],
                }}
                transition={{
                  duration: 1.5,
                  repeat: Infinity,
                  repeatType: "reverse"
                }}
              />
            </div>
            
            <div className="text-center">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={stopScanner}
                className="enhanced-button bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg font-semibold"
              >
                <X className="h-5 w-5 mr-2" />
                إلغاء المسح
              </motion.button>
            </div>
          </div>
        )}

        {/* عرض نتائج المسح */}
        {scannedCode && (
          <div className="space-y-6">
            <div className="text-center">
              <div className="text-sm text-gray-500 dark:text-gray-400">رمز الباركود</div>
              <div className="text-xl font-semibold text-gray-800 dark:text-gray-200 flex items-center justify-center gap-2">
                {scannedCode}
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => {
                    setScannedCode(null);
                    setProduct(null);
                    setError(null);
                  }}
                  className="p-1 text-gray-500 hover:text-gray-700 dark:hover:text-gray-300"
                >
                  <X className="h-4 w-4" />
                </motion.button>
              </div>
            </div>

            {loading && (
              <div className="text-center py-8">
                <Loader2 className="h-12 w-12 text-teal-500 animate-spin mx-auto mb-4" />
                <p className="text-gray-600 dark:text-gray-400">جاري البحث عن معلومات المنتج...</p>
              </div>
            )}

            {error && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="bg-red-50 dark:bg-red-900/20 p-4 rounded-lg text-center"
              >
                <AlertCircle className="h-8 w-8 text-red-500 mx-auto mb-2" />
                <p className="text-red-600 dark:text-red-400">{error}</p>
              </motion.div>
            )}

            {product && (
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                className="space-y-6"
              >
                <div className="flex flex-col md:flex-row items-center gap-6">
                  {product.image && (
                    <div className="w-32 h-32 bg-white rounded-lg overflow-hidden flex items-center justify-center p-2">
                      <img 
                        src={product.image} 
                        alt={product.name} 
                        className="max-w-full max-h-full object-contain"
                      />
                    </div>
                  )}
                  
                  <div className="flex-1 text-center md:text-right">
                    <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100">
                      {product.name}
                    </h3>
                    <p className="text-gray-600 dark:text-gray-400">
                      {product.brand}
                    </p>
                    <p className="text-sm text-gray-500 dark:text-gray-500 mt-1">
                      حجم الحصة: {product.nutritionFacts.servingSize}
                    </p>
                  </div>
                </div>

                <div className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4">
                  <h4 className="font-semibold text-gray-800 dark:text-gray-100 mb-4 text-center">
                    القيم الغذائية
                  </h4>
                  
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    <div className="bg-white dark:bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-xl font-bold text-teal-600 dark:text-teal-400">
                        {product.nutritionFacts.calories}
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        السعرات الحرارية
                      </div>
                    </div>
                    
                    <div className="bg-white dark:bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-xl font-bold text-blue-600 dark:text-blue-400">
                        {product.nutritionFacts.protein}g
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        البروتين
                      </div>
                    </div>
                    
                    <div className="bg-white dark:bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-xl font-bold text-yellow-600 dark:text-yellow-400">
                        {product.nutritionFacts.carbs}g
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        الكربوهيدرات
                      </div>
                    </div>
                    
                    <div className="bg-white dark:bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-xl font-bold text-orange-600 dark:text-orange-400">
                        {product.nutritionFacts.fat}g
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        الدهون
                      </div>
                    </div>
                    
                    <div className="bg-white dark:bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-xl font-bold text-pink-600 dark:text-pink-400">
                        {product.nutritionFacts.sugar}g
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        السكر
                      </div>
                    </div>
                    
                    <div className="bg-white dark:bg-gray-700 p-3 rounded-lg text-center">
                      <div className="text-xl font-bold text-purple-600 dark:text-purple-400">
                        {product.nutritionFacts.sodium}g
                      </div>
                      <div className="text-sm text-gray-600 dark:text-gray-400">
                        الصوديوم
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex justify-center">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={addToNutritionTracking}
                    disabled={addedToTracking}
                    className={`enhanced-button ${
                      addedToTracking 
                        ? 'bg-green-500 text-white' 
                        : 'bg-gradient-to-r from-teal-500 to-emerald-500 hover:from-teal-600 hover:to-emerald-600 text-white'
                    } px-6 py-3 rounded-xl font-semibold flex items-center gap-2`}
                  >
                    {addedToTracking ? (
                      <>
                        <Check className="h-5 w-5" />
                        تمت الإضافة
                      </>
                    ) : (
                      <>
                        <Plus className="h-5 w-5" />
                        إضافة إلى تتبع التغذية
                      </>
                    )}
                  </motion.button>
                </div>

                <div className="text-center">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={startScanning}
                    className="enhanced-button bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg font-semibold"
                  >
                    <Camera className="h-5 w-5 mr-2" />
                    مسح منتج آخر
                  </motion.button>
                </div>
              </motion.div>
            )}
          </div>
        )}
      </div>

      {/* عمليات المسح الأخيرة */}
      {recentScans.length > 0 && (
        <div className="enhanced-card rounded-2xl p-8">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-6">
            عمليات المسح الأخيرة
          </h3>
          <div className="space-y-4">
            {recentScans.map((scan) => (
              <motion.div
                key={scan.timestamp}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 flex items-center gap-4"
              >
                {scan.product.image && (
                  <div className="w-16 h-16 bg-white rounded-lg overflow-hidden flex items-center justify-center p-1">
                    <img 
                      src={scan.product.image} 
                      alt={scan.product.name} 
                      className="max-w-full max-h-full object-contain"
                    />
                  </div>
                )}
                
                <div className="flex-1">
                  <div className="font-semibold text-gray-800 dark:text-gray-100">
                    {scan.product.name}
                  </div>
                  <div className="text-sm text-gray-600 dark:text-gray-400">
                    {scan.product.brand}
                  </div>
                  <div className="text-sm text-gray-500 dark:text-gray-500">
                    {scan.product.nutritionFacts.calories} سعرة
                  </div>
                </div>
                
                <div className="text-xs text-gray-500 dark:text-gray-500">
                  {new Date(scan.timestamp).toLocaleDateString('ar-SA')}
                </div>
                
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => {
                    setScannedCode(scan.code);
                    setProduct(scan.product);
                    setError(null);
                    setAddedToTracking(false);
                  }}
                  className="p-2 text-teal-600 hover:bg-teal-100 dark:hover:bg-teal-900/20 rounded-lg"
                >
                  <Search className="h-4 w-4" />
                </motion.button>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* معلومات إضافية */}
      <div className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-6">
        <h4 className="font-semibold text-gray-800 dark:text-gray-100 mb-3">نصائح للاستخدام:</h4>
        <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
          <li>• تأكد من وجود إضاءة كافية عند مسح الباركود</li>
          <li>• حافظ على ثبات الكاميرا أثناء المسح</li>
          <li>• يمكنك إدخال رمز الباركود يدوياً إذا واجهت صعوبة في المسح</li>
          <li>• قد لا تتوفر معلومات لجميع المنتجات في قاعدة البيانات</li>
          <li>• يمكنك إضافة المنتجات مباشرة إلى تتبع التغذية الخاص بك</li>
        </ul>
      </div>
    </motion.div>
  );
};

export default BarcodeScanner;

