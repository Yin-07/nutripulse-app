import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Badge } from '../components/ui/badge'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select'
import { ChefHat, Search, Clock, Users, Flame, Heart, Leaf, Star, Filter } from 'lucide-react'

const RecipeLibrary = ({ language, translations }) => {
  const t = (key) => translations[language]?.[key] || key

  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [selectedDiet, setSelectedDiet] = useState('all')
  const [selectedTime, setSelectedTime] = useState('all')
  const [favorites, setFavorites] = useState([])

  // قاعدة بيانات الوصفات
  const recipes = [
    {
      id: 1,
      name: language === 'ar' ? 'سلطة الكينوا بالخضار' : 'Quinoa Vegetable Salad',
      category: 'salad',
      diet: 'vegetarian',
      prepTime: 20,
      servings: 4,
      calories: 320,
      protein: 12,
      carbs: 45,
      fat: 8,
      fiber: 6,
      image: '🥗',
      difficulty: 'easy',
      ingredients: language === 'ar' ? [
        '1 كوب كينوا مطبوخة',
        '2 حبة خيار مقطعة',
        '3 حبات طماطم كرزية',
        '1/2 كوب جزر مبشور',
        '1/4 كوب بقدونس مفروم',
        '2 ملعقة كبيرة زيت زيتون',
        '1 ملعقة كبيرة عصير ليمون',
        'ملح وفلفل حسب الذوق'
      ] : [
        '1 cup cooked quinoa',
        '2 cucumbers, diced',
        '3 cherry tomatoes',
        '1/2 cup shredded carrots',
        '1/4 cup chopped parsley',
        '2 tbsp olive oil',
        '1 tbsp lemon juice',
        'Salt and pepper to taste'
      ],
      instructions: language === 'ar' ? [
        'اطبخي الكينوا حسب التعليمات على العبوة',
        'قطعي الخضار إلى قطع صغيرة',
        'اخلطي جميع المكونات في وعاء كبير',
        'أضيفي الزيت وعصير الليمون',
        'تبلي بالملح والفلفل',
        'قدمي باردة'
      ] : [
        'Cook quinoa according to package instructions',
        'Dice all vegetables into small pieces',
        'Mix all ingredients in a large bowl',
        'Add olive oil and lemon juice',
        'Season with salt and pepper',
        'Serve chilled'
      ],
      tags: ['healthy', 'vegetarian', 'gluten-free', 'high-protein']
    },
    {
      id: 2,
      name: language === 'ar' ? 'سمك السلمون المشوي بالأعشاب' : 'Herb-Grilled Salmon',
      category: 'main',
      diet: 'pescatarian',
      prepTime: 25,
      servings: 2,
      calories: 450,
      protein: 35,
      carbs: 5,
      fat: 28,
      fiber: 1,
      image: '🐟',
      difficulty: 'medium',
      ingredients: language === 'ar' ? [
        '2 قطعة سمك سلمون (150 جم لكل قطعة)',
        '2 ملعقة كبيرة زيت زيتون',
        '1 ملعقة صغيرة إكليل الجبل المجفف',
        '1 ملعقة صغيرة زعتر',
        '2 فص ثوم مفروم',
        '1 حبة ليمون',
        'ملح وفلفل أسود'
      ] : [
        '2 salmon fillets (150g each)',
        '2 tbsp olive oil',
        '1 tsp dried rosemary',
        '1 tsp thyme',
        '2 garlic cloves, minced',
        '1 lemon',
        'Salt and black pepper'
      ],
      instructions: language === 'ar' ? [
        'سخني الشواية على حرارة متوسطة',
        'اخلطي الزيت مع الأعشاب والثوم',
        'ادهني السمك بالخليط',
        'تبلي بالملح والفلفل',
        'اشوي لمدة 4-5 دقائق من كل جهة',
        'قدمي مع شرائح الليمون'
      ] : [
        'Preheat grill to medium heat',
        'Mix oil with herbs and garlic',
        'Brush salmon with the mixture',
        'Season with salt and pepper',
        'Grill for 4-5 minutes per side',
        'Serve with lemon slices'
      ],
      tags: ['high-protein', 'omega-3', 'low-carb', 'heart-healthy']
    },
    {
      id: 3,
      name: language === 'ar' ? 'عصير الفواكه الاستوائية' : 'Tropical Fruit Smoothie',
      category: 'drink',
      diet: 'vegan',
      prepTime: 10,
      servings: 2,
      calories: 180,
      protein: 4,
      carbs: 42,
      fat: 2,
      fiber: 5,
      image: '🥤',
      difficulty: 'easy',
      ingredients: language === 'ar' ? [
        '1 حبة موز مجمدة',
        '1/2 كوب أناناس مقطع',
        '1/2 كوب مانجو مقطعة',
        '1 كوب حليب جوز الهند',
        '1 ملعقة كبيرة عسل',
        '1/2 كوب ثلج'
      ] : [
        '1 frozen banana',
        '1/2 cup pineapple chunks',
        '1/2 cup mango chunks',
        '1 cup coconut milk',
        '1 tbsp honey',
        '1/2 cup ice'
      ],
      instructions: language === 'ar' ? [
        'ضعي جميع المكونات في الخلاط',
        'اخلطي حتى تحصلي على قوام ناعم',
        'أضيفي الثلج تدريجياً',
        'اخلطي مرة أخرى',
        'قدمي فوراً في أكواب مبردة'
      ] : [
        'Add all ingredients to blender',
        'Blend until smooth',
        'Add ice gradually',
        'Blend again',
        'Serve immediately in chilled glasses'
      ],
      tags: ['vegan', 'dairy-free', 'vitamin-c', 'refreshing']
    },
    {
      id: 4,
      name: language === 'ar' ? 'شوربة العدس الأحمر' : 'Red Lentil Soup',
      category: 'soup',
      diet: 'vegan',
      prepTime: 35,
      servings: 6,
      calories: 220,
      protein: 16,
      carbs: 35,
      fat: 3,
      fiber: 12,
      image: '🍲',
      difficulty: 'easy',
      ingredients: language === 'ar' ? [
        '2 كوب عدس أحمر',
        '1 حبة بصل مقطعة',
        '3 فصوص ثوم',
        '2 حبة جزر مقطعة',
        '6 أكواب مرق خضار',
        '1 ملعقة صغيرة كمون',
        '1 ملعقة صغيرة كركم',
        '2 ملعقة كبيرة زيت زيتون'
      ] : [
        '2 cups red lentils',
        '1 onion, chopped',
        '3 garlic cloves',
        '2 carrots, diced',
        '6 cups vegetable broth',
        '1 tsp cumin',
        '1 tsp turmeric',
        '2 tbsp olive oil'
      ],
      instructions: language === 'ar' ? [
        'سخني الزيت في مقلاة كبيرة',
        'أضيفي البصل والثوم حتى يذبلا',
        'أضيفي الجزر والتوابل',
        'أضيفي العدس والمرق',
        'اتركي الخليط ينضج لمدة 25 دقيقة',
        'اهرسي جزءاً من الشوربة للحصول على قوام كريمي'
      ] : [
        'Heat oil in a large pot',
        'Add onion and garlic until softened',
        'Add carrots and spices',
        'Add lentils and broth',
        'Simmer for 25 minutes',
        'Blend partially for creamy texture'
      ],
      tags: ['vegan', 'high-protein', 'high-fiber', 'comfort-food']
    },
    {
      id: 5,
      name: language === 'ar' ? 'دجاج مشوي بالليمون والأعشاب' : 'Lemon Herb Grilled Chicken',
      category: 'main',
      diet: 'keto',
      prepTime: 30,
      servings: 4,
      calories: 380,
      protein: 42,
      carbs: 3,
      fat: 18,
      fiber: 0,
      image: '🍗',
      difficulty: 'medium',
      ingredients: language === 'ar' ? [
        '4 قطع صدر دجاج',
        '3 ملاعق كبيرة زيت زيتون',
        '2 حبة ليمون (عصير وقشر)',
        '3 فصوص ثوم مفروم',
        '1 ملعقة كبيرة إكليل الجبل',
        '1 ملعقة كبيرة زعتر',
        'ملح وفلفل'
      ] : [
        '4 chicken breast fillets',
        '3 tbsp olive oil',
        '2 lemons (juice and zest)',
        '3 garlic cloves, minced',
        '1 tbsp rosemary',
        '1 tbsp thyme',
        'Salt and pepper'
      ],
      instructions: language === 'ar' ? [
        'اخلطي جميع المكونات عدا الدجاج',
        'تبلي الدجاج بالخليط لمدة ساعة',
        'سخني الشواية على حرارة متوسطة',
        'اشوي الدجاج 6-7 دقائق من كل جهة',
        'تأكدي من نضج الدجاج تماماً',
        'اتركيه يرتاح 5 دقائق قبل التقديم'
      ] : [
        'Mix all ingredients except chicken',
        'Marinate chicken for 1 hour',
        'Preheat grill to medium heat',
        'Grill chicken 6-7 minutes per side',
        'Ensure chicken is fully cooked',
        'Let rest 5 minutes before serving'
      ],
      tags: ['keto', 'high-protein', 'low-carb', 'gluten-free']
    },
    {
      id: 6,
      name: language === 'ar' ? 'كرات الطاقة بالتمر والمكسرات' : 'Date and Nut Energy Balls',
      category: 'snack',
      diet: 'vegan',
      prepTime: 15,
      servings: 12,
      calories: 95,
      protein: 3,
      carbs: 12,
      fat: 5,
      fiber: 2,
      image: '🍯',
      difficulty: 'easy',
      ingredients: language === 'ar' ? [
        '1 كوب تمر منزوع النوى',
        '1/2 كوب لوز',
        '1/4 كوب جوز',
        '2 ملعقة كبيرة بذور الشيا',
        '1 ملعقة صغيرة فانيليا',
        '1/4 كوب جوز هند مبشور'
      ] : [
        '1 cup pitted dates',
        '1/2 cup almonds',
        '1/4 cup walnuts',
        '2 tbsp chia seeds',
        '1 tsp vanilla',
        '1/4 cup shredded coconut'
      ],
      instructions: language === 'ar' ? [
        'انقعي التمر في ماء دافئ لمدة 10 دقائق',
        'اطحني المكسرات في محضر الطعام',
        'أضيفي التمر المصفى والفانيليا',
        'اخلطي حتى تتكون عجينة متماسكة',
        'شكلي كرات صغيرة بحجم الجوز',
        'لفي الكرات في جوز الهند المبشور'
      ] : [
        'Soak dates in warm water for 10 minutes',
        'Process nuts in food processor',
        'Add drained dates and vanilla',
        'Mix until paste forms',
        'Roll into walnut-sized balls',
        'Roll balls in shredded coconut'
      ],
      tags: ['vegan', 'no-bake', 'energy-boost', 'natural-sweetener']
    }
  ]

  // تصفية الوصفات
  const filteredRecipes = recipes.filter(recipe => {
    const matchesSearch = recipe.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         recipe.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesCategory = selectedCategory === 'all' || recipe.category === selectedCategory
    const matchesDiet = selectedDiet === 'all' || recipe.diet === selectedDiet
    const matchesTime = selectedTime === 'all' || 
                       (selectedTime === 'quick' && recipe.prepTime <= 20) ||
                       (selectedTime === 'medium' && recipe.prepTime > 20 && recipe.prepTime <= 40) ||
                       (selectedTime === 'long' && recipe.prepTime > 40)
    
    return matchesSearch && matchesCategory && matchesDiet && matchesTime
  })

  // إدارة المفضلة
  useEffect(() => {
    const savedFavorites = localStorage.getItem('recipeFavorites')
    if (savedFavorites) {
      setFavorites(JSON.parse(savedFavorites))
    }
  }, [])

  const toggleFavorite = (recipeId) => {
    const newFavorites = favorites.includes(recipeId)
      ? favorites.filter(id => id !== recipeId)
      : [...favorites, recipeId]
    
    setFavorites(newFavorites)
    localStorage.setItem('recipeFavorites', JSON.stringify(newFavorites))
  }

  const getDifficultyColor = (difficulty) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
      case 'medium': return 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200'
      case 'hard': return 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-200'
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
    }
  }

  const getDietColor = (diet) => {
    switch (diet) {
      case 'vegan': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
      case 'vegetarian': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
      case 'keto': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200'
      case 'pescatarian': return 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200'
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-2"
      >
        <div className="flex items-center justify-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-2xl flex items-center justify-center">
            <ChefHat className="h-6 w-6 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-200">
            {t('recipe_library') || 'Healthy Recipe Library'}
          </h1>
        </div>
        <p className="text-gray-600 dark:text-gray-400">
          {t('recipe_library_desc') || 'Discover healthy and delicious recipes with detailed nutritional information'}
        </p>
      </motion.div>

      {/* أدوات البحث والتصفية */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="enhanced-card">
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="lg:col-span-2">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder={t('search_recipes') || 'Search recipes...'}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger>
                  <SelectValue placeholder={t('category') || 'Category'} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('all_categories') || 'All Categories'}</SelectItem>
                  <SelectItem value="main">{t('main_dishes') || 'Main Dishes'}</SelectItem>
                  <SelectItem value="salad">{t('salads') || 'Salads'}</SelectItem>
                  <SelectItem value="soup">{t('soups') || 'Soups'}</SelectItem>
                  <SelectItem value="snack">{t('snacks') || 'Snacks'}</SelectItem>
                  <SelectItem value="drink">{t('drinks') || 'Drinks'}</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedDiet} onValueChange={setSelectedDiet}>
                <SelectTrigger>
                  <SelectValue placeholder={t('diet') || 'Diet'} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('all_diets') || 'All Diets'}</SelectItem>
                  <SelectItem value="vegan">{t('vegan') || 'Vegan'}</SelectItem>
                  <SelectItem value="vegetarian">{t('vegetarian') || 'Vegetarian'}</SelectItem>
                  <SelectItem value="keto">{t('keto') || 'Keto'}</SelectItem>
                  <SelectItem value="pescatarian">{t('pescatarian') || 'Pescatarian'}</SelectItem>
                </SelectContent>
              </Select>

              <Select value={selectedTime} onValueChange={setSelectedTime}>
                <SelectTrigger>
                  <SelectValue placeholder={t('prep_time') || 'Prep Time'} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t('any_time') || 'Any Time'}</SelectItem>
                  <SelectItem value="quick">{t('quick') || 'Quick (≤20 min)'}</SelectItem>
                  <SelectItem value="medium">{t('medium') || 'Medium (20-40 min)'}</SelectItem>
                  <SelectItem value="long">{t('long') || 'Long (>40 min)'}</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* عدد النتائج */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="flex items-center justify-between"
      >
        <p className="text-gray-600 dark:text-gray-400">
          {filteredRecipes.length} {t('recipes_found') || 'recipes found'}
        </p>
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-gray-500" />
          <span className="text-sm text-gray-500">
            {t('filter_active') || 'Filters active'}
          </span>
        </div>
      </motion.div>

      {/* شبكة الوصفات */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
      >
        {filteredRecipes.map((recipe, index) => (
          <motion.div
            key={recipe.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * index }}
            whileHover={{ y: -5 }}
          >
            <Card className="enhanced-card h-full hover:shadow-xl transition-all duration-300">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="text-4xl">{recipe.image}</div>
                    <div>
                      <CardTitle className="text-lg leading-tight">
                        {recipe.name}
                      </CardTitle>
                      <div className="flex items-center gap-2 mt-1">
                        <Badge className={getDifficultyColor(recipe.difficulty)}>
                          {t(recipe.difficulty) || recipe.difficulty}
                        </Badge>
                        <Badge className={getDietColor(recipe.diet)}>
                          {t(recipe.diet) || recipe.diet}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => toggleFavorite(recipe.id)}
                    className={favorites.includes(recipe.id) ? 'text-red-500' : 'text-gray-400'}
                  >
                    <Heart className={`h-5 w-5 ${favorites.includes(recipe.id) ? 'fill-current' : ''}`} />
                  </Button>
                </div>
              </CardHeader>

              <CardContent className="space-y-4">
                {/* معلومات سريعة */}
                <div className="grid grid-cols-3 gap-2 text-sm">
                  <div className="flex items-center gap-1 text-gray-600 dark:text-gray-400">
                    <Clock className="h-4 w-4" />
                    <span>{recipe.prepTime} {t('min') || 'min'}</span>
                  </div>
                  <div className="flex items-center gap-1 text-gray-600 dark:text-gray-400">
                    <Users className="h-4 w-4" />
                    <span>{recipe.servings} {t('servings') || 'servings'}</span>
                  </div>
                  <div className="flex items-center gap-1 text-gray-600 dark:text-gray-400">
                    <Flame className="h-4 w-4" />
                    <span>{recipe.calories} {t('cal') || 'cal'}</span>
                  </div>
                </div>

                {/* المعلومات الغذائية */}
                <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-3">
                  <h4 className="font-semibold text-sm mb-2 text-gray-800 dark:text-gray-200">
                    {t('nutrition_per_serving') || 'Nutrition per serving'}
                  </h4>
                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">{t('protein') || 'Protein'}:</span>
                      <span className="font-medium">{recipe.protein}g</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">{t('carbs') || 'Carbs'}:</span>
                      <span className="font-medium">{recipe.carbs}g</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">{t('fat') || 'Fat'}:</span>
                      <span className="font-medium">{recipe.fat}g</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600 dark:text-gray-400">{t('fiber') || 'Fiber'}:</span>
                      <span className="font-medium">{recipe.fiber}g</span>
                    </div>
                  </div>
                </div>

                {/* العلامات */}
                <div className="flex flex-wrap gap-1">
                  {recipe.tags.slice(0, 3).map((tag, tagIndex) => (
                    <Badge key={tagIndex} variant="outline" className="text-xs">
                      {t(tag) || tag}
                    </Badge>
                  ))}
                  {recipe.tags.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{recipe.tags.length - 3}
                    </Badge>
                  )}
                </div>

                {/* المكونات (مختصرة) */}
                <div>
                  <h4 className="font-semibold text-sm mb-2 text-gray-800 dark:text-gray-200">
                    {t('ingredients') || 'Ingredients'}
                  </h4>
                  <ul className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
                    {recipe.ingredients.slice(0, 3).map((ingredient, ingredientIndex) => (
                      <li key={ingredientIndex} className="flex items-start gap-1">
                        <span className="text-orange-500 mt-1">•</span>
                        <span>{ingredient}</span>
                      </li>
                    ))}
                    {recipe.ingredients.length > 3 && (
                      <li className="text-orange-600 font-medium">
                        +{recipe.ingredients.length - 3} {t('more_ingredients') || 'more ingredients'}
                      </li>
                    )}
                  </ul>
                </div>

                {/* أزرار الإجراءات */}
                <div className="flex gap-2 pt-2">
                  <Button className="flex-1" size="sm">
                    {t('view_recipe') || 'View Recipe'}
                  </Button>
                  <Button variant="outline" size="sm">
                    {t('save') || 'Save'}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* رسالة عدم وجود نتائج */}
      {filteredRecipes.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12"
        >
          <ChefHat className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 dark:text-gray-400 mb-2">
            {t('no_recipes_found') || 'No recipes found'}
          </h3>
          <p className="text-gray-500 dark:text-gray-500">
            {t('try_different_filters') || 'Try adjusting your search filters'}
          </p>
        </motion.div>
      )}
    </div>
  )
}

export default RecipeLibrary

