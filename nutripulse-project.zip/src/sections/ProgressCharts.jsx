import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card'
import { Button } from '../components/ui/button'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '../components/ui/select'
import { TrendingUp, Calendar, Target, Award, BarChart3, LineChart as LineChartIcon } from 'lucide-react'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, AreaChart, Area, PieChart, Pie, Cell, RadialBarChart, RadialBar } from 'recharts'

const ProgressCharts = ({ language, translations }) => {
  const t = (key) => translations[language]?.[key] || key

  const [timeRange, setTimeRange] = useState('30') // 7, 30, 90 days
  const [chartType, setChartType] = useState('weight') // weight, calories, activity, nutrition

  // جلب البيانات من localStorage
  const [weightData, setWeightData] = useState([])
  const [activityData, setActivityData] = useState([])
  const [nutritionData, setNutritionData] = useState([])
  const [calorieData, setCalorieData] = useState([])

  useEffect(() => {
    // جلب بيانات الوزن
    const savedWeights = localStorage.getItem('weightLog')
    if (savedWeights) {
      const weights = JSON.parse(savedWeights)
      setWeightData(weights.slice(-parseInt(timeRange)))
    }

    // جلب بيانات النشاط
    const savedActivities = localStorage.getItem('activityLog')
    if (savedActivities) {
      const activities = JSON.parse(savedActivities)
      // تجميع البيانات حسب التاريخ
      const groupedActivities = activities.reduce((acc, activity) => {
        const date = activity.date
        if (!acc[date]) {
          acc[date] = { date, calories: 0, duration: 0, activities: 0 }
        }
        acc[date].calories += activity.caloriesBurned
        acc[date].duration += activity.duration
        acc[date].activities += 1
        return acc
      }, {})
      
      setActivityData(Object.values(groupedActivities).slice(-parseInt(timeRange)))
    }

    // جلب بيانات التغذية
    const savedNutrition = localStorage.getItem('nutritionTracking')
    if (savedNutrition) {
      const nutrition = JSON.parse(savedNutrition)
      setNutritionData(nutrition.slice(-parseInt(timeRange)))
    }

    // إنشاء بيانات وهمية للسعرات الحرارية إذا لم تكن متوفرة
    if (!localStorage.getItem('calorieData')) {
      const dummyCalorieData = Array.from({ length: parseInt(timeRange) }, (_, i) => {
        const date = new Date()
        date.setDate(date.getDate() - (parseInt(timeRange) - 1 - i))
        return {
          date: date.toISOString().split('T')[0],
          consumed: Math.floor(Math.random() * 500) + 1800,
          burned: Math.floor(Math.random() * 400) + 200,
          target: 2000
        }
      })
      setCalorieData(dummyCalorieData)
    }
  }, [timeRange])

  // حساب الإحصائيات
  const calculateStats = () => {
    const stats = {
      weight: { current: 0, change: 0, trend: 'stable' },
      activity: { total: 0, average: 0, trend: 'up' },
      calories: { average: 0, deficit: 0, trend: 'stable' }
    }

    if (weightData.length > 0) {
      stats.weight.current = weightData[weightData.length - 1]?.weight || 0
      if (weightData.length > 1) {
        const firstWeight = weightData[0].weight
        const lastWeight = weightData[weightData.length - 1].weight
        stats.weight.change = lastWeight - firstWeight
        stats.weight.trend = stats.weight.change > 0 ? 'up' : stats.weight.change < 0 ? 'down' : 'stable'
      }
    }

    if (activityData.length > 0) {
      stats.activity.total = activityData.reduce((sum, day) => sum + day.calories, 0)
      stats.activity.average = Math.round(stats.activity.total / activityData.length)
    }

    if (calorieData.length > 0) {
      stats.calories.average = Math.round(calorieData.reduce((sum, day) => sum + day.consumed, 0) / calorieData.length)
      stats.calories.deficit = Math.round(calorieData.reduce((sum, day) => sum + (day.burned - day.consumed), 0) / calorieData.length)
    }

    return stats
  }

  const stats = calculateStats()

  // ألوان للرسوم البيانية
  const colors = {
    primary: '#3b82f6',
    secondary: '#ef4444',
    success: '#10b981',
    warning: '#f59e0b',
    purple: '#8b5cf6'
  }

  // بيانات الرسم البياني الدائري للتغذية
  const nutritionPieData = [
    { name: t('protein') || 'Protein', value: 25, fill: colors.primary },
    { name: t('carbs') || 'Carbs', value: 45, fill: colors.success },
    { name: t('fats') || 'Fats', value: 30, fill: colors.warning }
  ]

  // بيانات الرسم البياني الشعاعي للأهداف
  const goalsData = [
    { name: t('weight_goal') || 'Weight Goal', value: 75, fill: colors.primary },
    { name: t('activity_goal') || 'Activity Goal', value: 60, fill: colors.success },
    { name: t('nutrition_goal') || 'Nutrition Goal', value: 85, fill: colors.warning }
  ]

  const renderChart = () => {
    switch (chartType) {
      case 'weight':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={weightData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={(date) => new Date(date).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', { month: 'short', day: 'numeric' })}
              />
              <YAxis />
              <Tooltip 
                labelFormatter={(date) => new Date(date).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}
                formatter={(value) => [`${value} kg`, t('weight') || 'Weight']}
              />
              <Line 
                type="monotone" 
                dataKey="weight" 
                stroke={colors.primary} 
                strokeWidth={3}
                dot={{ fill: colors.primary, strokeWidth: 2, r: 5 }}
              />
            </LineChart>
          </ResponsiveContainer>
        )

      case 'calories':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <AreaChart data={calorieData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={(date) => new Date(date).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', { month: 'short', day: 'numeric' })}
              />
              <YAxis />
              <Tooltip 
                labelFormatter={(date) => new Date(date).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}
              />
              <Area 
                type="monotone" 
                dataKey="consumed" 
                stackId="1"
                stroke={colors.success} 
                fill={colors.success}
                fillOpacity={0.6}
              />
              <Area 
                type="monotone" 
                dataKey="burned" 
                stackId="2"
                stroke={colors.secondary} 
                fill={colors.secondary}
                fillOpacity={0.6}
              />
              <Line 
                type="monotone" 
                dataKey="target" 
                stroke={colors.warning}
                strokeDasharray="5 5"
              />
            </AreaChart>
          </ResponsiveContainer>
        )

      case 'activity':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={activityData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis 
                dataKey="date" 
                tickFormatter={(date) => new Date(date).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US', { month: 'short', day: 'numeric' })}
              />
              <YAxis />
              <Tooltip 
                labelFormatter={(date) => new Date(date).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}
              />
              <Bar dataKey="calories" fill={colors.primary} radius={[4, 4, 0, 0]} />
              <Bar dataKey="duration" fill={colors.success} radius={[4, 4, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        )

      case 'nutrition':
        return (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={nutritionPieData}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="value"
                  label={({ name, value }) => `${name}: ${value}%`}
                >
                  {nutritionPieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>

            <ResponsiveContainer width="100%" height={300}>
              <RadialBarChart cx="50%" cy="50%" innerRadius="20%" outerRadius="80%" data={goalsData}>
                <RadialBar dataKey="value" cornerRadius={10} fill="#8884d8" />
                <Tooltip />
              </RadialBarChart>
            </ResponsiveContainer>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-2"
      >
        <div className="flex items-center justify-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-purple-500 to-pink-600 rounded-2xl flex items-center justify-center">
            <BarChart3 className="h-6 w-6 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-200">
            {t('progress_charts') || 'Progress Charts'}
          </h1>
        </div>
        <p className="text-gray-600 dark:text-gray-400">
          {t('progress_charts_desc') || 'Visualize your health and fitness progress over time'}
        </p>
      </motion.div>

      {/* الإحصائيات السريعة */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-1 md:grid-cols-3 gap-4"
      >
        <Card className="enhanced-card">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-cyan-600 rounded-full flex items-center justify-center mx-auto mb-3">
              <Target className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800 dark:text-gray-200">
              {stats.weight.current} kg
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              {t('current_weight') || 'Current Weight'}
            </p>
            <div className={`text-sm mt-1 ${stats.weight.change > 0 ? 'text-red-600' : stats.weight.change < 0 ? 'text-green-600' : 'text-gray-500'}`}>
              {stats.weight.change > 0 ? '+' : ''}{stats.weight.change.toFixed(1)} kg
            </div>
          </CardContent>
        </Card>

        <Card className="enhanced-card">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-full flex items-center justify-center mx-auto mb-3">
              <TrendingUp className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800 dark:text-gray-200">
              {stats.activity.average}
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              {t('avg_daily_calories_burned') || 'Avg Daily Calories Burned'}
            </p>
            <div className="text-sm mt-1 text-green-600">
              {stats.activity.total} {t('total') || 'total'}
            </div>
          </CardContent>
        </Card>

        <Card className="enhanced-card">
          <CardContent className="p-6 text-center">
            <div className="w-12 h-12 bg-gradient-to-br from-orange-500 to-red-600 rounded-full flex items-center justify-center mx-auto mb-3">
              <Award className="h-6 w-6 text-white" />
            </div>
            <h3 className="text-2xl font-bold text-gray-800 dark:text-gray-200">
              {stats.calories.average}
            </h3>
            <p className="text-gray-600 dark:text-gray-400">
              {t('avg_daily_calories') || 'Avg Daily Calories'}
            </p>
            <div className={`text-sm mt-1 ${stats.calories.deficit < 0 ? 'text-green-600' : 'text-red-600'}`}>
              {stats.calories.deficit} {t('deficit') || 'deficit'}
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* أدوات التحكم */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="enhanced-card">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
              <div className="flex items-center gap-4">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    {t('chart_type') || 'Chart Type'}
                  </label>
                  <Select value={chartType} onValueChange={setChartType}>
                    <SelectTrigger className="w-48">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="weight">
                        <span className="flex items-center gap-2">
                          <Target className="h-4 w-4" />
                          {t('weight_progress') || 'Weight Progress'}
                        </span>
                      </SelectItem>
                      <SelectItem value="calories">
                        <span className="flex items-center gap-2">
                          <LineChartIcon className="h-4 w-4" />
                          {t('calorie_tracking') || 'Calorie Tracking'}
                        </span>
                      </SelectItem>
                      <SelectItem value="activity">
                        <span className="flex items-center gap-2">
                          <BarChart3 className="h-4 w-4" />
                          {t('activity_progress') || 'Activity Progress'}
                        </span>
                      </SelectItem>
                      <SelectItem value="nutrition">
                        <span className="flex items-center gap-2">
                          <Award className="h-4 w-4" />
                          {t('nutrition_analysis') || 'Nutrition Analysis'}
                        </span>
                      </SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    {t('time_range') || 'Time Range'}
                  </label>
                  <Select value={timeRange} onValueChange={setTimeRange}>
                    <SelectTrigger className="w-32">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="7">7 {t('days') || 'days'}</SelectItem>
                      <SelectItem value="30">30 {t('days') || 'days'}</SelectItem>
                      <SelectItem value="90">90 {t('days') || 'days'}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <Calendar className="h-5 w-5 text-gray-500" />
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  {t('last_updated') || 'Last updated'}: {new Date().toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}
                </span>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* الرسم البياني الرئيسي */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
      >
        <Card className="enhanced-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              {chartType === 'weight' && (t('weight_progress') || 'Weight Progress')}
              {chartType === 'calories' && (t('calorie_tracking') || 'Calorie Tracking')}
              {chartType === 'activity' && (t('activity_progress') || 'Activity Progress')}
              {chartType === 'nutrition' && (t('nutrition_analysis') || 'Nutrition Analysis')}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {renderChart()}
          </CardContent>
        </Card>
      </motion.div>

      {/* نصائح وتوصيات */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.4 }}
      >
        <Card className="enhanced-card">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Award className="h-5 w-5" />
              {t('insights_recommendations') || 'Insights & Recommendations'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg">
                <h4 className="font-semibold text-blue-800 dark:text-blue-200 mb-2">
                  {t('weight_trend') || 'Weight Trend'}
                </h4>
                <p className="text-sm text-blue-700 dark:text-blue-300">
                  {stats.weight.trend === 'down' 
                    ? (t('weight_decreasing') || 'Your weight is decreasing. Keep up the good work!')
                    : stats.weight.trend === 'up'
                    ? (t('weight_increasing') || 'Your weight is increasing. Consider adjusting your diet and exercise.')
                    : (t('weight_stable') || 'Your weight is stable. Maintain your current routine.')
                  }
                </p>
              </div>

              <div className="p-4 bg-green-50 dark:bg-green-900/20 rounded-lg">
                <h4 className="font-semibold text-green-800 dark:text-green-200 mb-2">
                  {t('activity_level') || 'Activity Level'}
                </h4>
                <p className="text-sm text-green-700 dark:text-green-300">
                  {stats.activity.average > 300
                    ? (t('high_activity') || 'Excellent activity level! You\'re burning lots of calories.')
                    : stats.activity.average > 150
                    ? (t('moderate_activity') || 'Good activity level. Try to increase intensity gradually.')
                    : (t('low_activity') || 'Consider increasing your physical activity for better health.')
                  }
                </p>
              </div>

              <div className="p-4 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                <h4 className="font-semibold text-orange-800 dark:text-orange-200 mb-2">
                  {t('calorie_balance') || 'Calorie Balance'}
                </h4>
                <p className="text-sm text-orange-700 dark:text-orange-300">
                  {stats.calories.deficit < -200
                    ? (t('high_deficit') || 'You have a high calorie deficit. Great for weight loss!')
                    : stats.calories.deficit < 0
                    ? (t('moderate_deficit') || 'You have a moderate calorie deficit. Good for gradual weight loss.')
                    : (t('calorie_surplus') || 'You have a calorie surplus. Consider reducing intake or increasing activity.')
                  }
                </p>
              </div>

              <div className="p-4 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                <h4 className="font-semibold text-purple-800 dark:text-purple-200 mb-2">
                  {t('consistency') || 'Consistency'}
                </h4>
                <p className="text-sm text-purple-700 dark:text-purple-300">
                  {t('consistency_tip') || 'Consistency is key to achieving your health goals. Keep tracking your progress daily!'}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  )
}

export default ProgressCharts

