import React, { useState } from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Badge } from '../components/ui/badge'
import { BookOpen, Search, Clock, User, Heart, Bookmark, Share2, Filter } from 'lucide-react'

const NutritionArticles = ({ language, translations }) => {
  const t = (key) => translations[language]?.[key] || key

  const [searchTerm, setSearchTerm] = useState('')
  const [selectedCategory, setSelectedCategory] = useState('all')
  const [bookmarkedArticles, setBookmarkedArticles] = useState([])

  // قاعدة بيانات المقالات
  const articles = [
    {
      id: 1,
      title: language === 'ar' ? 'أساسيات التغذية الصحية: دليل شامل للمبتدئين' : 'Nutrition Basics: A Comprehensive Guide for Beginners',
      category: 'basics',
      author: language === 'ar' ? 'د. أحمد محمد' : 'Dr. Ahmed Mohamed',
      readTime: 8,
      publishDate: '2024-01-15',
      image: '🥗',
      excerpt: language === 'ar' 
        ? 'تعرف على أساسيات التغذية الصحية والمغذيات الأساسية التي يحتاجها جسمك يومياً للحفاظ على صحة مثلى.'
        : 'Learn the fundamentals of healthy nutrition and essential nutrients your body needs daily for optimal health.',
      content: language === 'ar' ? `
        التغذية الصحية هي أساس الحياة الصحية والعافية. في هذا المقال، سنستكشف المبادئ الأساسية للتغذية السليمة.

        ## المغذيات الكبرى (Macronutrients)

        ### البروتينات
        البروتينات هي اللبنات الأساسية لبناء العضلات والأنسجة. يحتاج الجسم إلى 0.8-1.2 جرام من البروتين لكل كيلوجرام من وزن الجسم يومياً.

        المصادر الجيدة للبروتين:
        - اللحوم الخالية من الدهون
        - الأسماك والمأكولات البحرية
        - البيض ومنتجات الألبان
        - البقوليات والمكسرات
        - الكينوا والحبوب الكاملة

        ### الكربوهيدرات
        الكربوهيدرات هي المصدر الرئيسي للطاقة في الجسم. يُنصح بأن تشكل 45-65% من إجمالي السعرات الحرارية اليومية.

        أنواع الكربوهيدرات:
        - الكربوهيدرات البسيطة: السكريات الطبيعية في الفواكه
        - الكربوهيدرات المعقدة: الحبوب الكاملة والخضروات النشوية

        ### الدهون
        الدهون ضرورية لامتصاص الفيتامينات وإنتاج الهرمونات. يجب أن تشكل 20-35% من السعرات اليومية.

        أنواع الدهون:
        - الدهون المشبعة: يجب تقليلها
        - الدهون غير المشبعة: مفيدة للصحة
        - الدهون المتحولة: يجب تجنبها تماماً

        ## المغذيات الصغرى (Micronutrients)

        ### الفيتامينات
        - فيتامين C: مضاد للأكسدة ويقوي المناعة
        - فيتامين D: ضروري لصحة العظام
        - فيتامينات B: مهمة لإنتاج الطاقة
        - فيتامين A: مهم للرؤية والمناعة

        ### المعادن
        - الكالسيوم: لصحة العظام والأسنان
        - الحديد: لنقل الأكسجين في الدم
        - الزنك: لوظائف المناعة والشفاء
        - المغنيسيوم: لوظائف العضلات والأعصاب

        ## نصائح للتغذية الصحية

        1. **تناول وجبات متوازنة**: اجعل نصف طبقك من الخضروات والفواكه
        2. **اشرب الماء بكثرة**: 8-10 أكواب يومياً
        3. **قلل من السكر المضاف**: تجنب المشروبات السكرية
        4. **اختر الحبوب الكاملة**: بدلاً من المكررة
        5. **تناول البروتين في كل وجبة**: للشعور بالشبع لفترة أطول

        ## الخلاصة

        التغذية الصحية ليست معقدة، بل تحتاج إلى فهم أساسيات المغذيات وتطبيق مبادئ بسيطة في الحياة اليومية.
      ` : `
        Healthy nutrition is the foundation of a healthy life and well-being. In this article, we'll explore the basic principles of proper nutrition.

        ## Macronutrients

        ### Proteins
        Proteins are the building blocks for muscles and tissues. The body needs 0.8-1.2 grams of protein per kilogram of body weight daily.

        Good protein sources:
        - Lean meats
        - Fish and seafood
        - Eggs and dairy products
        - Legumes and nuts
        - Quinoa and whole grains

        ### Carbohydrates
        Carbohydrates are the body's main source of energy. It's recommended that they make up 45-65% of total daily calories.

        Types of carbohydrates:
        - Simple carbohydrates: Natural sugars in fruits
        - Complex carbohydrates: Whole grains and starchy vegetables

        ### Fats
        Fats are essential for vitamin absorption and hormone production. They should make up 20-35% of daily calories.

        Types of fats:
        - Saturated fats: Should be limited
        - Unsaturated fats: Beneficial for health
        - Trans fats: Should be completely avoided

        ## Micronutrients

        ### Vitamins
        - Vitamin C: Antioxidant and immune booster
        - Vitamin D: Essential for bone health
        - B vitamins: Important for energy production
        - Vitamin A: Important for vision and immunity

        ### Minerals
        - Calcium: For bone and teeth health
        - Iron: For oxygen transport in blood
        - Zinc: For immune function and healing
        - Magnesium: For muscle and nerve function

        ## Healthy Nutrition Tips

        1. **Eat balanced meals**: Make half your plate vegetables and fruits
        2. **Drink plenty of water**: 8-10 glasses daily
        3. **Reduce added sugar**: Avoid sugary drinks
        4. **Choose whole grains**: Instead of refined ones
        5. **Include protein in every meal**: To feel full longer

        ## Conclusion

        Healthy nutrition isn't complicated, it just requires understanding nutrient basics and applying simple principles in daily life.
      `,
      tags: ['nutrition', 'health', 'basics', 'macronutrients', 'micronutrients']
    },
    {
      id: 2,
      title: language === 'ar' ? 'فوائد الصيام المتقطع: العلم وراء هذا النظام الغذائي' : 'Benefits of Intermittent Fasting: The Science Behind This Diet',
      category: 'weight-loss',
      author: language === 'ar' ? 'د. سارة أحمد' : 'Dr. Sarah Ahmed',
      readTime: 12,
      publishDate: '2024-01-10',
      image: '⏰',
      excerpt: language === 'ar'
        ? 'اكتشف الفوائد العلمية للصيام المتقطع وكيف يمكن أن يساعد في فقدان الوزن وتحسين الصحة العامة.'
        : 'Discover the scientific benefits of intermittent fasting and how it can help with weight loss and overall health improvement.',
      content: language === 'ar' ? `
        الصيام المتقطع أصبح من أكثر الأنظمة الغذائية شعبية في السنوات الأخيرة، وذلك لأسباب علمية مدعومة بالأبحاث.

        ## ما هو الصيام المتقطع؟

        الصيام المتقطع ليس نظاماً غذائياً بالمعنى التقليدي، بل هو نمط لتوقيت الوجبات. يتضمن فترات من الصيام تتناوب مع فترات الأكل.

        ## أنواع الصيام المتقطع

        ### نظام 16:8
        - الصيام لمدة 16 ساعة
        - تناول الطعام خلال 8 ساعات
        - الأكثر شيوعاً وسهولة في التطبيق

        ### نظام 5:2
        - تناول الطعام بشكل طبيعي 5 أيام
        - تقليل السعرات إلى 500-600 سعرة يومين

        ### الصيام المتناوب
        - صيام يوم كامل
        - تناول الطعام بشكل طبيعي اليوم التالي

        ## الفوائد العلمية

        ### فقدان الوزن
        - تقليل السعرات الحرارية الإجمالية
        - زيادة معدل الأيض
        - تحفيز حرق الدهون

        ### تحسين الصحة الأيضية
        - تحسين حساسية الأنسولين
        - تقليل مستويات السكر في الدم
        - تحسين مستويات الكوليسترول

        ### الفوائد الخلوية
        - تحفيز عملية الالتهام الذاتي (Autophagy)
        - تجديد الخلايا
        - مقاومة الشيخوخة

        ### صحة الدماغ
        - زيادة إنتاج BDNF
        - تحسين الذاكرة والتركيز
        - حماية من الأمراض العصبية

        ## كيفية البدء

        1. **ابدأ تدريجياً**: ابدأ بصيام 12 ساعة ثم زد تدريجياً
        2. **اختر النظام المناسب**: حسب نمط حياتك
        3. **حافظ على الترطيب**: اشرب الماء والشاي والقهوة بدون سكر
        4. **تناول وجبات متوازنة**: في فترات الأكل

        ## التحذيرات والاحتياطات

        - استشر طبيبك قبل البدء
        - غير مناسب للحوامل والمرضعات
        - قد يسبب صداع في البداية
        - تجنبه إذا كان لديك تاريخ مع اضطرابات الأكل

        ## الخلاصة

        الصيام المتقطع أداة فعالة لفقدان الوزن وتحسين الصحة، لكن يجب تطبيقه بحكمة وتحت إشراف طبي.
      ` : `
        Intermittent fasting has become one of the most popular dietary approaches in recent years, backed by scientific research.

        ## What is Intermittent Fasting?

        Intermittent fasting isn't a diet in the traditional sense, but rather an eating pattern. It involves periods of fasting alternating with eating periods.

        ## Types of Intermittent Fasting

        ### 16:8 Method
        - Fast for 16 hours
        - Eat within an 8-hour window
        - Most popular and easy to implement

        ### 5:2 Method
        - Eat normally 5 days
        - Reduce calories to 500-600 on 2 days

        ### Alternate Day Fasting
        - Fast for a full day
        - Eat normally the next day

        ## Scientific Benefits

        ### Weight Loss
        - Reduces overall caloric intake
        - Increases metabolic rate
        - Promotes fat burning

        ### Improved Metabolic Health
        - Improves insulin sensitivity
        - Reduces blood sugar levels
        - Improves cholesterol levels

        ### Cellular Benefits
        - Stimulates autophagy
        - Cell renewal
        - Anti-aging effects

        ### Brain Health
        - Increases BDNF production
        - Improves memory and focus
        - Protection from neurological diseases

        ## How to Start

        1. **Start gradually**: Begin with 12-hour fasts then increase
        2. **Choose the right method**: Based on your lifestyle
        3. **Stay hydrated**: Drink water, tea, and coffee without sugar
        4. **Eat balanced meals**: During eating periods

        ## Warnings and Precautions

        - Consult your doctor before starting
        - Not suitable for pregnant or breastfeeding women
        - May cause headaches initially
        - Avoid if you have a history of eating disorders

        ## Conclusion

        Intermittent fasting is an effective tool for weight loss and health improvement, but should be applied wisely and under medical supervision.
      `,
      tags: ['intermittent-fasting', 'weight-loss', 'metabolism', 'health', 'science']
    },
    {
      id: 3,
      title: language === 'ar' ? 'الأطعمة الخارقة: حقيقة أم خرافة؟' : 'Superfoods: Fact or Fiction?',
      category: 'nutrition',
      author: language === 'ar' ? 'د. محمد علي' : 'Dr. Mohamed Ali',
      readTime: 10,
      publishDate: '2024-01-05',
      image: '🥬',
      excerpt: language === 'ar'
        ? 'تعرف على حقيقة الأطعمة الخارقة وما إذا كانت تستحق الضجيج المثار حولها من الناحية العلمية.'
        : 'Learn the truth about superfoods and whether they deserve the hype from a scientific perspective.',
      content: language === 'ar' ? `
        مصطلح "الأطعمة الخارقة" أصبح شائعاً جداً في عالم التغذية، لكن ما هي الحقيقة العلمية وراء هذا المفهوم؟

        ## ما هي الأطعمة الخارقة؟

        الأطعمة الخارقة هي أطعمة غنية بالمغذيات وتحتوي على مستويات عالية من الفيتامينات والمعادن ومضادات الأكسدة.

        ## أمثلة على الأطعمة الخارقة

        ### التوت الأزرق (Blueberries)
        - غني بمضادات الأكسدة
        - يحسن الذاكرة والوظائف المعرفية
        - يقلل الالتهابات

        ### السبانخ
        - مصدر ممتاز للحديد وحمض الفوليك
        - غني بفيتامين K للعظام
        - يحتوي على اللوتين لصحة العيون

        ### الأفوكادو
        - غني بالدهون الصحية
        - يحتوي على البوتاسيوم
        - يساعد في امتصاص الفيتامينات

        ### الكينوا
        - بروتين كامل
        - خالي من الجلوتين
        - غني بالألياف والمعادن

        ### السلمون
        - مصدر ممتاز لأوميجا 3
        - بروتين عالي الجودة
        - يدعم صحة القلب والدماغ

        ## الحقيقة العلمية

        ### الإيجابيات
        - هذه الأطعمة فعلاً غنية بالمغذيات
        - لها فوائد صحية مثبتة علمياً
        - تساهم في نظام غذائي صحي

        ### السلبيات
        - لا يوجد طعام واحد "سحري"
        - التسويق المبالغ فيه
        - قد تكون مكلفة دون مبرر

        ## البدائل المحلية

        ### بدلاً من التوت الأزرق المستورد
        - الرمان المحلي
        - التوت الأحمر
        - العنب الأحمر

        ### بدلاً من الكينوا
        - البرغل
        - الشعير
        - الأرز البني

        ### بدلاً من بذور الشيا
        - بذور الكتان
        - بذور السمسم
        - المكسرات المحلية

        ## نصائح للاستفادة القصوى

        1. **التنويع هو المفتاح**: لا تعتمد على طعام واحد
        2. **الموسمية والمحلية**: اختر الأطعمة الموسمية المحلية
        3. **الجودة قبل الكمية**: طعام واحد عالي الجودة أفضل من عدة أطعمة متوسطة
        4. **التوازن العام**: ركز على النظام الغذائي ككل

        ## الخلاصة

        الأطعمة الخارقة ليست خرافة، لكنها ليست الحل السحري. الأهم هو نظام غذائي متوازن ومتنوع.
      ` : `
        The term "superfoods" has become very popular in the nutrition world, but what's the scientific truth behind this concept?

        ## What are Superfoods?

        Superfoods are nutrient-rich foods containing high levels of vitamins, minerals, and antioxidants.

        ## Examples of Superfoods

        ### Blueberries
        - Rich in antioxidants
        - Improves memory and cognitive function
        - Reduces inflammation

        ### Spinach
        - Excellent source of iron and folate
        - Rich in vitamin K for bones
        - Contains lutein for eye health

        ### Avocado
        - Rich in healthy fats
        - Contains potassium
        - Helps vitamin absorption

        ### Quinoa
        - Complete protein
        - Gluten-free
        - Rich in fiber and minerals

        ### Salmon
        - Excellent source of omega-3
        - High-quality protein
        - Supports heart and brain health

        ## Scientific Truth

        ### Positives
        - These foods are indeed nutrient-dense
        - Have scientifically proven health benefits
        - Contribute to a healthy diet

        ### Negatives
        - No single "magic" food exists
        - Exaggerated marketing
        - May be unnecessarily expensive

        ## Local Alternatives

        ### Instead of imported blueberries
        - Local pomegranate
        - Red berries
        - Red grapes

        ### Instead of quinoa
        - Bulgur
        - Barley
        - Brown rice

        ### Instead of chia seeds
        - Flax seeds
        - Sesame seeds
        - Local nuts

        ## Tips for Maximum Benefits

        1. **Variety is key**: Don't rely on one food
        2. **Seasonal and local**: Choose seasonal local foods
        3. **Quality over quantity**: One high-quality food is better than several average ones
        4. **Overall balance**: Focus on the diet as a whole

        ## Conclusion

        Superfoods aren't a myth, but they're not a magic solution either. The most important thing is a balanced and varied diet.
      `,
      tags: ['superfoods', 'nutrition', 'antioxidants', 'health', 'science']
    },
    {
      id: 4,
      title: language === 'ar' ? 'دليل التغذية الرياضية: كيف تغذي جسمك للأداء الأمثل' : 'Sports Nutrition Guide: Fueling Your Body for Optimal Performance',
      category: 'sports',
      author: language === 'ar' ? 'د. ليلى حسن' : 'Dr. Layla Hassan',
      readTime: 15,
      publishDate: '2024-01-01',
      image: '🏃‍♂️',
      excerpt: language === 'ar'
        ? 'تعلم كيفية تحسين أدائك الرياضي من خلال التغذية المناسبة قبل وأثناء وبعد التمرين.'
        : 'Learn how to optimize your athletic performance through proper nutrition before, during, and after exercise.',
      content: language === 'ar' ? `
        التغذية الرياضية علم متخصص يهدف إلى تحسين الأداء الرياضي والتعافي من خلال التغذية المناسبة.

        ## أساسيات التغذية الرياضية

        ### الطاقة والسعرات الحرارية
        الرياضيون يحتاجون سعرات حرارية أكثر من الأشخاص العاديين:
        - رياضة خفيفة: +200-400 سعرة
        - رياضة متوسطة: +400-600 سعرة
        - رياضة مكثفة: +600-1000 سعرة

        ### توزيع المغذيات الكبرى
        - الكربوهيدرات: 55-65% (الوقود الرئيسي)
        - البروتين: 15-20% (بناء وإصلاح العضلات)
        - الدهون: 20-30% (طاقة طويلة المدى)

        ## التغذية قبل التمرين

        ### التوقيت
        - 3-4 ساعات قبل: وجبة كاملة
        - 1-2 ساعة قبل: وجبة خفيفة
        - 30 دقيقة قبل: مشروب رياضي

        ### أفضل الأطعمة
        - الموز مع زبدة الفول السوداني
        - الشوفان مع التوت
        - الخبز الأسمر مع العسل
        - عصير الفواكه الطبيعي

        ## التغذية أثناء التمرين

        ### للتمارين أقل من ساعة
        - الماء كافي
        - لا حاجة لسعرات إضافية

        ### للتمارين أكثر من ساعة
        - 30-60 جرام كربوهيدرات/ساعة
        - مشروبات رياضية
        - جل الطاقة
        - التمر أو الموز

        ## التغذية بعد التمرين

        ### النافذة الذهبية (30-60 دقيقة)
        - نسبة 3:1 أو 4:1 كربوهيدرات:بروتين
        - إعادة تعبئة الجليكوجين
        - إصلاح العضلات

        ### أمثلة على وجبات التعافي
        - حليب الشوكولاتة
        - زبادي مع الفواكه والجرانولا
        - ساندويش تونة
        - عصير البروتين مع الموز

        ## الترطيب

        ### قبل التمرين
        - 500-600 مل قبل 2-3 ساعات
        - 200-300 مل قبل 15-20 دقيقة

        ### أثناء التمرين
        - 150-250 مل كل 15-20 دقيقة
        - مشروبات رياضية للتمارين الطويلة

        ### بعد التمرين
        - 150% من الوزن المفقود
        - راقب لون البول

        ## المكملات الغذائية

        ### المكملات المفيدة
        - الكرياتين: لقوة العضلات
        - بروتين مصل اللبن: للتعافي
        - الكافيين: لتحسين الأداء
        - بيتا ألانين: لتحمل العضلات

        ### تحذيرات
        - استشر أخصائي تغذية
        - تأكد من الجودة والأمان
        - لا تعتمد عليها كبديل للطعام

        ## نصائح خاصة حسب نوع الرياضة

        ### رياضات التحمل
        - ركز على الكربوهيدرات
        - تدرب على التغذية أثناء السباق
        - اهتم بالترطيب

        ### رياضات القوة
        - زد البروتين إلى 1.6-2.2 جم/كجم
        - تناول البروتين بعد التمرين مباشرة
        - لا تهمل الكربوهيدرات

        ### الرياضات الجماعية
        - توازن بين جميع المغذيات
        - خطط للوجبات بين المباريات
        - حافظ على الطاقة طوال الموسم

        ## الخلاصة

        التغذية الرياضية تتطلب تخطيطاً وتخصيصاً حسب نوع الرياضة والهدف. الأساس هو نظام غذائي متوازن مع تعديلات حسب التمرين.
      ` : `
        Sports nutrition is a specialized science aimed at improving athletic performance and recovery through proper nutrition.

        ## Sports Nutrition Basics

        ### Energy and Calories
        Athletes need more calories than regular people:
        - Light exercise: +200-400 calories
        - Moderate exercise: +400-600 calories
        - Intense exercise: +600-1000 calories

        ### Macronutrient Distribution
        - Carbohydrates: 55-65% (main fuel)
        - Protein: 15-20% (muscle building and repair)
        - Fats: 20-30% (long-term energy)

        ## Pre-Exercise Nutrition

        ### Timing
        - 3-4 hours before: Full meal
        - 1-2 hours before: Light snack
        - 30 minutes before: Sports drink

        ### Best Foods
        - Banana with peanut butter
        - Oatmeal with berries
        - Whole grain bread with honey
        - Natural fruit juice

        ## During Exercise Nutrition

        ### For exercises under 1 hour
        - Water is sufficient
        - No need for extra calories

        ### For exercises over 1 hour
        - 30-60g carbohydrates/hour
        - Sports drinks
        - Energy gels
        - Dates or bananas

        ## Post-Exercise Nutrition

        ### Golden Window (30-60 minutes)
        - 3:1 or 4:1 carbohydrate:protein ratio
        - Replenish glycogen
        - Muscle repair

        ### Recovery Meal Examples
        - Chocolate milk
        - Yogurt with fruits and granola
        - Tuna sandwich
        - Protein smoothie with banana

        ## Hydration

        ### Before Exercise
        - 500-600ml 2-3 hours before
        - 200-300ml 15-20 minutes before

        ### During Exercise
        - 150-250ml every 15-20 minutes
        - Sports drinks for long exercises

        ### After Exercise
        - 150% of weight lost
        - Monitor urine color

        ## Supplements

        ### Beneficial Supplements
        - Creatine: For muscle strength
        - Whey protein: For recovery
        - Caffeine: For performance enhancement
        - Beta-alanine: For muscle endurance

        ### Warnings
        - Consult a nutritionist
        - Ensure quality and safety
        - Don't rely on them as food substitutes

        ## Sport-Specific Tips

        ### Endurance Sports
        - Focus on carbohydrates
        - Practice race nutrition
        - Prioritize hydration

        ### Strength Sports
        - Increase protein to 1.6-2.2g/kg
        - Consume protein immediately post-workout
        - Don't neglect carbohydrates

        ### Team Sports
        - Balance all nutrients
        - Plan meals between games
        - Maintain energy throughout season

        ## Conclusion

        Sports nutrition requires planning and customization based on sport type and goals. The foundation is a balanced diet with exercise-specific modifications.
      `,
      tags: ['sports-nutrition', 'performance', 'exercise', 'recovery', 'hydration']
    }
  ]

  // تصفية المقالات
  const filteredArticles = articles.filter(article => {
    const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         article.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
    const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory
    
    return matchesSearch && matchesCategory
  })

  // إدارة المفضلة
  const toggleBookmark = (articleId) => {
    const newBookmarks = bookmarkedArticles.includes(articleId)
      ? bookmarkedArticles.filter(id => id !== articleId)
      : [...bookmarkedArticles, articleId]
    
    setBookmarkedArticles(newBookmarks)
    localStorage.setItem('bookmarkedArticles', JSON.stringify(newBookmarks))
  }

  const getCategoryColor = (category) => {
    switch (category) {
      case 'basics': return 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200'
      case 'weight-loss': return 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
      case 'nutrition': return 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200'
      case 'sports': return 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200'
      default: return 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
    }
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-2"
      >
        <div className="flex items-center justify-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-2xl flex items-center justify-center">
            <BookOpen className="h-6 w-6 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-200">
            {t('nutrition_articles') || 'Nutrition Articles'}
          </h1>
        </div>
        <p className="text-gray-600 dark:text-gray-400">
          {t('nutrition_articles_desc') || 'Expert articles on nutrition, health, and wellness'}
        </p>
      </motion.div>

      {/* أدوات البحث والتصفية */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
      >
        <Card className="enhanced-card">
          <CardContent className="p-6">
            <div className="flex flex-col md:flex-row gap-4">
              <div className="flex-1">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input
                    placeholder={t('search_articles') || 'Search articles...'}
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>

              <select
                value={selectedCategory}
                onChange={(e) => setSelectedCategory(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="all">{t('all_categories') || 'All Categories'}</option>
                <option value="basics">{t('nutrition_basics') || 'Nutrition Basics'}</option>
                <option value="weight-loss">{t('weight_loss') || 'Weight Loss'}</option>
                <option value="nutrition">{t('general_nutrition') || 'General Nutrition'}</option>
                <option value="sports">{t('sports_nutrition') || 'Sports Nutrition'}</option>
              </select>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* عدد النتائج */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="flex items-center justify-between"
      >
        <p className="text-gray-600 dark:text-gray-400">
          {filteredArticles.length} {t('articles_found') || 'articles found'}
        </p>
        <div className="flex items-center gap-2">
          <Filter className="h-4 w-4 text-gray-500" />
          <span className="text-sm text-gray-500">
            {bookmarkedArticles.length} {t('bookmarked') || 'bookmarked'}
          </span>
        </div>
      </motion.div>

      {/* قائمة المقالات */}
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.3 }}
        className="space-y-6"
      >
        {filteredArticles.map((article, index) => (
          <motion.div
            key={article.id}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 * index }}
          >
            <Card className="enhanced-card hover:shadow-xl transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex flex-col lg:flex-row gap-6">
                  {/* محتوى المقال */}
                  <div className="flex-1 space-y-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2">
                        <div className="flex items-center gap-2">
                          <Badge className={getCategoryColor(article.category)}>
                            {t(article.category) || article.category}
                          </Badge>
                          <span className="text-4xl">{article.image}</span>
                        </div>
                        <h2 className="text-xl font-bold text-gray-800 dark:text-gray-200 leading-tight">
                          {article.title}
                        </h2>
                      </div>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleBookmark(article.id)}
                        className={bookmarkedArticles.includes(article.id) ? 'text-yellow-500' : 'text-gray-400'}
                      >
                        <Bookmark className={`h-5 w-5 ${bookmarkedArticles.includes(article.id) ? 'fill-current' : ''}`} />
                      </Button>
                    </div>

                    <p className="text-gray-600 dark:text-gray-400 leading-relaxed">
                      {article.excerpt}
                    </p>

                    {/* معلومات المقال */}
                    <div className="flex items-center gap-4 text-sm text-gray-500 dark:text-gray-400">
                      <div className="flex items-center gap-1">
                        <User className="h-4 w-4" />
                        <span>{article.author}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        <span>{article.readTime} {t('min_read') || 'min read'}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <span>{new Date(article.publishDate).toLocaleDateString(language === 'ar' ? 'ar-SA' : 'en-US')}</span>
                      </div>
                    </div>

                    {/* العلامات */}
                    <div className="flex flex-wrap gap-2">
                      {article.tags.slice(0, 4).map((tag, tagIndex) => (
                        <Badge key={tagIndex} variant="outline" className="text-xs">
                          #{t(tag) || tag}
                        </Badge>
                      ))}
                      {article.tags.length > 4 && (
                        <Badge variant="outline" className="text-xs">
                          +{article.tags.length - 4}
                        </Badge>
                      )}
                    </div>

                    {/* أزرار الإجراءات */}
                    <div className="flex gap-3 pt-2">
                      <Button className="flex-1">
                        {t('read_article') || 'Read Article'}
                      </Button>
                      <Button variant="outline" size="sm">
                        <Share2 className="h-4 w-4 mr-1" />
                        {t('share') || 'Share'}
                      </Button>
                      <Button variant="outline" size="sm">
                        <Heart className="h-4 w-4 mr-1" />
                        {t('like') || 'Like'}
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </motion.div>

      {/* رسالة عدم وجود نتائج */}
      {filteredArticles.length === 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-center py-12"
        >
          <BookOpen className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 dark:text-gray-400 mb-2">
            {t('no_articles_found') || 'No articles found'}
          </h3>
          <p className="text-gray-500 dark:text-gray-500">
            {t('try_different_search') || 'Try a different search term or category'}
          </p>
        </motion.div>
      )}
    </div>
  )
}

export default NutritionArticles

