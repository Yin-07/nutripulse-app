import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Scale, User, Ruler } from 'lucide-react';

const IdealWeight = () => {
  const [formData, setFormData] = useState({
    height: '',
    gender: '',
    age: '',
    bodyType: 'medium'
  });
  const [results, setResults] = useState(null);
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.height || formData.height < 100 || formData.height > 250) {
      newErrors.height = 'يرجى إدخال طول صحيح بين 100-250 سم';
    }
    
    if (!formData.gender) {
      newErrors.gender = 'يرجى اختيار الجنس';
    }
    
    if (!formData.age || formData.age < 1 || formData.age > 120) {
      newErrors.age = 'يرجى إدخال عمر صحيح بين 1-120 سنة';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const calculateIdealWeight = () => {
    if (!validateForm()) return;

    const height = parseFloat(formData.height);
    const age = parseInt(formData.age);
    const { gender, bodyType } = formData;

    // حساب الوزن المثالي باستخدام عدة معادلات
    const heightInM = height / 100;
    
    // معادلة Devine
    let devineWeight;
    if (gender === 'male') {
      devineWeight = 50 + 2.3 * ((height - 152.4) / 2.54);
    } else {
      devineWeight = 45.5 + 2.3 * ((height - 152.4) / 2.54);
    }

    // معادلة Robinson
    let robinsonWeight;
    if (gender === 'male') {
      robinsonWeight = 52 + 1.9 * ((height - 152.4) / 2.54);
    } else {
      robinsonWeight = 49 + 1.7 * ((height - 152.4) / 2.54);
    }

    // معادلة Miller
    let millerWeight;
    if (gender === 'male') {
      millerWeight = 56.2 + 1.41 * ((height - 152.4) / 2.54);
    } else {
      millerWeight = 53.1 + 1.36 * ((height - 152.4) / 2.54);
    }

    // حساب المتوسط
    const averageWeight = (devineWeight + robinsonWeight + millerWeight) / 3;

    // تعديل حسب نوع الجسم
    let adjustedWeight = averageWeight;
    if (bodyType === 'small') {
      adjustedWeight *= 0.9;
    } else if (bodyType === 'large') {
      adjustedWeight *= 1.1;
    }

    // حساب النطاق الصحي
    const minWeight = adjustedWeight * 0.9;
    const maxWeight = adjustedWeight * 1.1;

    // حساب BMI للوزن المثالي
    const idealBMI = adjustedWeight / (heightInM * heightInM);

    setResults({
      idealWeight: Math.round(adjustedWeight * 10) / 10,
      minWeight: Math.round(minWeight * 10) / 10,
      maxWeight: Math.round(maxWeight * 10) / 10,
      idealBMI: Math.round(idealBMI * 10) / 10,
      devine: Math.round(devineWeight * 10) / 10,
      robinson: Math.round(robinsonWeight * 10) / 10,
      miller: Math.round(millerWeight * 10) / 10
    });
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8"
      >
        <div className="flex items-center gap-3 mb-6">
          <Scale className="w-8 h-8 text-blue-600" />
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">حاسبة الوزن المثالي</h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* نموذج الإدخال */}
          <div className="space-y-6">
            {/* الطول */}
            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <Ruler className="w-4 h-4" />
                الطول (سم)
              </label>
              <input
                type="number"
                value={formData.height}
                onChange={(e) => handleInputChange('height', e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                placeholder="مثال: 170"
              />
              {errors.height && (
                <p className="text-red-500 text-sm mt-1">{errors.height}</p>
              )}
            </div>

            {/* الجنس */}
            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <User className="w-4 h-4" />
                الجنس
              </label>
              <select
                value={formData.gender}
                onChange={(e) => handleInputChange('gender', e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
              >
                <option value="">اختر الجنس</option>
                <option value="male">ذكر</option>
                <option value="female">أنثى</option>
              </select>
              {errors.gender && (
                <p className="text-red-500 text-sm mt-1">{errors.gender}</p>
              )}
            </div>

            {/* العمر */}
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                العمر (سنة)
              </label>
              <input
                type="number"
                value={formData.age}
                onChange={(e) => handleInputChange('age', e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                placeholder="مثال: 30"
              />
              {errors.age && (
                <p className="text-red-500 text-sm mt-1">{errors.age}</p>
              )}
            </div>

            {/* نوع الجسم */}
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                نوع الجسم
              </label>
              <select
                value={formData.bodyType}
                onChange={(e) => handleInputChange('bodyType', e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
              >
                <option value="small">صغير البنية</option>
                <option value="medium">متوسط البنية</option>
                <option value="large">كبير البنية</option>
              </select>
            </div>

            <motion.button
              onClick={calculateIdealWeight}
              className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-blue-700 hover:to-purple-700 transition-all duration-300 shadow-lg"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              احسب الوزن المثالي
            </motion.button>
          </div>

          {/* النتائج */}
          {results && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-4">النتائج</h3>
              
              <div className="bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 p-4 rounded-lg">
                <h4 className="font-semibold text-gray-800 dark:text-white mb-2">الوزن المثالي</h4>
                <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">{results.idealWeight} كجم</p>
              </div>

              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
                <h4 className="font-semibold text-gray-800 dark:text-white mb-2">النطاق الصحي</h4>
                <p className="text-lg text-green-600 dark:text-green-400">
                  {results.minWeight} - {results.maxWeight} كجم
                </p>
              </div>

              <div className="bg-gray-50 dark:bg-gray-700 p-4 rounded-lg">
                <h4 className="font-semibold text-gray-800 dark:text-white mb-2">مؤشر كتلة الجسم المثالي</h4>
                <p className="text-lg text-gray-600 dark:text-gray-300">{results.idealBMI}</p>
              </div>

              <div className="bg-yellow-50 dark:bg-yellow-900/20 p-4 rounded-lg">
                <h4 className="font-semibold text-gray-800 dark:text-white mb-2">حسب المعادلات المختلفة</h4>
                <div className="space-y-1 text-sm">
                  <p className="text-gray-600 dark:text-gray-300">معادلة Devine: {results.devine} كجم</p>
                  <p className="text-gray-600 dark:text-gray-300">معادلة Robinson: {results.robinson} كجم</p>
                  <p className="text-gray-600 dark:text-gray-300">معادلة Miller: {results.miller} كجم</p>
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default IdealWeight;

