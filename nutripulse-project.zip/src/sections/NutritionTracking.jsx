import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Activity, Plus, Trash2, Search, Calendar } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip } from 'recharts';

const NutritionTracking = () => {
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split('T')[0]);
  const [dailyEntries, setDailyEntries] = useState([]);
  const [newFood, setNewFood] = useState({
    name: '',
    calories: '',
    protein: '',
    carbs: '',
    fat: '',
    quantity: '100'
  });
  const [showAddForm, setShowAddForm] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');

  // قاعدة بيانات الأطعمة الشائعة
  const commonFoods = [
    { name: 'أرز أبيض مطبوخ', calories: 130, protein: 2.7, carbs: 28, fat: 0.3 },
    { name: 'دجاج مشوي', calories: 165, protein: 31, carbs: 0, fat: 3.6 },
    { name: 'خبز أبيض', calories: 265, protein: 9, carbs: 49, fat: 3.2 },
    { name: 'بيض مسلوق', calories: 155, protein: 13, carbs: 1.1, fat: 11 },
    { name: 'تفاح', calories: 52, protein: 0.3, carbs: 14, fat: 0.2 },
    { name: 'موز', calories: 89, protein: 1.1, carbs: 23, fat: 0.3 },
    { name: 'حليب كامل الدسم', calories: 61, protein: 3.2, carbs: 4.8, fat: 3.3 },
    { name: 'زيت زيتون', calories: 884, protein: 0, carbs: 0, fat: 100 },
    { name: 'لحم بقري', calories: 250, protein: 26, carbs: 0, fat: 15 },
    { name: 'سمك سلمون', calories: 208, protein: 20, carbs: 0, fat: 13 },
    { name: 'جبن أبيض', calories: 264, protein: 18, carbs: 1.3, fat: 21 },
    { name: 'خيار', calories: 16, protein: 0.7, carbs: 4, fat: 0.1 },
    { name: 'طماطم', calories: 18, protein: 0.9, carbs: 3.9, fat: 0.2 },
    { name: 'خس', calories: 15, protein: 1.4, carbs: 2.9, fat: 0.2 },
    { name: 'جزر', calories: 41, protein: 0.9, carbs: 10, fat: 0.2 }
  ];

  // تحميل البيانات من localStorage
  useEffect(() => {
    const savedData = localStorage.getItem('nutritionTracking');
    if (savedData) {
      const allData = JSON.parse(savedData);
      setDailyEntries(allData[selectedDate] || []);
    }
  }, [selectedDate]);

  // حفظ البيانات في localStorage
  const saveData = (entries) => {
    const savedData = localStorage.getItem('nutritionTracking');
    const allData = savedData ? JSON.parse(savedData) : {};
    allData[selectedDate] = entries;
    localStorage.setItem('nutritionTracking', JSON.stringify(allData));
  };

  const addFood = () => {
    if (!newFood.name || !newFood.calories) return;

    const quantity = parseFloat(newFood.quantity) || 100;
    const multiplier = quantity / 100;

    const entry = {
      id: Date.now(),
      name: newFood.name,
      quantity: quantity,
      calories: Math.round(parseFloat(newFood.calories) * multiplier),
      protein: Math.round(parseFloat(newFood.protein || 0) * multiplier * 10) / 10,
      carbs: Math.round(parseFloat(newFood.carbs || 0) * multiplier * 10) / 10,
      fat: Math.round(parseFloat(newFood.fat || 0) * multiplier * 10) / 10,
      time: new Date().toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })
    };

    const updatedEntries = [...dailyEntries, entry];
    setDailyEntries(updatedEntries);
    saveData(updatedEntries);

    setNewFood({
      name: '',
      calories: '',
      protein: '',
      carbs: '',
      fat: '',
      quantity: '100'
    });
    setShowAddForm(false);
  };

  const deleteFood = (id) => {
    const updatedEntries = dailyEntries.filter(entry => entry.id !== id);
    setDailyEntries(updatedEntries);
    saveData(updatedEntries);
  };

  const selectCommonFood = (food) => {
    setNewFood({
      name: food.name,
      calories: food.calories.toString(),
      protein: food.protein.toString(),
      carbs: food.carbs.toString(),
      fat: food.fat.toString(),
      quantity: '100'
    });
  };

  // حساب الإجماليات
  const totals = dailyEntries.reduce((acc, entry) => ({
    calories: acc.calories + entry.calories,
    protein: acc.protein + entry.protein,
    carbs: acc.carbs + entry.carbs,
    fat: acc.fat + entry.fat
  }), { calories: 0, protein: 0, carbs: 0, fat: 0 });

  // بيانات الرسم البياني الدائري
  const pieData = [
    { name: 'البروتين', value: totals.protein * 4, color: '#3B82F6' },
    { name: 'الكربوهيدرات', value: totals.carbs * 4, color: '#10B981' },
    { name: 'الدهون', value: totals.fat * 9, color: '#F59E0B' }
  ];

  // تصفية الأطعمة الشائعة
  const filteredFoods = commonFoods.filter(food =>
    food.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-8"
    >
      {/* العنوان */}
      <div className="text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-pink-500 to-rose-500 rounded-full mb-4"
        >
          <Activity className="h-8 w-8 text-white" />
        </motion.div>
        <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-100 mb-2">
          تتبع المغذيات
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          تتبع ما تأكله وراقب المغذيات الكبرى
        </p>
      </div>

      {/* اختيار التاريخ */}
      <div className="enhanced-card rounded-2xl p-6">
        <div className="flex items-center justify-center gap-4">
          <Calendar className="h-5 w-5 text-gray-600 dark:text-gray-400" />
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="enhanced-input max-w-xs"
          />
        </div>
      </div>

      {/* الإحصائيات اليومية */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="enhanced-card rounded-xl p-6 text-center">
          <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
            {totals.calories}
          </div>
          <div className="text-sm text-gray-600 dark:text-gray-400">السعرات الحرارية</div>
        </div>

        <div className="enhanced-card rounded-xl p-6 text-center">
          <div className="text-3xl font-bold text-green-600 dark:text-green-400 mb-2">
            {totals.protein.toFixed(1)}g
          </div>
          <div className="text-sm text-gray-600 dark:text-gray-400">البروتين</div>
        </div>

        <div className="enhanced-card rounded-xl p-6 text-center">
          <div className="text-3xl font-bold text-yellow-600 dark:text-yellow-400 mb-2">
            {totals.carbs.toFixed(1)}g
          </div>
          <div className="text-sm text-gray-600 dark:text-gray-400">الكربوهيدرات</div>
        </div>

        <div className="enhanced-card rounded-xl p-6 text-center">
          <div className="text-3xl font-bold text-orange-600 dark:text-orange-400 mb-2">
            {totals.fat.toFixed(1)}g
          </div>
          <div className="text-sm text-gray-600 dark:text-gray-400">الدهون</div>
        </div>
      </div>

      {/* الرسم البياني الدائري */}
      {totals.calories > 0 && (
        <div className="enhanced-card rounded-2xl p-8">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-6 text-center">
            توزيع المغذيات الكبرى
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={120}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value, name) => [
                    `${Math.round(value)} سعرة (${Math.round((value / totals.calories) * 100)}%)`,
                    name
                  ]}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-6 mt-4">
            {pieData.map((entry, index) => (
              <div key={index} className="flex items-center gap-2">
                <div 
                  className="w-4 h-4 rounded-full" 
                  style={{ backgroundColor: entry.color }}
                />
                <span className="text-sm text-gray-600 dark:text-gray-400">
                  {entry.name}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* زر إضافة طعام */}
      <div className="text-center">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowAddForm(!showAddForm)}
          className="enhanced-button bg-gradient-to-r from-pink-500 to-rose-500 hover:from-pink-600 hover:to-rose-600 text-white px-8 py-3 rounded-xl font-semibold flex items-center gap-2 mx-auto"
        >
          <Plus className="h-5 w-5" />
          إضافة طعام
        </motion.button>
      </div>

      {/* نموذج إضافة الطعام */}
      {showAddForm && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="enhanced-card rounded-2xl p-8 space-y-6"
        >
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100">
            إضافة طعام جديد
          </h3>

          {/* البحث في الأطعمة الشائعة */}
          <div className="space-y-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400" />
              <input
                type="text"
                placeholder="ابحث في الأطعمة الشائعة..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="enhanced-input pl-10"
              />
            </div>

            {searchTerm && (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 max-h-60 overflow-y-auto">
                {filteredFoods.map((food, index) => (
                  <motion.button
                    key={index}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                    onClick={() => selectCommonFood(food)}
                    className="text-right p-3 bg-gray-50 dark:bg-gray-800/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700/50 transition-colors"
                  >
                    <div className="font-medium text-gray-800 dark:text-gray-100">
                      {food.name}
                    </div>
                    <div className="text-sm text-gray-600 dark:text-gray-400">
                      {food.calories} سعرة / 100g
                    </div>
                  </motion.button>
                ))}
              </div>
            )}
          </div>

          {/* نموذج الإدخال */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                اسم الطعام *
              </label>
              <input
                type="text"
                value={newFood.name}
                onChange={(e) => setNewFood(prev => ({ ...prev, name: e.target.value }))}
                placeholder="مثال: أرز أبيض"
                className="enhanced-input"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                الكمية (جرام) *
              </label>
              <input
                type="number"
                value={newFood.quantity}
                onChange={(e) => setNewFood(prev => ({ ...prev, quantity: e.target.value }))}
                placeholder="100"
                className="enhanced-input"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                السعرات الحرارية (لكل 100g) *
              </label>
              <input
                type="number"
                value={newFood.calories}
                onChange={(e) => setNewFood(prev => ({ ...prev, calories: e.target.value }))}
                placeholder="130"
                className="enhanced-input"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                البروتين (g لكل 100g)
              </label>
              <input
                type="number"
                step="0.1"
                value={newFood.protein}
                onChange={(e) => setNewFood(prev => ({ ...prev, protein: e.target.value }))}
                placeholder="2.7"
                className="enhanced-input"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                الكربوهيدرات (g لكل 100g)
              </label>
              <input
                type="number"
                step="0.1"
                value={newFood.carbs}
                onChange={(e) => setNewFood(prev => ({ ...prev, carbs: e.target.value }))}
                placeholder="28"
                className="enhanced-input"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                الدهون (g لكل 100g)
              </label>
              <input
                type="number"
                step="0.1"
                value={newFood.fat}
                onChange={(e) => setNewFood(prev => ({ ...prev, fat: e.target.value }))}
                placeholder="0.3"
                className="enhanced-input"
              />
            </div>
          </div>

          <div className="flex gap-4">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={addFood}
              disabled={!newFood.name || !newFood.calories}
              className="enhanced-button bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white px-6 py-2 rounded-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              إضافة
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => setShowAddForm(false)}
              className="enhanced-button bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg font-semibold"
            >
              إلغاء
            </motion.button>
          </div>
        </motion.div>
      )}

      {/* قائمة الأطعمة المضافة */}
      {dailyEntries.length > 0 && (
        <div className="enhanced-card rounded-2xl p-8">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-6">
            الأطعمة المتناولة اليوم
          </h3>
          <div className="space-y-4">
            {dailyEntries.map((entry) => (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 flex items-center justify-between"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-4 mb-2">
                    <span className="font-semibold text-gray-800 dark:text-gray-100">
                      {entry.name}
                    </span>
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {entry.quantity}g
                    </span>
                    <span className="text-sm text-gray-500 dark:text-gray-500">
                      {entry.time}
                    </span>
                  </div>
                  <div className="flex items-center gap-6 text-sm">
                    <span className="text-blue-600 dark:text-blue-400">
                      {entry.calories} سعرة
                    </span>
                    <span className="text-green-600 dark:text-green-400">
                      ب: {entry.protein}g
                    </span>
                    <span className="text-yellow-600 dark:text-yellow-400">
                      ك: {entry.carbs}g
                    </span>
                    <span className="text-orange-600 dark:text-orange-400">
                      د: {entry.fat}g
                    </span>
                  </div>
                </div>
                <motion.button
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  onClick={() => deleteFood(entry.id)}
                  className="p-2 text-red-600 hover:bg-red-100 dark:hover:bg-red-900/20 rounded-lg"
                >
                  <Trash2 className="h-4 w-4" />
                </motion.button>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* رسالة عدم وجود بيانات */}
      {dailyEntries.length === 0 && (
        <div className="text-center py-12">
          <Activity className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 dark:text-gray-400 mb-2">
            لم تضف أي طعام بعد
          </h3>
          <p className="text-gray-500 dark:text-gray-500">
            ابدأ بإضافة الأطعمة التي تناولتها اليوم
          </p>
        </div>
      )}
    </motion.div>
  );
};

export default NutritionTracking;

