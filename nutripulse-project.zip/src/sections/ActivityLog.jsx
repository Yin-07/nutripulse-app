import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Activity, Plus, Trash2, Calendar, Clock, Flame, Edit3, BarChart3 } from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const ActivityLog = () => {
  const [activities, setActivities] = useState([]);
  const [newActivity, setNewActivity] = useState({
    date: new Date().toISOString().split('T')[0],
    type: '',
    duration: '',
    intensity: 'moderate',
    calories: '',
    notes: ''
  });
  const [editingId, setEditingId] = useState(null);
  const [showForm, setShowForm] = useState(false);
  const [viewMode, setViewMode] = useState('list'); // 'list' or 'chart'

  // تحميل البيانات من localStorage عند بدء التشغيل
  useEffect(() => {
    const savedActivities = localStorage.getItem('activityLogEntries');
    if (savedActivities) {
      setActivities(JSON.parse(savedActivities));
    }
  }, []);

  // حفظ البيانات في localStorage عند تغيير الأنشطة
  useEffect(() => {
    localStorage.setItem('activityLogEntries', JSON.stringify(activities));
  }, [activities]);

  // قائمة الأنشطة الشائعة
  const activityTypes = [
    { name: 'المشي', caloriesPerMinute: { light: 3, moderate: 4, vigorous: 5 } },
    { name: 'الجري', caloriesPerMinute: { light: 8, moderate: 10, vigorous: 14 } },
    { name: 'ركوب الدراجة', caloriesPerMinute: { light: 5, moderate: 7, vigorous: 12 } },
    { name: 'السباحة', caloriesPerMinute: { light: 6, moderate: 8, vigorous: 10 } },
    { name: 'تمارين القوة', caloriesPerMinute: { light: 3, moderate: 5, vigorous: 8 } },
    { name: 'اليوغا', caloriesPerMinute: { light: 2, moderate: 3, vigorous: 4 } },
    { name: 'رقص', caloriesPerMinute: { light: 4, moderate: 6, vigorous: 8 } },
    { name: 'كرة قدم', caloriesPerMinute: { light: 5, moderate: 7, vigorous: 10 } },
    { name: 'كرة سلة', caloriesPerMinute: { light: 6, moderate: 8, vigorous: 12 } },
    { name: 'تنس', caloriesPerMinute: { light: 5, moderate: 7, vigorous: 9 } },
    { name: 'تمارين هوائية', caloriesPerMinute: { light: 4, moderate: 6, vigorous: 8 } },
    { name: 'تمارين منزلية', caloriesPerMinute: { light: 3, moderate: 4, vigorous: 6 } },
    { name: 'المشي لمسافات طويلة', caloriesPerMinute: { light: 4, moderate: 6, vigorous: 8 } },
    { name: 'صعود الدرج', caloriesPerMinute: { light: 5, moderate: 7, vigorous: 9 } },
    { name: 'نشاط آخر', caloriesPerMinute: { light: 3, moderate: 5, vigorous: 7 } }
  ];

  // حساب السعرات الحرارية تلقائيًا
  const calculateCalories = (type, duration, intensity) => {
    if (!type || !duration) return '';
    
    const activity = activityTypes.find(a => a.name === type);
    if (!activity) return '';
    
    return Math.round(activity.caloriesPerMinute[intensity] * parseInt(duration));
  };

  // إضافة نشاط جديد
  const addActivity = () => {
    if (!newActivity.type || !newActivity.duration) return;

    const activity = {
      id: Date.now(),
      date: newActivity.date,
      type: newActivity.type,
      duration: parseInt(newActivity.duration),
      intensity: newActivity.intensity,
      calories: newActivity.calories ? parseInt(newActivity.calories) : calculateCalories(newActivity.type, newActivity.duration, newActivity.intensity),
      notes: newActivity.notes,
      timestamp: new Date().toISOString()
    };

    if (editingId) {
      setActivities(prev => prev.map(a => a.id === editingId ? { ...activity, id: editingId } : a));
      setEditingId(null);
    } else {
      setActivities(prev => [...prev, activity].sort((a, b) => new Date(b.date) - new Date(a.date)));
    }

    setNewActivity({
      date: new Date().toISOString().split('T')[0],
      type: '',
      duration: '',
      intensity: 'moderate',
      calories: '',
      notes: ''
    });
    setShowForm(false);
  };

  // حذف نشاط
  const deleteActivity = (id) => {
    setActivities(prev => prev.filter(a => a.id !== id));
  };

  // تعديل نشاط
  const editActivity = (activity) => {
    setNewActivity({
      date: activity.date,
      type: activity.type,
      duration: activity.duration.toString(),
      intensity: activity.intensity,
      calories: activity.calories.toString(),
      notes: activity.notes || ''
    });
    setEditingId(activity.id);
    setShowForm(true);
  };

  // الحصول على إحصائيات النشاط
  const getStats = () => {
    if (activities.length === 0) return null;

    const totalCalories = activities.reduce((sum, a) => sum + a.calories, 0);
    const totalDuration = activities.reduce((sum, a) => sum + a.duration, 0);
    
    // الحصول على الأنشطة في الأسبوع الحالي
    const now = new Date();
    const oneWeekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
    const thisWeekActivities = activities.filter(a => new Date(a.date) >= oneWeekAgo);
    
    const thisWeekCalories = thisWeekActivities.reduce((sum, a) => sum + a.calories, 0);
    const thisWeekDuration = thisWeekActivities.reduce((sum, a) => sum + a.duration, 0);

    return {
      totalActivities: activities.length,
      totalCalories,
      totalDuration,
      thisWeekActivities: thisWeekActivities.length,
      thisWeekCalories,
      thisWeekDuration,
      averageCaloriesPerActivity: Math.round(totalCalories / activities.length)
    };
  };

  const stats = getStats();

  // تحضير بيانات الرسم البياني
  const prepareChartData = () => {
    // تجميع الأنشطة حسب التاريخ
    const groupedByDate = {};
    activities.forEach(activity => {
      if (!groupedByDate[activity.date]) {
        groupedByDate[activity.date] = {
          date: activity.date,
          calories: 0,
          duration: 0,
          count: 0
        };
      }
      groupedByDate[activity.date].calories += activity.calories;
      groupedByDate[activity.date].duration += activity.duration;
      groupedByDate[activity.date].count += 1;
    });

    // تحويل إلى مصفوفة وترتيب حسب التاريخ
    return Object.values(groupedByDate)
      .sort((a, b) => new Date(a.date) - new Date(b.date))
      .map(item => ({
        ...item,
        formattedDate: new Date(item.date).toLocaleDateString('ar-SA', { month: 'short', day: 'numeric' })
      }));
  };

  const chartData = prepareChartData();

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-8"
    >
      {/* العنوان */}
      <div className="text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-teal-500 to-cyan-500 rounded-full mb-4"
        >
          <Activity className="h-8 w-8 text-white" />
        </motion.div>
        <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-100 mb-2">
          سجل النشاط البدني
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          تتبع أنشطتك البدنية والسعرات الحرارية المحروقة
        </p>
      </div>

      {/* الإحصائيات */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="enhanced-card rounded-xl p-6 text-center">
            <div className="text-3xl font-bold text-teal-600 dark:text-teal-400 mb-2">
              {stats.totalCalories}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">إجمالي السعرات المحروقة</div>
          </div>

          <div className="enhanced-card rounded-xl p-6 text-center">
            <div className="text-3xl font-bold text-cyan-600 dark:text-cyan-400 mb-2">
              {Math.floor(stats.totalDuration / 60)}:{(stats.totalDuration % 60).toString().padStart(2, '0')}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">إجمالي وقت النشاط (ساعة:دقيقة)</div>
          </div>

          <div className="enhanced-card rounded-xl p-6 text-center">
            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
              {stats.thisWeekCalories}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">سعرات هذا الأسبوع</div>
          </div>

          <div className="enhanced-card rounded-xl p-6 text-center">
            <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">
              {stats.totalActivities}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">عدد الأنشطة المسجلة</div>
          </div>
        </div>
      )}

      {/* أزرار التبديل بين العرض */}
      <div className="flex justify-center gap-4">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setViewMode('list')}
          className={`enhanced-button px-6 py-2 rounded-lg font-semibold flex items-center gap-2 ${
            viewMode === 'list' 
              ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white' 
              : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
          }`}
        >
          <Activity className="h-5 w-5" />
          قائمة الأنشطة
        </motion.button>
        
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setViewMode('chart')}
          className={`enhanced-button px-6 py-2 rounded-lg font-semibold flex items-center gap-2 ${
            viewMode === 'chart' 
              ? 'bg-gradient-to-r from-teal-500 to-cyan-500 text-white' 
              : 'bg-gray-200 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
          }`}
        >
          <BarChart3 className="h-5 w-5" />
          الرسم البياني
        </motion.button>
      </div>

      {/* زر إضافة نشاط جديد */}
      <div className="text-center">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowForm(!showForm)}
          className="enhanced-button bg-gradient-to-r from-teal-500 to-cyan-500 hover:from-teal-600 hover:to-cyan-600 text-white px-8 py-3 rounded-xl font-semibold flex items-center gap-2 mx-auto"
        >
          <Plus className="h-5 w-5" />
          إضافة نشاط جديد
        </motion.button>
      </div>

      {/* نموذج إضافة/تعديل النشاط */}
      {showForm && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="enhanced-card rounded-2xl p-8"
        >
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-6">
            {editingId ? 'تعديل النشاط' : 'إضافة نشاط جديد'}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                <Calendar className="h-4 w-4" />
                التاريخ
              </label>
              <input
                type="date"
                value={newActivity.date}
                onChange={(e) => setNewActivity(prev => ({ ...prev, date: e.target.value }))}
                className="enhanced-input"
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                <Activity className="h-4 w-4" />
                نوع النشاط *
              </label>
              <select
                value={newActivity.type}
                onChange={(e) => {
                  const newType = e.target.value;
                  setNewActivity(prev => {
                    const newState = { ...prev, type: newType };
                    if (newType && prev.duration && prev.intensity) {
                      newState.calories = calculateCalories(newType, prev.duration, prev.intensity).toString();
                    }
                    return newState;
                  });
                }}
                className="enhanced-input"
              >
                <option value="">اختر نوع النشاط</option>
                {activityTypes.map((activity, index) => (
                  <option key={index} value={activity.name}>
                    {activity.name}
                  </option>
                ))}
              </select>
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                <Clock className="h-4 w-4" />
                المدة (دقيقة) *
              </label>
              <input
                type="number"
                value={newActivity.duration}
                onChange={(e) => {
                  const newDuration = e.target.value;
                  setNewActivity(prev => {
                    const newState = { ...prev, duration: newDuration };
                    if (prev.type && newDuration && prev.intensity) {
                      newState.calories = calculateCalories(prev.type, newDuration, prev.intensity).toString();
                    }
                    return newState;
                  });
                }}
                placeholder="مثال: 30"
                className="enhanced-input"
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                <Activity className="h-4 w-4" />
                شدة النشاط
              </label>
              <select
                value={newActivity.intensity}
                onChange={(e) => {
                  const newIntensity = e.target.value;
                  setNewActivity(prev => {
                    const newState = { ...prev, intensity: newIntensity };
                    if (prev.type && prev.duration && newIntensity) {
                      newState.calories = calculateCalories(prev.type, prev.duration, newIntensity).toString();
                    }
                    return newState;
                  });
                }}
                className="enhanced-input"
              >
                <option value="light">خفيفة</option>
                <option value="moderate">متوسطة</option>
                <option value="vigorous">عالية</option>
              </select>
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                <Flame className="h-4 w-4" />
                السعرات المحروقة
              </label>
              <input
                type="number"
                value={newActivity.calories}
                onChange={(e) => setNewActivity(prev => ({ ...prev, calories: e.target.value }))}
                placeholder="سيتم حسابها تلقائيًا"
                className="enhanced-input"
              />
              <p className="text-xs text-gray-500 dark:text-gray-400">
                يتم الحساب تلقائيًا، أو يمكنك تعديلها يدويًا
              </p>
            </div>

            <div className="md:col-span-2 space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                ملاحظات - اختيارية
              </label>
              <textarea
                value={newActivity.notes}
                onChange={(e) => setNewActivity(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="أي ملاحظات حول هذا النشاط..."
                rows={3}
                className="enhanced-input"
              />
            </div>
          </div>

          <div className="flex gap-4 mt-6">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={addActivity}
              disabled={!newActivity.type || !newActivity.duration}
              className="enhanced-button bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white px-6 py-2 rounded-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {editingId ? 'تحديث' : 'إضافة'}
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => {
                setShowForm(false);
                setEditingId(null);
                setNewActivity({
                  date: new Date().toISOString().split('T')[0],
                  type: '',
                  duration: '',
                  intensity: 'moderate',
                  calories: '',
                  notes: ''
                });
              }}
              className="enhanced-button bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg font-semibold"
            >
              إلغاء
            </motion.button>
          </div>
        </motion.div>
      )}

      {/* عرض الرسم البياني */}
      {viewMode === 'chart' && chartData.length > 0 && (
        <div className="enhanced-card rounded-2xl p-8">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-6">
            تطور النشاط البدني
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="formattedDate" />
                <YAxis yAxisId="left" orientation="left" stroke="#06b6d4" />
                <YAxis yAxisId="right" orientation="right" stroke="#14b8a6" />
                <Tooltip 
                  formatter={(value, name) => [
                    name === 'calories' ? `${value} سعرة` : `${value} دقيقة`,
                    name === 'calories' ? 'السعرات المحروقة' : 'مدة النشاط'
                  ]}
                  labelFormatter={(label) => `التاريخ: ${label}`}
                />
                <Bar 
                  yAxisId="left"
                  dataKey="calories" 
                  name="calories"
                  fill="#06b6d4" 
                  radius={[4, 4, 0, 0]}
                />
                <Bar 
                  yAxisId="right"
                  dataKey="duration" 
                  name="duration"
                  fill="#14b8a6" 
                  radius={[4, 4, 0, 0]}
                />
              </BarChart>
            </ResponsiveContainer>
          </div>
          <div className="flex justify-center gap-6 mt-4">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-cyan-500" />
              <span className="text-sm text-gray-600 dark:text-gray-400">
                السعرات المحروقة
              </span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 rounded-full bg-teal-500" />
              <span className="text-sm text-gray-600 dark:text-gray-400">
                مدة النشاط (دقيقة)
              </span>
            </div>
          </div>
        </div>
      )}

      {/* قائمة الأنشطة */}
      {viewMode === 'list' && activities.length > 0 && (
        <div className="enhanced-card rounded-2xl p-8">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-6">
            سجل الأنشطة
          </h3>
          <div className="space-y-4">
            {activities.map((activity) => (
              <motion.div
                key={activity.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 flex items-center justify-between"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-4 mb-2">
                    <span className="font-semibold text-gray-800 dark:text-gray-100">
                      {new Date(activity.date).toLocaleDateString('ar-SA')}
                    </span>
                    <span className="text-lg font-bold text-teal-600 dark:text-teal-400">
                      {activity.type}
                    </span>
                    <span className="text-sm text-cyan-600 dark:text-cyan-400">
                      {Math.floor(activity.duration / 60) > 0 ? `${Math.floor(activity.duration / 60)} ساعة و ` : ''}
                      {activity.duration % 60} دقيقة
                    </span>
                  </div>
                  <div className="flex items-center gap-6 text-sm">
                    <span className="text-red-600 dark:text-red-400 flex items-center gap-1">
                      <Flame className="h-4 w-4" />
                      {activity.calories} سعرة
                    </span>
                    <span className="text-blue-600 dark:text-blue-400">
                      الشدة: {activity.intensity === 'light' ? 'خفيفة' : activity.intensity === 'moderate' ? 'متوسطة' : 'عالية'}
                    </span>
                    {activity.notes && (
                      <span className="text-gray-600 dark:text-gray-400">
                        {activity.notes}
                      </span>
                    )}
                  </div>
                </div>
                <div className="flex gap-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => editActivity(activity)}
                    className="p-2 text-blue-600 hover:bg-blue-100 dark:hover:bg-blue-900/20 rounded-lg"
                  >
                    <Edit3 className="h-4 w-4" />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => deleteActivity(activity.id)}
                    className="p-2 text-red-600 hover:bg-red-100 dark:hover:bg-red-900/20 rounded-lg"
                  >
                    <Trash2 className="h-4 w-4" />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* رسالة عدم وجود بيانات */}
      {activities.length === 0 && (
        <div className="text-center py-12">
          <Activity className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 dark:text-gray-400 mb-2">
            لا توجد أنشطة مسجلة بعد
          </h3>
          <p className="text-gray-500 dark:text-gray-500">
            ابدأ بإضافة أول نشاط لتتبع تقدمك
          </p>
        </div>
      )}

      {/* معلومات إضافية */}
      <div className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-6">
        <h4 className="font-semibold text-gray-800 dark:text-gray-100 mb-3">نصائح للاستخدام:</h4>
        <ul className="text-sm text-gray-600 dark:text-gray-400 space-y-2">
          <li>• سجل أنشطتك البدنية بانتظام للحصول على نظرة شاملة عن نشاطك</li>
          <li>• يتم حساب السعرات المحروقة تلقائيًا بناءً على نوع النشاط ومدته وشدته</li>
          <li>• يمكنك تعديل السعرات المحروقة يدويًا إذا كان لديك قياس أكثر دقة</li>
          <li>• استخدم الرسم البياني لمراقبة تقدمك عبر الزمن</li>
          <li>• حاول الوصول إلى هدف 150 دقيقة من النشاط المتوسط أسبوعيًا على الأقل</li>
        </ul>
      </div>
    </motion.div>
  );
};

export default ActivityLog;

