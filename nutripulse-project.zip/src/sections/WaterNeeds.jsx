import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Droplets, User, Scale, Thermometer, Activity } from 'lucide-react';

const WaterNeeds = () => {
  const [formData, setFormData] = useState({
    weight: '',
    age: '',
    gender: '',
    activityLevel: 'sedentary',
    climate: 'moderate',
    pregnancy: false,
    breastfeeding: false
  });
  const [results, setResults] = useState(null);
  const [errors, setErrors] = useState({});

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.weight || formData.weight < 5 || formData.weight > 300) {
      newErrors.weight = 'يرجى إدخال وزن صحيح بين 5-300 كجم';
    }
    
    if (!formData.age || formData.age < 1 || formData.age > 120) {
      newErrors.age = 'يرجى إدخال عمر صحيح بين 1-120 سنة';
    }
    
    if (!formData.gender) {
      newErrors.gender = 'يرجى اختيار الجنس';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const calculateWaterNeeds = () => {
    if (!validateForm()) return;

    const weight = parseFloat(formData.weight);
    const age = parseInt(formData.age);
    const { gender, activityLevel, climate, pregnancy, breastfeeding } = formData;

    // الحساب الأساسي: 35 مل لكل كيلوغرام من وزن الجسم
    let baseWater = weight * 35;

    // تعديل حسب العمر
    if (age < 18) {
      baseWater *= 1.1; // الأطفال والمراهقون يحتاجون المزيد
    } else if (age > 65) {
      baseWater *= 0.9; // كبار السن قد يحتاجون أقل
    }

    // تعديل حسب الجنس
    if (gender === 'male') {
      baseWater *= 1.1;
    }

    // تعديل حسب مستوى النشاط
    const activityMultipliers = {
      sedentary: 1.0,
      light: 1.2,
      moderate: 1.4,
      active: 1.6,
      very_active: 1.8
    };
    baseWater *= activityMultipliers[activityLevel];

    // تعديل حسب المناخ
    const climateMultipliers = {
      cold: 0.9,
      moderate: 1.0,
      hot: 1.3,
      very_hot: 1.5
    };
    baseWater *= climateMultipliers[climate];

    // تعديلات خاصة للنساء
    if (pregnancy) {
      baseWater += 300; // 300 مل إضافية للحمل
    }
    if (breastfeeding) {
      baseWater += 700; // 700 مل إضافية للرضاعة
    }

    // تحويل إلى لترات
    const waterInLiters = baseWater / 1000;

    // حساب عدد الأكواب (كوب = 250 مل)
    const cupsNeeded = Math.ceil(baseWater / 250);

    // توزيع على مدار اليوم
    const hourlyIntake = Math.round((baseWater / 16) * 10) / 10; // 16 ساعة استيقاظ

    setResults({
      totalWater: Math.round(baseWater),
      waterInLiters: Math.round(waterInLiters * 10) / 10,
      cupsNeeded,
      hourlyIntake,
      recommendations: getRecommendations(activityLevel, climate, age, gender)
    });
  };

  const getRecommendations = (activity, climate, age, gender) => {
    const tips = [];
    
    if (activity === 'very_active' || activity === 'active') {
      tips.push('اشرب الماء قبل وأثناء وبعد التمرين');
      tips.push('راقب لون البول للتأكد من الترطيب الكافي');
    }
    
    if (climate === 'hot' || climate === 'very_hot') {
      tips.push('زد من شرب الماء في الطقس الحار');
      tips.push('تجنب المشروبات المحتوية على الكافيين في الحر');
    }
    
    if (age > 65) {
      tips.push('كبار السن أكثر عرضة للجفاف، اشرب بانتظام');
    }
    
    if (age < 18) {
      tips.push('الأطفال والمراهقون يحتاجون المزيد من الماء للنمو');
    }
    
    tips.push('ابدأ يومك بكوب من الماء');
    tips.push('اشرب الماء مع كل وجبة');
    tips.push('احمل زجاجة ماء معك دائماً');
    
    return tips;
  };

  const handleInputChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    if (errors[field]) {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
  };

  return (
    <div className="max-w-4xl mx-auto p-6">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl p-8"
      >
        <div className="flex items-center gap-3 mb-6">
          <Droplets className="w-8 h-8 text-blue-600" />
          <h2 className="text-2xl font-bold text-gray-800 dark:text-white">حاسبة احتياجات الماء اليومية</h2>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* نموذج الإدخال */}
          <div className="space-y-6">
            {/* الوزن */}
            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <Scale className="w-4 h-4" />
                الوزن (كجم)
              </label>
              <input
                type="number"
                value={formData.weight}
                onChange={(e) => handleInputChange('weight', e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                placeholder="مثال: 70"
              />
              {errors.weight && (
                <p className="text-red-500 text-sm mt-1">{errors.weight}</p>
              )}
            </div>

            {/* العمر */}
            <div>
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2 block">
                العمر (سنة)
              </label>
              <input
                type="number"
                value={formData.age}
                onChange={(e) => handleInputChange('age', e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
                placeholder="مثال: 30"
              />
              {errors.age && (
                <p className="text-red-500 text-sm mt-1">{errors.age}</p>
              )}
            </div>

            {/* الجنس */}
            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <User className="w-4 h-4" />
                الجنس
              </label>
              <select
                value={formData.gender}
                onChange={(e) => handleInputChange('gender', e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
              >
                <option value="">اختر الجنس</option>
                <option value="male">ذكر</option>
                <option value="female">أنثى</option>
              </select>
              {errors.gender && (
                <p className="text-red-500 text-sm mt-1">{errors.gender}</p>
              )}
            </div>

            {/* مستوى النشاط */}
            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <Activity className="w-4 h-4" />
                مستوى النشاط
              </label>
              <select
                value={formData.activityLevel}
                onChange={(e) => handleInputChange('activityLevel', e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
              >
                <option value="sedentary">قليل الحركة</option>
                <option value="light">نشاط خفيف</option>
                <option value="moderate">نشاط متوسط</option>
                <option value="active">نشاط عالي</option>
                <option value="very_active">نشاط عالي جداً</option>
              </select>
            </div>

            {/* المناخ */}
            <div>
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
                <Thermometer className="w-4 h-4" />
                المناخ
              </label>
              <select
                value={formData.climate}
                onChange={(e) => handleInputChange('climate', e.target.value)}
                className="w-full p-3 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:bg-gray-700 dark:text-white"
              >
                <option value="cold">بارد</option>
                <option value="moderate">معتدل</option>
                <option value="hot">حار</option>
                <option value="very_hot">حار جداً</option>
              </select>
            </div>

            {/* خيارات خاصة للنساء */}
            {formData.gender === 'female' && (
              <div className="space-y-3">
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="pregnancy"
                    checked={formData.pregnancy}
                    onChange={(e) => handleInputChange('pregnancy', e.target.checked)}
                    className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                  />
                  <label htmlFor="pregnancy" className="text-sm text-gray-700 dark:text-gray-300">
                    حامل
                  </label>
                </div>
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    id="breastfeeding"
                    checked={formData.breastfeeding}
                    onChange={(e) => handleInputChange('breastfeeding', e.target.checked)}
                    className="w-4 h-4 text-blue-600 rounded focus:ring-blue-500"
                  />
                  <label htmlFor="breastfeeding" className="text-sm text-gray-700 dark:text-gray-300">
                    مرضعة
                  </label>
                </div>
              </div>
            )}

            <motion.button
              onClick={calculateWaterNeeds}
              className="w-full bg-gradient-to-r from-blue-600 to-cyan-600 text-white py-3 px-6 rounded-lg font-semibold hover:from-blue-700 hover:to-cyan-700 transition-all duration-300 shadow-lg"
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
            >
              احسب احتياجات الماء
            </motion.button>
          </div>

          {/* النتائج */}
          {results && (
            <motion.div
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              className="space-y-4"
            >
              <h3 className="text-xl font-bold text-gray-800 dark:text-white mb-4">النتائج</h3>
              
              <div className="bg-gradient-to-r from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20 p-4 rounded-lg">
                <h4 className="font-semibold text-gray-800 dark:text-white mb-2">الاحتياج اليومي</h4>
                <p className="text-2xl font-bold text-blue-600 dark:text-blue-400 mb-1">
                  {results.waterInLiters} لتر
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  ({results.totalWater} مل)
                </p>
              </div>

              <div className="bg-cyan-50 dark:bg-cyan-900/20 p-4 rounded-lg">
                <h4 className="font-semibold text-gray-800 dark:text-white mb-2">عدد الأكواب</h4>
                <p className="text-xl font-bold text-cyan-600 dark:text-cyan-400">
                  {results.cupsNeeded} كوب
                </p>
                <p className="text-sm text-gray-600 dark:text-gray-300">
                  (كوب = 250 مل)
                </p>
              </div>

              <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-lg">
                <h4 className="font-semibold text-gray-800 dark:text-white mb-2">التوزيع على مدار اليوم</h4>
                <p className="text-lg text-blue-600 dark:text-blue-400">
                  {results.hourlyIntake} مل كل ساعة
                </p>
              </div>

              <div className="bg-green-50 dark:bg-green-900/20 p-4 rounded-lg">
                <h4 className="font-semibold text-gray-800 dark:text-white mb-3">نصائح مهمة</h4>
                <div className="space-y-2">
                  {results.recommendations.map((tip, index) => (
                    <p key={index} className="text-sm text-gray-600 dark:text-gray-300 flex items-start gap-2">
                      <span className="text-green-500 mt-1">•</span>
                      {tip}
                    </p>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </div>
      </motion.div>
    </div>
  );
};

export default WaterNeeds;

