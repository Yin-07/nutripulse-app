import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Scale, Plus, Trash2, TrendingUp, TrendingDown, Calendar, Edit3 } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

const WeightLog = () => {
  const [entries, setEntries] = useState([]);
  const [newEntry, setNewEntry] = useState({
    date: new Date().toISOString().split('T')[0],
    weight: '',
    bodyFat: '',
    muscleMass: '',
    notes: ''
  });
  const [editingId, setEditingId] = useState(null);
  const [showForm, setShowForm] = useState(false);

  // تحميل البيانات من localStorage عند بدء التشغيل
  useEffect(() => {
    const savedEntries = localStorage.getItem('weightLogEntries');
    if (savedEntries) {
      setEntries(JSON.parse(savedEntries));
    }
  }, []);

  // حفظ البيانات في localStorage عند تغيير الإدخالات
  useEffect(() => {
    localStorage.setItem('weightLogEntries', JSON.stringify(entries));
  }, [entries]);

  const addEntry = () => {
    if (!newEntry.weight) return;

    const entry = {
      id: Date.now(),
      date: newEntry.date,
      weight: parseFloat(newEntry.weight),
      bodyFat: newEntry.bodyFat ? parseFloat(newEntry.bodyFat) : null,
      muscleMass: newEntry.muscleMass ? parseFloat(newEntry.muscleMass) : null,
      notes: newEntry.notes
    };

    if (editingId) {
      setEntries(prev => prev.map(e => e.id === editingId ? { ...entry, id: editingId } : e));
      setEditingId(null);
    } else {
      setEntries(prev => [...prev, entry].sort((a, b) => new Date(b.date) - new Date(a.date)));
    }

    setNewEntry({
      date: new Date().toISOString().split('T')[0],
      weight: '',
      bodyFat: '',
      muscleMass: '',
      notes: ''
    });
    setShowForm(false);
  };

  const deleteEntry = (id) => {
    setEntries(prev => prev.filter(e => e.id !== id));
  };

  const editEntry = (entry) => {
    setNewEntry({
      date: entry.date,
      weight: entry.weight.toString(),
      bodyFat: entry.bodyFat ? entry.bodyFat.toString() : '',
      muscleMass: entry.muscleMass ? entry.muscleMass.toString() : '',
      notes: entry.notes || ''
    });
    setEditingId(entry.id);
    setShowForm(true);
  };

  const getStats = () => {
    if (entries.length === 0) return null;

    const sortedEntries = [...entries].sort((a, b) => new Date(a.date) - new Date(b.date));
    const latest = sortedEntries[sortedEntries.length - 1];
    const previous = sortedEntries[sortedEntries.length - 2];
    
    const weightChange = previous ? latest.weight - previous.weight : 0;
    const totalChange = sortedEntries.length > 1 ? latest.weight - sortedEntries[0].weight : 0;

    return {
      currentWeight: latest.weight,
      weightChange,
      totalChange,
      entriesCount: entries.length,
      averageWeight: entries.reduce((sum, e) => sum + e.weight, 0) / entries.length
    };
  };

  const stats = getStats();

  // تحضير البيانات للرسم البياني
  const chartData = entries
    .sort((a, b) => new Date(a.date) - new Date(b.date))
    .map(entry => ({
      date: new Date(entry.date).toLocaleDateString('ar-SA', { month: 'short', day: 'numeric' }),
      weight: entry.weight,
      bodyFat: entry.bodyFat,
      muscleMass: entry.muscleMass
    }));

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="space-y-8"
    >
      {/* العنوان */}
      <div className="text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
          className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-r from-indigo-500 to-purple-500 rounded-full mb-4"
        >
          <Scale className="h-8 w-8 text-white" />
        </motion.div>
        <h2 className="text-3xl font-bold text-gray-800 dark:text-gray-100 mb-2">
          سجل الوزن والقياسات
        </h2>
        <p className="text-gray-600 dark:text-gray-400">
          تتبع تقدمك في الوزن وتركيب الجسم
        </p>
      </div>

      {/* الإحصائيات */}
      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          <div className="enhanced-card rounded-xl p-6 text-center">
            <div className="text-3xl font-bold text-blue-600 dark:text-blue-400 mb-2">
              {stats.currentWeight} كجم
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">الوزن الحالي</div>
          </div>

          <div className="enhanced-card rounded-xl p-6 text-center">
            <div className={`text-3xl font-bold mb-2 flex items-center justify-center gap-2 ${
              stats.weightChange > 0 ? 'text-red-600 dark:text-red-400' : 
              stats.weightChange < 0 ? 'text-green-600 dark:text-green-400' : 
              'text-gray-600 dark:text-gray-400'
            }`}>
              {stats.weightChange > 0 ? <TrendingUp className="h-6 w-6" /> : 
               stats.weightChange < 0 ? <TrendingDown className="h-6 w-6" /> : null}
              {stats.weightChange > 0 ? '+' : ''}{stats.weightChange.toFixed(1)} كجم
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">التغيير الأخير</div>
          </div>

          <div className="enhanced-card rounded-xl p-6 text-center">
            <div className={`text-3xl font-bold mb-2 ${
              stats.totalChange > 0 ? 'text-red-600 dark:text-red-400' : 
              stats.totalChange < 0 ? 'text-green-600 dark:text-green-400' : 
              'text-gray-600 dark:text-gray-400'
            }`}>
              {stats.totalChange > 0 ? '+' : ''}{stats.totalChange.toFixed(1)} كجم
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">التغيير الإجمالي</div>
          </div>

          <div className="enhanced-card rounded-xl p-6 text-center">
            <div className="text-3xl font-bold text-purple-600 dark:text-purple-400 mb-2">
              {stats.entriesCount}
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-400">عدد القياسات</div>
          </div>
        </div>
      )}

      {/* الرسم البياني */}
      {chartData.length > 1 && (
        <div className="enhanced-card rounded-2xl p-8">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-6">
            تطور الوزن عبر الزمن
          </h3>
          <div className="h-80">
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip 
                  labelFormatter={(label) => `التاريخ: ${label}`}
                  formatter={(value, name) => [
                    `${value} ${name === 'weight' ? 'كجم' : '%'}`,
                    name === 'weight' ? 'الوزن' : name === 'bodyFat' ? 'نسبة الدهون' : 'كتلة العضلات'
                  ]}
                />
                <Line 
                  type="monotone" 
                  dataKey="weight" 
                  stroke="#3B82F6" 
                  strokeWidth={3}
                  dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
                />
                {chartData.some(d => d.bodyFat) && (
                  <Line 
                    type="monotone" 
                    dataKey="bodyFat" 
                    stroke="#EF4444" 
                    strokeWidth={2}
                    dot={{ fill: '#EF4444', strokeWidth: 2, r: 3 }}
                  />
                )}
                {chartData.some(d => d.muscleMass) && (
                  <Line 
                    type="monotone" 
                    dataKey="muscleMass" 
                    stroke="#10B981" 
                    strokeWidth={2}
                    dot={{ fill: '#10B981', strokeWidth: 2, r: 3 }}
                  />
                )}
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>
      )}

      {/* زر إضافة قياس جديد */}
      <div className="text-center">
        <motion.button
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
          onClick={() => setShowForm(!showForm)}
          className="enhanced-button bg-gradient-to-r from-indigo-500 to-purple-500 hover:from-indigo-600 hover:to-purple-600 text-white px-8 py-3 rounded-xl font-semibold flex items-center gap-2 mx-auto"
        >
          <Plus className="h-5 w-5" />
          إضافة قياس جديد
        </motion.button>
      </div>

      {/* نموذج إضافة/تعديل القياس */}
      {showForm && (
        <motion.div
          initial={{ opacity: 0, height: 0 }}
          animate={{ opacity: 1, height: 'auto' }}
          exit={{ opacity: 0, height: 0 }}
          className="enhanced-card rounded-2xl p-8"
        >
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-6">
            {editingId ? 'تعديل القياس' : 'إضافة قياس جديد'}
          </h3>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                <Calendar className="h-4 w-4" />
                التاريخ
              </label>
              <input
                type="date"
                value={newEntry.date}
                onChange={(e) => setNewEntry(prev => ({ ...prev, date: e.target.value }))}
                className="enhanced-input"
              />
            </div>

            <div className="space-y-2">
              <label className="flex items-center gap-2 text-sm font-medium text-gray-700 dark:text-gray-300">
                <Scale className="h-4 w-4" />
                الوزن (كجم) *
              </label>
              <input
                type="number"
                step="0.1"
                value={newEntry.weight}
                onChange={(e) => setNewEntry(prev => ({ ...prev, weight: e.target.value }))}
                placeholder="مثال: 70.5"
                className="enhanced-input"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                نسبة الدهون (%) - اختيارية
              </label>
              <input
                type="number"
                step="0.1"
                value={newEntry.bodyFat}
                onChange={(e) => setNewEntry(prev => ({ ...prev, bodyFat: e.target.value }))}
                placeholder="مثال: 15.5"
                className="enhanced-input"
              />
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                كتلة العضلات (%) - اختيارية
              </label>
              <input
                type="number"
                step="0.1"
                value={newEntry.muscleMass}
                onChange={(e) => setNewEntry(prev => ({ ...prev, muscleMass: e.target.value }))}
                placeholder="مثال: 45.2"
                className="enhanced-input"
              />
            </div>

            <div className="md:col-span-2 space-y-2">
              <label className="text-sm font-medium text-gray-700 dark:text-gray-300">
                ملاحظات - اختيارية
              </label>
              <textarea
                value={newEntry.notes}
                onChange={(e) => setNewEntry(prev => ({ ...prev, notes: e.target.value }))}
                placeholder="أي ملاحظات حول هذا القياس..."
                rows={3}
                className="enhanced-input"
              />
            </div>
          </div>

          <div className="flex gap-4 mt-6">
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={addEntry}
              disabled={!newEntry.weight}
              className="enhanced-button bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white px-6 py-2 rounded-lg font-semibold disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {editingId ? 'تحديث' : 'إضافة'}
            </motion.button>
            <motion.button
              whileHover={{ scale: 1.02 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => {
                setShowForm(false);
                setEditingId(null);
                setNewEntry({
                  date: new Date().toISOString().split('T')[0],
                  weight: '',
                  bodyFat: '',
                  muscleMass: '',
                  notes: ''
                });
              }}
              className="enhanced-button bg-gray-500 hover:bg-gray-600 text-white px-6 py-2 rounded-lg font-semibold"
            >
              إلغاء
            </motion.button>
          </div>
        </motion.div>
      )}

      {/* قائمة القياسات */}
      {entries.length > 0 && (
        <div className="enhanced-card rounded-2xl p-8">
          <h3 className="text-xl font-bold text-gray-800 dark:text-gray-100 mb-6">
            سجل القياسات
          </h3>
          <div className="space-y-4">
            {entries.map((entry) => (
              <motion.div
                key={entry.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                className="bg-gray-50 dark:bg-gray-800/50 rounded-xl p-4 flex items-center justify-between"
              >
                <div className="flex-1">
                  <div className="flex items-center gap-4 mb-2">
                    <span className="font-semibold text-gray-800 dark:text-gray-100">
                      {new Date(entry.date).toLocaleDateString('ar-SA')}
                    </span>
                    <span className="text-2xl font-bold text-blue-600 dark:text-blue-400">
                      {entry.weight} كجم
                    </span>
                    {entry.bodyFat && (
                      <span className="text-sm text-red-600 dark:text-red-400">
                        دهون: {entry.bodyFat}%
                      </span>
                    )}
                    {entry.muscleMass && (
                      <span className="text-sm text-green-600 dark:text-green-400">
                        عضلات: {entry.muscleMass}%
                      </span>
                    )}
                  </div>
                  {entry.notes && (
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {entry.notes}
                    </p>
                  )}
                </div>
                <div className="flex gap-2">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => editEntry(entry)}
                    className="p-2 text-blue-600 hover:bg-blue-100 dark:hover:bg-blue-900/20 rounded-lg"
                  >
                    <Edit3 className="h-4 w-4" />
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                    onClick={() => deleteEntry(entry.id)}
                    className="p-2 text-red-600 hover:bg-red-100 dark:hover:bg-red-900/20 rounded-lg"
                  >
                    <Trash2 className="h-4 w-4" />
                  </motion.button>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      )}

      {/* رسالة عدم وجود بيانات */}
      {entries.length === 0 && (
        <div className="text-center py-12">
          <Scale className="h-16 w-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-600 dark:text-gray-400 mb-2">
            لا توجد قياسات بعد
          </h3>
          <p className="text-gray-500 dark:text-gray-500">
            ابدأ بإضافة أول قياس لتتبع تقدمك
          </p>
        </div>
      )}
    </motion.div>
  );
};

export default WeightLog;

