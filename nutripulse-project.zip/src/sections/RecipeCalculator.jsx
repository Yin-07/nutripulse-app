import React, { useState, useEffect } from 'react'
import { motion } from 'framer-motion'
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card'
import { Button } from '../components/ui/button'
import { Input } from '../components/ui/input'
import { Label } from '../components/ui/label'
import { Textarea } from '../components/ui/textarea'
import { Badge } from '../components/ui/badge'
import { Calculator, Plus, Minus, Save, Share2, Printer, ChefHat, Trash2 } from 'lucide-react'

const RecipeCalculator = ({ language, translations }) => {
  const t = (key) => translations[language]?.[key] || key

  const [recipeName, setRecipeName] = useState('')
  const [servings, setServings] = useState(4)
  const [ingredients, setIngredients] = useState([
    { name: '', amount: '', unit: 'g', calories: 0, protein: 0, carbs: 0, fat: 0 }
  ])
  const [instructions, setInstructions] = useState('')
  const [totalNutrition, setTotalNutrition] = useState({
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
    fiber: 0
  })

  // قاعدة بيانات المكونات الشائعة
  const commonIngredients = {
    // البروتينات
    'chicken_breast': { calories: 165, protein: 31, carbs: 0, fat: 3.6, fiber: 0 },
    'salmon': { calories: 208, protein: 22, carbs: 0, fat: 12, fiber: 0 },
    'eggs': { calories: 155, protein: 13, carbs: 1.1, fat: 11, fiber: 0 },
    'tofu': { calories: 76, protein: 8, carbs: 1.9, fat: 4.8, fiber: 0.3 },
    
    // الكربوهيدرات
    'rice': { calories: 130, protein: 2.7, carbs: 28, fat: 0.3, fiber: 0.4 },
    'quinoa': { calories: 120, protein: 4.4, carbs: 22, fat: 1.9, fiber: 2.8 },
    'oats': { calories: 389, protein: 16.9, carbs: 66, fat: 6.9, fiber: 10.6 },
    'bread': { calories: 265, protein: 9, carbs: 49, fat: 3.2, fiber: 2.7 },
    
    // الخضار
    'broccoli': { calories: 34, protein: 2.8, carbs: 7, fat: 0.4, fiber: 2.6 },
    'spinach': { calories: 23, protein: 2.9, carbs: 3.6, fat: 0.4, fiber: 2.2 },
    'tomato': { calories: 18, protein: 0.9, carbs: 3.9, fat: 0.2, fiber: 1.2 },
    'onion': { calories: 40, protein: 1.1, carbs: 9.3, fat: 0.1, fiber: 1.7 },
    
    // الفواكه
    'banana': { calories: 89, protein: 1.1, carbs: 23, fat: 0.3, fiber: 2.6 },
    'apple': { calories: 52, protein: 0.3, carbs: 14, fat: 0.2, fiber: 2.4 },
    'orange': { calories: 47, protein: 0.9, carbs: 12, fat: 0.1, fiber: 2.4 },
    
    // الدهون الصحية
    'olive_oil': { calories: 884, protein: 0, carbs: 0, fat: 100, fiber: 0 },
    'avocado': { calories: 160, protein: 2, carbs: 9, fat: 15, fiber: 7 },
    'almonds': { calories: 579, protein: 21, carbs: 22, fat: 50, fiber: 12 },
    'walnuts': { calories: 654, protein: 15, carbs: 14, fat: 65, fiber: 7 }
  }

  // إضافة مكون جديد
  const addIngredient = () => {
    setIngredients([...ingredients, { 
      name: '', 
      amount: '', 
      unit: 'g', 
      calories: 0, 
      protein: 0, 
      carbs: 0, 
      fat: 0 
    }])
  }

  // حذف مكون
  const removeIngredient = (index) => {
    if (ingredients.length > 1) {
      const newIngredients = ingredients.filter((_, i) => i !== index)
      setIngredients(newIngredients)
    }
  }

  // تحديث مكون
  const updateIngredient = (index, field, value) => {
    const newIngredients = [...ingredients]
    newIngredients[index][field] = value

    // إذا تم تغيير اسم المكون، ابحث عن القيم الغذائية
    if (field === 'name') {
      const ingredient = commonIngredients[value.toLowerCase().replace(/\s+/g, '_')]
      if (ingredient) {
        newIngredients[index] = {
          ...newIngredients[index],
          calories: ingredient.calories,
          protein: ingredient.protein,
          carbs: ingredient.carbs,
          fat: ingredient.fat
        }
      }
    }

    // إعادة حساب القيم الغذائية بناءً على الكمية
    if (field === 'amount' && newIngredients[index].calories > 0) {
      const amount = parseFloat(value) || 0
      const baseNutrition = commonIngredients[newIngredients[index].name.toLowerCase().replace(/\s+/g, '_')]
      if (baseNutrition) {
        const factor = amount / 100 // القيم الأساسية لكل 100 جرام
        newIngredients[index].calories = Math.round(baseNutrition.calories * factor)
        newIngredients[index].protein = Math.round(baseNutrition.protein * factor * 10) / 10
        newIngredients[index].carbs = Math.round(baseNutrition.carbs * factor * 10) / 10
        newIngredients[index].fat = Math.round(baseNutrition.fat * factor * 10) / 10
      }
    }

    setIngredients(newIngredients)
  }

  // حساب إجمالي القيم الغذائية
  useEffect(() => {
    const total = ingredients.reduce((acc, ingredient) => {
      return {
        calories: acc.calories + (ingredient.calories || 0),
        protein: acc.protein + (ingredient.protein || 0),
        carbs: acc.carbs + (ingredient.carbs || 0),
        fat: acc.fat + (ingredient.fat || 0),
        fiber: acc.fiber + (ingredient.fiber || 0)
      }
    }, { calories: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 })

    setTotalNutrition(total)
  }, [ingredients])

  // حفظ الوصفة
  const saveRecipe = () => {
    const recipe = {
      id: Date.now(),
      name: recipeName,
      servings,
      ingredients,
      instructions,
      nutrition: {
        total: totalNutrition,
        perServing: {
          calories: Math.round(totalNutrition.calories / servings),
          protein: Math.round((totalNutrition.protein / servings) * 10) / 10,
          carbs: Math.round((totalNutrition.carbs / servings) * 10) / 10,
          fat: Math.round((totalNutrition.fat / servings) * 10) / 10,
          fiber: Math.round((totalNutrition.fiber / servings) * 10) / 10
        }
      },
      createdAt: new Date().toISOString()
    }

    const savedRecipes = JSON.parse(localStorage.getItem('customRecipes') || '[]')
    savedRecipes.push(recipe)
    localStorage.setItem('customRecipes', JSON.stringify(savedRecipes))

    alert(t('recipe_saved') || 'Recipe saved successfully!')
  }

  // مشاركة الوصفة
  const shareRecipe = () => {
    const recipeText = `
${recipeName}
${t('servings')}: ${servings}

${t('ingredients')}:
${ingredients.map(ing => `- ${ing.amount}${ing.unit} ${ing.name}`).join('\n')}

${t('instructions')}:
${instructions}

${t('nutrition_per_serving')}:
${t('calories')}: ${Math.round(totalNutrition.calories / servings)}
${t('protein')}: ${Math.round((totalNutrition.protein / servings) * 10) / 10}g
${t('carbs')}: ${Math.round((totalNutrition.carbs / servings) * 10) / 10}g
${t('fat')}: ${Math.round((totalNutrition.fat / servings) * 10) / 10}g
    `

    if (navigator.share) {
      navigator.share({
        title: recipeName,
        text: recipeText
      })
    } else {
      navigator.clipboard.writeText(recipeText)
      alert(t('recipe_copied') || 'Recipe copied to clipboard!')
    }
  }

  // طباعة الوصفة
  const printRecipe = () => {
    const printWindow = window.open('', '_blank')
    printWindow.document.write(`
      <html>
        <head>
          <title>${recipeName}</title>
          <style>
            body { font-family: Arial, sans-serif; margin: 20px; }
            h1 { color: #333; }
            .nutrition { background: #f5f5f5; padding: 15px; border-radius: 8px; }
            .ingredient { margin: 5px 0; }
          </style>
        </head>
        <body>
          <h1>${recipeName}</h1>
          <p><strong>${t('servings')}:</strong> ${servings}</p>
          
          <h2>${t('ingredients')}</h2>
          ${ingredients.map(ing => `<div class="ingredient">• ${ing.amount}${ing.unit} ${ing.name}</div>`).join('')}
          
          <h2>${t('instructions')}</h2>
          <p>${instructions.replace(/\n/g, '<br>')}</p>
          
          <div class="nutrition">
            <h2>${t('nutrition_per_serving')}</h2>
            <p><strong>${t('calories')}:</strong> ${Math.round(totalNutrition.calories / servings)}</p>
            <p><strong>${t('protein')}:</strong> ${Math.round((totalNutrition.protein / servings) * 10) / 10}g</p>
            <p><strong>${t('carbs')}:</strong> ${Math.round((totalNutrition.carbs / servings) * 10) / 10}g</p>
            <p><strong>${t('fat')}:</strong> ${Math.round((totalNutrition.fat / servings) * 10) / 10}g</p>
          </div>
        </body>
      </html>
    `)
    printWindow.document.close()
    printWindow.print()
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center space-y-2"
      >
        <div className="flex items-center justify-center gap-3">
          <div className="w-12 h-12 bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl flex items-center justify-center">
            <Calculator className="h-6 w-6 text-white" />
          </div>
          <h1 className="text-3xl font-bold text-gray-800 dark:text-gray-200">
            {t('recipe_calculator') || 'Recipe Calculator'}
          </h1>
        </div>
        <p className="text-gray-600 dark:text-gray-400">
          {t('recipe_calculator_desc') || 'Calculate nutritional values for your custom recipes'}
        </p>
      </motion.div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* معلومات الوصفة الأساسية */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.1 }}
          className="lg:col-span-2 space-y-6"
        >
          <Card className="enhanced-card">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <ChefHat className="h-5 w-5" />
                {t('recipe_details') || 'Recipe Details'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="md:col-span-2">
                  <Label htmlFor="recipeName">{t('recipe_name') || 'Recipe Name'}</Label>
                  <Input
                    id="recipeName"
                    value={recipeName}
                    onChange={(e) => setRecipeName(e.target.value)}
                    placeholder={t('enter_recipe_name') || 'Enter recipe name...'}
                  />
                </div>
                <div>
                  <Label htmlFor="servings">{t('servings') || 'Servings'}</Label>
                  <Input
                    id="servings"
                    type="number"
                    min="1"
                    value={servings}
                    onChange={(e) => setServings(parseInt(e.target.value) || 1)}
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* المكونات */}
          <Card className="enhanced-card">
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="flex items-center gap-2">
                  <Plus className="h-5 w-5" />
                  {t('ingredients') || 'Ingredients'}
                </CardTitle>
                <Button onClick={addIngredient} size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  {t('add_ingredient') || 'Add Ingredient'}
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {ingredients.map((ingredient, index) => (
                  <motion.div
                    key={index}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    className="grid grid-cols-12 gap-2 items-end p-4 bg-gray-50 dark:bg-gray-800 rounded-lg"
                  >
                    <div className="col-span-4">
                      <Label className="text-xs">{t('ingredient_name') || 'Name'}</Label>
                      <Input
                        value={ingredient.name}
                        onChange={(e) => updateIngredient(index, 'name', e.target.value)}
                        placeholder={t('ingredient_name') || 'Ingredient name'}
                        className="text-sm"
                      />
                    </div>
                    <div className="col-span-2">
                      <Label className="text-xs">{t('amount') || 'Amount'}</Label>
                      <Input
                        type="number"
                        value={ingredient.amount}
                        onChange={(e) => updateIngredient(index, 'amount', e.target.value)}
                        placeholder="100"
                        className="text-sm"
                      />
                    </div>
                    <div className="col-span-2">
                      <Label className="text-xs">{t('unit') || 'Unit'}</Label>
                      <select
                        value={ingredient.unit}
                        onChange={(e) => updateIngredient(index, 'unit', e.target.value)}
                        className="w-full px-3 py-2 text-sm border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      >
                        <option value="g">g</option>
                        <option value="kg">kg</option>
                        <option value="ml">ml</option>
                        <option value="l">l</option>
                        <option value="cup">{t('cup') || 'cup'}</option>
                        <option value="tbsp">{t('tbsp') || 'tbsp'}</option>
                        <option value="tsp">{t('tsp') || 'tsp'}</option>
                        <option value="piece">{t('piece') || 'piece'}</option>
                      </select>
                    </div>
                    <div className="col-span-3">
                      <Label className="text-xs">{t('calories') || 'Calories'}</Label>
                      <div className="flex items-center gap-1">
                        <Input
                          type="number"
                          value={ingredient.calories}
                          onChange={(e) => updateIngredient(index, 'calories', parseFloat(e.target.value) || 0)}
                          className="text-sm"
                        />
                        <span className="text-xs text-gray-500">cal</span>
                      </div>
                    </div>
                    <div className="col-span-1 flex justify-center">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeIngredient(index)}
                        disabled={ingredients.length === 1}
                        className="text-red-500 hover:text-red-700"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>

                    {/* القيم الغذائية للمكون */}
                    <div className="col-span-12 grid grid-cols-3 gap-2 mt-2 pt-2 border-t border-gray-200 dark:border-gray-700">
                      <div>
                        <Label className="text-xs text-gray-500">{t('protein') || 'Protein'}</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={ingredient.protein}
                          onChange={(e) => updateIngredient(index, 'protein', parseFloat(e.target.value) || 0)}
                          className="text-xs h-8"
                        />
                      </div>
                      <div>
                        <Label className="text-xs text-gray-500">{t('carbs') || 'Carbs'}</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={ingredient.carbs}
                          onChange={(e) => updateIngredient(index, 'carbs', parseFloat(e.target.value) || 0)}
                          className="text-xs h-8"
                        />
                      </div>
                      <div>
                        <Label className="text-xs text-gray-500">{t('fat') || 'Fat'}</Label>
                        <Input
                          type="number"
                          step="0.1"
                          value={ingredient.fat}
                          onChange={(e) => updateIngredient(index, 'fat', parseFloat(e.target.value) || 0)}
                          className="text-xs h-8"
                        />
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* طريقة التحضير */}
          <Card className="enhanced-card">
            <CardHeader>
              <CardTitle>{t('instructions') || 'Instructions'}</CardTitle>
            </CardHeader>
            <CardContent>
              <Textarea
                value={instructions}
                onChange={(e) => setInstructions(e.target.value)}
                placeholder={t('enter_instructions') || 'Enter cooking instructions...'}
                rows={6}
              />
            </CardContent>
          </Card>
        </motion.div>

        {/* ملخص القيم الغذائية */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
          className="space-y-6"
        >
          {/* إجمالي القيم الغذائية */}
          <Card className="enhanced-card">
            <CardHeader>
              <CardTitle className="text-center">
                {t('total_nutrition') || 'Total Nutrition'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
                  {totalNutrition.calories}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  {t('total_calories') || 'Total Calories'}
                </div>
              </div>

              <div className="grid grid-cols-3 gap-2 text-center">
                <div className="p-3 bg-green-50 dark:bg-green-900/20 rounded-lg">
                  <div className="text-lg font-semibold text-green-600 dark:text-green-400">
                    {totalNutrition.protein.toFixed(1)}g
                  </div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">
                    {t('protein') || 'Protein'}
                  </div>
                </div>
                <div className="p-3 bg-orange-50 dark:bg-orange-900/20 rounded-lg">
                  <div className="text-lg font-semibold text-orange-600 dark:text-orange-400">
                    {totalNutrition.carbs.toFixed(1)}g
                  </div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">
                    {t('carbs') || 'Carbs'}
                  </div>
                </div>
                <div className="p-3 bg-purple-50 dark:bg-purple-900/20 rounded-lg">
                  <div className="text-lg font-semibold text-purple-600 dark:text-purple-400">
                    {totalNutrition.fat.toFixed(1)}g
                  </div>
                  <div className="text-xs text-gray-600 dark:text-gray-400">
                    {t('fat') || 'Fat'}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* القيم الغذائية لكل حصة */}
          <Card className="enhanced-card">
            <CardHeader>
              <CardTitle className="text-center">
                {t('per_serving') || 'Per Serving'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-green-600 dark:text-green-400">
                  {Math.round(totalNutrition.calories / servings)}
                </div>
                <div className="text-sm text-gray-600 dark:text-gray-400">
                  {t('calories_per_serving') || 'Calories per serving'}
                </div>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    {t('protein') || 'Protein'}
                  </span>
                  <Badge variant="outline">
                    {Math.round((totalNutrition.protein / servings) * 10) / 10}g
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    {t('carbs') || 'Carbs'}
                  </span>
                  <Badge variant="outline">
                    {Math.round((totalNutrition.carbs / servings) * 10) / 10}g
                  </Badge>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-gray-600 dark:text-gray-400">
                    {t('fat') || 'Fat'}
                  </span>
                  <Badge variant="outline">
                    {Math.round((totalNutrition.fat / servings) * 10) / 10}g
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* أزرار الإجراءات */}
          <Card className="enhanced-card">
            <CardContent className="p-4 space-y-3">
              <Button 
                onClick={saveRecipe} 
                className="w-full"
                disabled={!recipeName.trim() || ingredients.some(ing => !ing.name.trim())}
              >
                <Save className="h-4 w-4 mr-2" />
                {t('save_recipe') || 'Save Recipe'}
              </Button>
              
              <div className="grid grid-cols-2 gap-2">
                <Button variant="outline" onClick={shareRecipe} size="sm">
                  <Share2 className="h-4 w-4 mr-1" />
                  {t('share') || 'Share'}
                </Button>
                <Button variant="outline" onClick={printRecipe} size="sm">
                  <Printer className="h-4 w-4 mr-1" />
                  {t('print') || 'Print'}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* نصائح */}
          <Card className="enhanced-card">
            <CardHeader>
              <CardTitle className="text-sm">
                {t('tips') || 'Tips'}
              </CardTitle>
            </CardHeader>
            <CardContent className="text-xs text-gray-600 dark:text-gray-400 space-y-2">
              <p>• {t('tip_1') || 'Use common ingredient names for automatic nutrition lookup'}</p>
              <p>• {t('tip_2') || 'Nutritional values are calculated per 100g by default'}</p>
              <p>• {t('tip_3') || 'You can manually adjust nutritional values for accuracy'}</p>
              <p>• {t('tip_4') || 'Save your recipes to build a personal collection'}</p>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  )
}

export default RecipeCalculator

