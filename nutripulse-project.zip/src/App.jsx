import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Input } from '@/components/ui/input.jsx'
import { Label } from '@/components/ui/label.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Calculator, Sun, Moon, Menu, Home, Languages, ArrowLeft } from 'lucide-react'
import { motion } from 'framer-motion'

// Import components
import HomePage from './components/HomePage'
import Settings from './components/Settings'
import UnitConverter from './components/UnitConverter'
import Sidebar from './Sidebar'
import IdealWeight from './sections/IdealWeight'
import BMICalculator from './sections/BMICalculator'
import WaterNeeds from './sections/WaterNeeds'
import BodyFat from './sections/BodyFat'
import MetabolicRate from './sections/MetabolicRate'
import WeightLog from './sections/WeightLog'
import NutritionTracking from './sections/NutritionTracking'
import BarcodeScanner from './sections/BarcodeScanner'
import ActivityLog from './sections/ActivityLog'
import ComingSoon from './sections/ComingSoon'

// Import translations
import { translations, getBrowserLanguage, getTranslation } from './translations'
import './App.css'

function App() {
  // Initialize language from browser or default to English
  const [language, setLanguage] = useState(() => {
    const saved = localStorage.getItem('preferred-language')
    return saved || getBrowserLanguage()
  })
  
  const [theme, setTheme] = useState(() => {
    const saved = localStorage.getItem('theme')
    return saved || 'light'
  })
  
  const [isSidebarOpen, setIsSidebarOpen] = useState(false)
  const [activeSection, setActiveSection] = useState('home')

  // Save preferences to localStorage
  useEffect(() => {
    localStorage.setItem('preferred-language', language)
    localStorage.setItem('theme', theme)
  }, [language, theme])

  // Translation helper
  const t = (key) => getTranslation(key, language)

  // State for calculators
  const [foodCalories, setFoodCalories] = useState({
    protein: "",
    carbs: "",
    fat: "",
    result: 0,
    errors: { protein: "", carbs: "", fat: "" }
  })

  const [dailyNeeds, setDailyNeeds] = useState({
    age: "",
    gender: "",
    weight: "",
    height: "",
    activity: "",
    result: 0,
    errors: { age: "", gender: "", weight: "", height: "", activity: "" }
  })

  const toggleTheme = () => {
    setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light')
  }

  const toggleLanguage = () => {
    setLanguage(prevLang => prevLang === 'en' ? 'ar' : 'en')
  }

  const toggleSidebar = () => {
    setIsSidebarOpen(!isSidebarOpen)
  }

  const handleSectionChange = (section) => {
    setActiveSection(section)
    setIsSidebarOpen(false)
  }

  const goHome = () => {
    setActiveSection('home')
  }

  // Calculate food calories
  const calculateFoodCalories = () => {
    const protein = parseFloat(foodCalories.protein)
    const carbs = parseFloat(foodCalories.carbs)
    const fat = parseFloat(foodCalories.fat)
    
    let errors = { protein: "", carbs: "", fat: "" }
    let hasErrors = false

    if (!foodCalories.protein || protein < 0 || protein > 1000) {
      errors.protein = t('invalid_protein')
      hasErrors = true
    }
    if (!foodCalories.carbs || carbs < 0 || carbs > 1000) {
      errors.carbs = t('invalid_carbs')
      hasErrors = true
    }
    if (!foodCalories.fat || fat < 0 || fat > 1000) {
      errors.fat = t('invalid_fat')
      hasErrors = true
    }

    if (hasErrors) {
      setFoodCalories(prev => ({ ...prev, errors }))
      return
    }

    const result = Math.round((protein * 4) + (carbs * 4) + (fat * 9))
    setFoodCalories(prev => ({ ...prev, result, errors }))
  }

  // Calculate daily needs
  const calculateDailyNeeds = () => {
    const age = parseInt(dailyNeeds.age)
    const weight = parseFloat(dailyNeeds.weight)
    const height = parseFloat(dailyNeeds.height)
    
    let errors = { age: "", gender: "", weight: "", height: "", activity: "" }
    let hasErrors = false

    if (!dailyNeeds.age || age < 1 || age > 120) {
      errors.age = t('invalid_age')
      hasErrors = true
    }
    if (!dailyNeeds.gender) {
      errors.gender = t('select_gender')
      hasErrors = true
    }
    if (!dailyNeeds.weight || weight < 5 || weight > 500) {
      errors.weight = t('invalid_weight')
      hasErrors = true
    }
    if (!dailyNeeds.height || height < 50 || height > 250) {
      errors.height = t('invalid_height')
      hasErrors = true
    }
    if (!dailyNeeds.activity) {
      errors.activity = t('select_activity')
      hasErrors = true
    }

    if (hasErrors) {
      setDailyNeeds(prev => ({ ...prev, errors }))
      return
    }

    // Calculate BMR using Mifflin-St Jeor equation
    let bmr
    if (age < 18) {
      // Simplified calculation for children/teens
      if (dailyNeeds.gender === 'male') {
        bmr = 10 * weight + 6.25 * height - 5 * age + 5
      } else {
        bmr = 10 * weight + 6.25 * height - 5 * age - 161
      }
    } else {
      // Standard adult calculation
      if (dailyNeeds.gender === 'male') {
        bmr = 10 * weight + 6.25 * height - 5 * age + 5
      } else {
        bmr = 10 * weight + 6.25 * height - 5 * age - 161
      }
    }

    const activityFactors = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      very_active: 1.9
    }

    const result = Math.round(bmr * activityFactors[dailyNeeds.activity])
    setDailyNeeds(prev => ({ ...prev, result, errors }))
  }

  // Render daily needs calculator
  const renderDailyNeedsCalculator = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="max-w-2xl mx-auto"
    >
      <Card className="enhanced-card">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-gray-800 dark:text-gray-200 flex items-center justify-center gap-3">
            <Calculator className="h-8 w-8 text-blue-600 dark:text-blue-400" />
            {t('daily_needs')}
          </CardTitle>
          <CardDescription className="text-gray-600 dark:text-gray-400">
            {t('daily_needs_desc')}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-3">
              <Label htmlFor="age" className="text-gray-700 dark:text-gray-200 font-semibold">
                {t('age')}
              </Label>
              <Input
                id="age"
                type="number"
                placeholder="25"
                value={dailyNeeds.age}
                onChange={(e) => setDailyNeeds(prev => ({ ...prev, age: e.target.value, errors: { ...prev.errors, age: "" } }))}
                className={`enhanced-input text-lg py-4 ${dailyNeeds.errors.age ? "border-red-500" : ""}`}
              />
              {dailyNeeds.errors.age && (
                <p className="text-red-500 text-sm">{dailyNeeds.errors.age}</p>
              )}
            </div>
            
            <div className="space-y-3">
              <Label htmlFor="gender" className="text-gray-700 dark:text-gray-200 font-semibold">
                {t('gender')}
              </Label>
              <Select value={dailyNeeds.gender} onValueChange={(value) => setDailyNeeds(prev => ({ ...prev, gender: value, errors: { ...prev.errors, gender: "" } }))}>
                <SelectTrigger className={`enhanced-input text-lg py-4 ${dailyNeeds.errors.gender ? "border-red-500" : ""}`}>
                  <SelectValue placeholder={t('gender')} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="male">{t('male')}</SelectItem>
                  <SelectItem value="female">{t('female')}</SelectItem>
                </SelectContent>
              </Select>
              {dailyNeeds.errors.gender && (
                <p className="text-red-500 text-sm">{dailyNeeds.errors.gender}</p>
              )}
            </div>
            
            <div className="space-y-3">
              <Label htmlFor="weight" className="text-gray-700 dark:text-gray-200 font-semibold">
                {t('weight')}
              </Label>
              <Input
                id="weight"
                type="number"
                placeholder="70"
                value={dailyNeeds.weight}
                onChange={(e) => setDailyNeeds(prev => ({ ...prev, weight: e.target.value, errors: { ...prev.errors, weight: "" } }))}
                className={`enhanced-input text-lg py-4 ${dailyNeeds.errors.weight ? "border-red-500" : ""}`}
              />
              {dailyNeeds.errors.weight && (
                <p className="text-red-500 text-sm">{dailyNeeds.errors.weight}</p>
              )}
            </div>
            
            <div className="space-y-3">
              <Label htmlFor="height" className="text-gray-700 dark:text-gray-200 font-semibold">
                {t('height')}
              </Label>
              <Input
                id="height"
                type="number"
                placeholder="175"
                value={dailyNeeds.height}
                onChange={(e) => setDailyNeeds(prev => ({ ...prev, height: e.target.value, errors: { ...prev.errors, height: "" } }))}
                className={`enhanced-input text-lg py-4 ${dailyNeeds.errors.height ? "border-red-500" : ""}`}
              />
              {dailyNeeds.errors.height && (
                <p className="text-red-500 text-sm">{dailyNeeds.errors.height}</p>
              )}
            </div>
          </div>

          <div className="space-y-3">
            <Label htmlFor="activity" className="text-gray-700 dark:text-gray-200 font-semibold">
              {t('activity_level')}
            </Label>
            <Select value={dailyNeeds.activity} onValueChange={(value) => setDailyNeeds(prev => ({ ...prev, activity: value, errors: { ...prev.errors, activity: "" } }))}>
              <SelectTrigger className={`enhanced-input text-lg py-4 ${dailyNeeds.errors.activity ? "border-red-500" : ""}`}>
                <SelectValue placeholder={t('activity_level')} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="sedentary">{t('sedentary')}</SelectItem>
                <SelectItem value="light">{t('light')}</SelectItem>
                <SelectItem value="moderate">{t('moderate')}</SelectItem>
                <SelectItem value="active">{t('active')}</SelectItem>
                <SelectItem value="very_active">{t('very_active')}</SelectItem>
              </SelectContent>
            </Select>
            {dailyNeeds.errors.activity && (
              <p className="text-red-500 text-sm">{dailyNeeds.errors.activity}</p>
            )}
          </div>

          <Button 
            onClick={calculateDailyNeeds}
            className="w-full enhanced-button text-lg py-6 font-semibold"
          >
            {t('calculate_daily_needs')}
          </Button>

          {dailyNeeds.result > 0 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="mt-8 p-6 bg-gradient-to-r from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 rounded-2xl border border-blue-200 dark:border-blue-700"
            >
              <h3 className="text-xl font-bold text-center mb-6 text-gray-800 dark:text-gray-200">
                {t('your_daily_needs')}
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-white/80 dark:bg-gray-800/80 p-4 rounded-xl text-center">
                  <p className="font-semibold text-red-600 dark:text-red-400 mb-1">{t('for_weight_loss')}</p>
                  <p className="text-lg font-bold">{dailyNeeds.result - 500}</p>
                  <p className="text-xs text-gray-500">(-500 {t('calories_per_gram')})</p>
                </div>
                <div className="bg-white/80 dark:bg-gray-800/80 p-4 rounded-xl text-center">
                  <p className="font-semibold text-green-600 dark:text-green-400 mb-1">{t('to_maintain_weight')}</p>
                  <p className="text-lg font-bold">{dailyNeeds.result}</p>
                  <p className="text-xs text-gray-500">{t('calories_per_gram')}</p>
                </div>
                <div className="bg-white/80 dark:bg-gray-800/80 p-4 rounded-xl text-center">
                  <p className="font-semibold text-blue-600 dark:text-blue-400 mb-1">{t('for_weight_gain')}</p>
                  <p className="text-lg font-bold">{dailyNeeds.result + 500}</p>
                  <p className="text-xs text-gray-500">(+500 {t('calories_per_gram')})</p>
                </div>
              </div>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  )

  // Render food calories calculator
  const renderFoodCaloriesCalculator = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
      className="max-w-2xl mx-auto"
    >
      <Card className="enhanced-card">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-gray-800 dark:text-gray-200 flex items-center justify-center gap-3">
            <Calculator className="h-8 w-8 text-purple-600 dark:text-purple-400" />
            {t('food_calories')}
          </CardTitle>
          <CardDescription className="text-gray-600 dark:text-gray-400">
            {t('food_calories_desc')}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-3">
              <Label htmlFor="protein" className="text-gray-700 dark:text-gray-200 font-semibold flex items-center gap-2">
                <span className="w-3 h-3 bg-red-500 rounded-full"></span>
                {t('protein')}
              </Label>
              <Input
                id="protein"
                type="number"
                placeholder="0"
                value={foodCalories.protein}
                onChange={(e) => setFoodCalories(prev => ({ ...prev, protein: e.target.value, errors: { ...prev.errors, protein: "" } }))}
                className={`enhanced-input text-center text-lg py-4 ${foodCalories.errors.protein ? "border-red-500" : ""}`}
              />
              {foodCalories.errors.protein && (
                <p className="text-red-500 text-sm">{foodCalories.errors.protein}</p>
              )}
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center">4 {t('calories_per_gram')}</p>
            </div>
            
            <div className="space-y-3">
              <Label htmlFor="carbs" className="text-gray-700 dark:text-gray-200 font-semibold flex items-center gap-2">
                <span className="w-3 h-3 bg-yellow-500 rounded-full"></span>
                {t('carbs')}
              </Label>
              <Input
                id="carbs"
                type="number"
                placeholder="0"
                value={foodCalories.carbs}
                onChange={(e) => setFoodCalories(prev => ({ ...prev, carbs: e.target.value, errors: { ...prev.errors, carbs: "" } }))}
                className={`enhanced-input text-center text-lg py-4 ${foodCalories.errors.carbs ? "border-red-500" : ""}`}
              />
              {foodCalories.errors.carbs && (
                <p className="text-red-500 text-sm">{foodCalories.errors.carbs}</p>
              )}
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center">4 {t('calories_per_gram')}</p>
            </div>
            
            <div className="space-y-3">
              <Label htmlFor="fat" className="text-gray-700 dark:text-gray-200 font-semibold flex items-center gap-2">
                <span className="w-3 h-3 bg-green-500 rounded-full"></span>
                {t('fat')}
              </Label>
              <Input
                id="fat"
                type="number"
                placeholder="0"
                value={foodCalories.fat}
                onChange={(e) => setFoodCalories(prev => ({ ...prev, fat: e.target.value, errors: { ...prev.errors, fat: "" } }))}
                className={`enhanced-input text-center text-lg py-4 ${foodCalories.errors.fat ? "border-red-500" : ""}`}
              />
              {foodCalories.errors.fat && (
                <p className="text-red-500 text-sm">{foodCalories.errors.fat}</p>
              )}
              <p className="text-sm text-gray-500 dark:text-gray-400 text-center">9 {t('calories_per_gram')}</p>
            </div>
          </div>

          <Button 
            onClick={calculateFoodCalories}
            className="w-full enhanced-button text-lg py-6 font-semibold"
          >
            {t('calculate_food_calories')}
          </Button>

          {foodCalories.result > 0 && (
            <motion.div
              initial={{ opacity: 0, scale: 0.9 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="text-center p-8 bg-gradient-to-r from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20 rounded-2xl border border-purple-200 dark:border-purple-700"
            >
              <h3 className="text-2xl font-bold text-gray-800 dark:text-gray-200 mb-2">
                {t('total_calories')}
              </h3>
              <p className="text-4xl font-bold bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent">
                {foodCalories.result}
              </p>
              <p className="text-gray-600 dark:text-gray-400 mt-2">{t('calories_per_gram')}</p>
            </motion.div>
          )}
        </CardContent>
      </Card>
    </motion.div>
  )

  // Render content based on active section
  const renderContent = () => {
    switch (activeSection) {
      case 'home':
        return <HomePage language={language} onSectionChange={handleSectionChange} />
      case 'daily-needs':
        return renderDailyNeedsCalculator()
      case 'food-calories':
        return renderFoodCaloriesCalculator()
      case 'ideal-weight':
        return <IdealWeight language={language} />
      case 'bmi':
        return <BMICalculator language={language} />
      case 'water-needs':
        return <WaterNeeds language={language} />
      case 'body-fat':
        return <BodyFat language={language} />
      case 'metabolic-rate':
        return <MetabolicRate language={language} />
      case 'barcode-scanner':
        return <BarcodeScanner language={language} />
      case 'weight-log':
        return <WeightLog language={language} />
      case 'nutrition-tracking':
        return <NutritionTracking language={language} />
      case 'activity-log':
        return <ActivityLog language={language} />
      case 'preferences':
        return <Settings language={language} />
      case 'unit-converter':
        return <UnitConverter language={language} />
      default:
        return <ComingSoon language={language} sectionName={t(activeSection.replace('-', '_'))} />
    }
  }

  return (
    <div className={`min-h-screen ${theme === 'dark' ? 'dark' : ''}`} dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <div className="min-h-screen p-4 enhanced-gradient-bg">
        <Sidebar 
          isOpen={isSidebarOpen} 
          onClose={toggleSidebar} 
          activeSection={activeSection} 
          onSectionChange={handleSectionChange}
          language={language}
        />
        
        <div className="max-w-6xl mx-auto relative z-10">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            className="flex items-center justify-between mb-8"
          >
            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="lg"
                onClick={toggleSidebar}
                className="enhanced-button-ghost p-3"
              >
                <Menu className="h-8 w-8" />
              </Button>
              
              {activeSection !== 'home' && (
                <Button
                  variant="ghost"
                  onClick={goHome}
                  className="enhanced-button-ghost flex items-center gap-2 p-3"
                >
                  {language === 'ar' ? <ArrowLeft className="h-6 w-6 rotate-180" /> : <ArrowLeft className="h-6 w-6" />}
                  <Home className="h-6 w-6" />
                  {t('home')}
                </Button>
              )}
            </div>

            <div className="flex items-center gap-3">
              <motion.div 
                className="flex items-center gap-2 text-2xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent"
                whileHover={{ scale: 1.05 }}
              >
                <Calculator className="h-8 w-8 text-blue-600 dark:text-blue-400" />
                {t('title')}
              </motion.div>
            </div>

            <div className="flex items-center gap-4">
              <Button
                variant="ghost"
                size="lg"
                onClick={toggleLanguage}
                className="enhanced-button-ghost p-3"
                title={language === 'en' ? 'العربية' : 'English'}
              >
                <Languages className="h-8 w-8" />
              </Button>
              
              <Button
                variant="ghost"
                size="lg"
                onClick={toggleTheme}
                className="enhanced-button-ghost p-3"
              >
                {theme === 'light' ? <Moon className="h-8 w-8" /> : <Sun className="h-8 w-8" />}
              </Button>
            </div>
          </motion.div>

          {/* Main Content */}
          <div className="space-y-8">
            {activeSection === 'home' && (
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="text-center mb-12"
              >
                <p className="text-lg text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
                  {t('subtitle')}
                </p>
              </motion.div>
            )}
            
            {renderContent()}
          </div>

          {/* Footer */}
          <motion.footer
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
            className="mt-12 text-center"
          >
            <div className="enhanced-card rounded-2xl p-6 max-w-2xl mx-auto">
              <p className="text-sm text-gray-600 dark:text-gray-400 leading-relaxed">
                <span className="font-semibold text-amber-600 dark:text-amber-400">{t('disclaimer')}</span> {t('disclaimer_text')}
              </p>
            </div>
          </motion.footer>
        </div>
      </div>
    </div>
  )
}

export default App

